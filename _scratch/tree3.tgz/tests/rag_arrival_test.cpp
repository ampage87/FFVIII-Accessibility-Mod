// rag_arrival_test -- the Ragnarok's arrival rule and the words it says.
//
// WHY THIS EXISTS
// ---------------
// Every other drive in this mod ends when a field loads, which is why
// world_map_drive.inl has no distance arrival test at all. Flying does not end
// that way: the ship arrives ABOVE a piece of ground and nothing happens until
// the player sets it down. Without a radius the drive would press UP over the
// spot forever, and without something said he would never know he was there.
//
// And it must not land for him. Aaron: "Let's not have auto-drive automatically
// land and instead prompt the player to land just like we do with Garden."
#include <cstdio>
#include <cstring>
#include <cstdint>
#include <cstdlib>
#include <string>

#define _stricmp strcasecmp
#define FF8OPC_RAG_HOST_TEST 1     // RagIsFlying needs the live engine; skip it

#include "rag_landing_model.inl"
#include "world_rag_arrival.inl"

static int bad = 0;
static void check(bool ok, const char* what)
{ if (!ok) { std::printf("  BAD: %s\n", what); bad++; } }
static bool has(const char* hay, const char* needle)
{ return std::strstr(hay, needle) != nullptr; }

int main()
{
    std::printf("rag_arrival_test\n");

    // ---- the decision ----------------------------------------------------
    check(RagArriveDecide(false, true, RAG_PAD, 0.0) == RAG_FLY_ON,
          "**a player who is not flying is never arrived by this rule** -- it is "
          "the one arrival test in the world map that is not driven by a field "
          "load, and letting it fire on foot would end a walk in mid-sentence");
    check(RagArriveDecide(true, false, RAG_PAD, 0.0) == RAG_FLY_ON,
          "**and neither is a destination with no landing row** -- the drive still "
          "flies there, it just has no opinion about where to set down");

    check(RagArriveDecide(true, true, RAG_PAD,  RAG_ARRIVE_DIST) == RAG_FLY_ON,
          "at exactly the radius it is still flying");
    check(RagArriveDecide(true, true, RAG_PAD,  RAG_ARRIVE_DIST - 1) == RAG_OVER_PAD,
          "**inside the radius over a pad, it is over the pad**");
    check(RagArriveDecide(true, true, RAG_WALK, RAG_ARRIVE_DIST - 1) == RAG_OVER_SPOT,
          "**and over a walk row it is over the spot** -- the two end the same "
          "drive and mean different things to the player, so they are different "
          "answers rather than one with a flag");
    check(RAG_ARRIVE_DIST >= 400.0 && RAG_ARRIVE_DIST <= 900.0,
          "**the radius is a couple of the airship's own move steps** -- 0x100 "
          "each, from the engine's step table; the Deep Sea Research Center's pad "
          "is 768 units across, so a tighter radius would fly past it and a much "
          "looser one would stop short of it");

    // ---- the words -------------------------------------------------------
    char b[256];
    RagArrivalLine(RAG_OVER_PAD, "Fisherman's Horizon", 0, "north", b, sizeof b);
    check(has(b, "Land the Ragnarok") && has(b, "Fisherman's Horizon"),
          "**a pad tells him to land, and names the place**");
    check(!has(b, "walk"),
          "**and says nothing about walking** -- landing on a pad IS the arrival");

    RagArrivalLine(RAG_OVER_SPOT, "Balamb Town", 704, "east", b, sizeof b);
    check(has(b, "Land the Ragnarok") && has(b, "backslash") && has(b, "east"),
          "**a short walk gives him the key that starts it and the direction** -- "
          "the Garden's parked announcement has done exactly this since v0.20.79");
    check(has(b, "7 hundred"),
          "and rounds to hundreds of units, the unit the rest of the mod speaks");

    RagArrivalLine(RAG_OVER_SPOT, "Shumi Village", 12288, "north", b, sizeof b);
    check(has(b, "kilometres") && has(b, "long walk"),
          "**past five kilometres it switches to kilometres and says it is a "
          "hike** -- 'one hundred and twenty-two hundred units' is not a distance "
          "anyone can hold in their head, which the Garden learned at v0.20.88");

    // ---- it never lands by itself ---------------------------------------
    for (int k = 0; k < 2; k++) {
        RagArrivalLine(k ? RAG_OVER_PAD : RAG_OVER_SPOT, "Anywhere", 100, "west", b, sizeof b);
        check(has(b, "Land the Ragnarok"),
              "**every arrival asks HIM to land** -- the mod flies him to the spot "
              "and stops; the last act of arriving is the player's");
    }

    // ---- and the table and the rule agree about pads ---------------------
    {
        const RagLanding* fh = RagLandingFor("Fisherman's Horizon");
        check(fh != nullptr && RagArriveDecide(true, true, fh->kind, 0.0) == RAG_OVER_PAD,
              "the shipped table's pads reach the pad branch");
        const RagLanding* bt = RagLandingFor("Balamb Town");
        check(bt != nullptr && RagArriveDecide(true, true, bt->kind, 0.0) == RAG_OVER_SPOT,
              "and its walk rows reach the walk branch");
    }

    std::printf(bad ? "rag_arrival_test: FAILED (%d bad)\n"
                    : "rag_arrival_test: OK (%d bad)\n", bad);
    return bad ? 1 : 0;
}
