// rag_approach_pure.inl -- the Ragnarok is a helicopter, not a plane.
//
// A statement-free header fragment #included by world_map_drive.inl (the real
// build) and by tests/rag_approach_test.cpp.
//
// THE CORRECTION THAT MATTERS MOST HERE. v0.85.0 shipped this file explaining
// the 12:59 orbit as a TURNING CIRCLE -- "at 2,500 units per second the
// airship's turning circle is a thousand units and more across". Aaron, who
// flies it: "you can literally stop in midair and turn the ship in any direction
// you want. You do not have to turn in a wide circle." THAT IS THE WHOLE MODEL
// AND I HAD IT WRONG. The record is corrected here rather than quietly amended,
// for the same reason the v0.73.0 changelog corrected the v0.72.0 Propagator
// diagnosis: a wrong explanation that happens to sit next to a working fix is
// the most expensive kind of comment, because the next person builds on it.
//
// SO WHAT ACTUALLY CAUSED THE ORBIT. The executor's vehicle final-approach
// branch fires inside VEH_FINAL_APPROACH_DIST (1200 units) and says, in its own
// comment: "never stop to pivot: a stationary rotate-and-launch cycle at this
// range can only ORBIT the aim". For a car inside its own turning circle that is
// right, and #68 proved it. For a machine that can stop dead and spin on the
// spot it is exactly backwards -- and worse, 1200 units is HALF A SECOND of
// Ragnarok travel. The ship crossed the zone with the throttle pinned before any
// arc-steering could bend it, came out the far side, pivoted at ~1600, launched
// back in, and crossed again. The ring in the trace -- 1830, 1770, 1113, 1645,
// 958, 1618, 1281 -- is that cycle, not a radius the ship was unable to turn
// inside of. It was never flying a circle. IT WAS BEING FORBIDDEN TO STOP.
//
// The evidence for the correction was in the same trace all along: it holds one
// position for THIRTY-THREE CONSECUTIVE FRAMES while it pivots. A vehicle with a
// thousand-unit turning circle cannot do that.
//
// WHICH MAKES THE APPROACH SIMPLE, BECAUSE IT IS WHAT THE SHIP IS GOOD AT.
// Stop, aim, hop. Aim off by more than a hair and the throttle is shut entirely
// while it rotates -- free, instant, and costing only the time to turn. Aimed,
// and it spends one short pulse. If a pulse carries it PAST the target, the
// throttle shuts the moment the distance grows, and it re-aims from where it
// stopped. None of that is available to a car, and all of it is available here.
static const double RAG_BRAKE_DIST   = 4000.0;  // start braking here
static const unsigned RAG_PULSE_MS   = 100;     // one throttle slice
static const unsigned RAG_PULSE_EVERY = 3;      // ...open 1 slice in 3

// Beyond RAG_BRAKE_DIST the airship runs flat out -- it has nothing to route
// around and 150 km to cross. Inside it, the throttle is pulsed: not to bleed
// off a turning circle, which does not exist, but so that ONE PULSE IS SHORTER
// THAN THE DISTANCE LEFT. The 288-unit arrival disc is a tenth of a second of
// cruise, and a hop that overshoots it has to be undone.
//
// `grew` shuts the throttle outright: if the last tick INCREASED the distance,
// the ship is past the target and the only useful thing it can do is stop. A car
// cannot act on that -- stopping and restarting is how #68's orbit began. This
// one can.
static bool RagThrottleOpen(bool flying, double dist, unsigned nowMs, bool grew)
{
    if (!flying) return true;                    // foot and car are BAT-tuned
    if (dist >= RAG_BRAKE_DIST) return true;
    if (grew) return false;                      // overshot -- stop, then re-aim
    return ((nowMs / RAG_PULSE_MS) % RAG_PULSE_EVERY) == 0;
}

// Did the last tick take us further away? Only meaningful inside the approach,
// and only once there is a previous reading to compare with.
static bool RagDistGrew(double distNow, double distPrev)
{
    if (distPrev <= 0.0) return false;
    return distNow > distPrev;
}

// And on the braked approach it aims properly before spending a pulse. The
// ordinary cone is ~50 degrees, which is fine for a car that has to keep rolling
// to steer at all. Rotation here is free and instant, so there is no reason to
// accept any error worth correcting: aim, THEN spend the pulse.
static const int RAG_FINAL_CONE = 96;            // ~8.4 degrees of 4096

static int RagSteerCone(bool flying, double dist, int defaultCone)
{
    if (!flying) return defaultCone;
    if (dist >= RAG_BRAKE_DIST) return defaultCone;
    return RAG_FINAL_CONE;
}

// ---------------------------------------------------------------------------
// AND IF IT STILL ORBITS, IT HAS TO SAY SO.
//
// The BAT ran "Stuck check 1/6, 2/6, 1/6, 2/6" for fifty-eight seconds and never
// reached six. The give-up counter resets on MOVEMENT, and a ship crossing and
// re-crossing its destination is moving beautifully -- 3,000 units a window. v0.84.0 fixed exactly this for the
// turn budget and left the give-up counter alone, which was half a lesson
// learned. For flight, the strike is scored on PROGRESS: the one measure an
// orbit cannot fake.
//
// Deliberately NOT applied on foot or in the car. There, a drive that is shoving
// itself off a wall is making no progress either, and the reverse-burst recovery
// that #67 spent many builds tuning depends on those strikes being spent slowly.
static bool RagStuckStrike(bool flying, double moved, double movedFloor,
                           double distNow, double distThen, double progressFloor)
{
    if (!flying) return moved < movedFloor;      // unchanged for everything else
    if (distThen <= 0.0) return false;           // no previous reading; no strike
    return (distThen - distNow) < progressFloor;
}

// ---------------------------------------------------------------------------
// COMMANDED FORWARD, AND DID NOT MOVE.
//
// Aaron: "Did a short test this time and got stuck heading for FH. I gained
// altitude then it seemed to go the rest of the way fine. Can you tell if the
// ship is getting stuck?" YES, AND THE 15:15 LOG SAYS IT IN ONE LINE REPEATED
// SIXTEEN TIMES:
//
//   [RAGSTEER] dist=1806 hdg=2255 off=65 err=-65 cone=96 gas=1 grew=0 keys=U---
//
// Distance frozen at 1806. Heading frozen at 2255. Aimed well inside the cone.
// AND UP IS BEING PRESSED. The mod asked the ship to go forward and the ship did
// not go forward, for fifteen seconds, 1,806 units short of the Fisherman's
// Horizon pad at (20871,-4323).
//
// For this hull that can mean exactly one thing. 0x53E6B0 falls through to
// `return 1` for vehicle 0x32, so no POLYGON is closed to it -- which means what
// stopped it is not in the polygon mask at all. It is a structure standing up
// off the ground, and FH is the largest structure on the map. Aaron cleared it
// by gaining altitude, which is the same fact from the pilot's seat.
//
// This is a DIFFERENT FAILURE from the give-up counter's ordinary one, and it
// deserves a different answer. "Stuck. Cannot reach destination." is true and
// useless: it tells a blind pilot nothing he can act on. Two strikes is also
// plenty -- the ordinary six exist because a car's stall is ambiguous, and this
// one is not ambiguous at all.
static const int RAG_BLOCKED_MAX = 2;

static bool RagBlockedStrike(bool flying, int gasTicks, double moved, double movedFloor)
{
    if (!flying)        return false;   // only the airship can be blocked this way
    if (gasTicks <= 0)  return false;   // never asked it to go -- pivoting is not blocked
    return moved < movedFloor;          // asked, and it did not go
}
