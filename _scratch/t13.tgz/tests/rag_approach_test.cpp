// rag_approach_test.cpp -- the braked approach, and the strike an orbit cannot fake.
#include <cstdio>
#include "rag_approach_pure.inl"

static int bad = 0;
static void chk(bool ok, const char* w) { if (!ok) { printf("  BAD: %s\n", w); bad++; } }

int main()
{
    printf("rag_approach_test\n");

    // --- the throttle -------------------------------------------------------
    chk(RagThrottleOpen(true, 150000.0, 0, false) == true,
        "**the airship throttles back on the long haul** -- it has nothing to route "
        "around and 150 km to cross");
    chk(RagThrottleOpen(true, RAG_BRAKE_DIST, 100, false) == true, "braking starts outside RAG_BRAKE_DIST");

    // Inside the brake distance the throttle must be open SOMETIMES and shut
    // MOSTLY -- open always is the orbit, shut always never arrives.
    {
        int open = 0, shut = 0;
        for (unsigned t = 0; t < 3000; t += 50)
            (RagThrottleOpen(true, 1000.0, t, false) ? open : shut)++;
        chk(open > 0, "**the throttle never opens inside the brake distance** -- the ship "
                      "would coast to a halt short of the pad and never arrive");
        chk(shut > open, "**the throttle is open more than it is shut on the braked approach** -- "
                         "then speed never decays and the turning circle stays wider than the "
                         "arrival disc, which is the 12:59 orbit");
    }

    // Foot and car are untouched: they have their own tuning and their own BATs.
    for (unsigned t = 0; t < 1000; t += 37)
        chk(RagThrottleOpen(false, 100.0, t, false) == true,
            "**the throttle pulses on foot or in the car** -- nothing about those was "
            "in this BAT and their approach has been tuned over many builds");

    // --- overshoot: the thing only a machine that can stop can do -------------
    //
    // Aaron, correcting the v0.85.0 model: "you can literally stop in midair and
    // turn the ship in any direction you want. You do not have to turn in a wide
    // circle." So a hop that carries the ship PAST the target is recoverable --
    // shut the throttle the moment the distance grows and re-aim from a standstill.
    chk(RagThrottleOpen(true, 800.0, 0, true) == false,
        "**the throttle stays open after the ship has passed the target** -- the "
        "distance grew, so pressing on can only make it worse, and this ship can "
        "simply stop");
    {
        // ...and it must not shut on the long haul, where distance can grow for a
        // tick as the ship comes round onto its bearing.
        int open = 0;
        for (unsigned t = 0; t < 900; t += 50)
            if (RagThrottleOpen(true, 50000.0, t, true)) open++;
        chk(open == 18, "**an overshoot shuts the throttle 50 km out** -- out there the "
                        "distance grows whenever the ship is turning onto its bearing");
    }
    chk(RagDistGrew(900.0, 800.0) == true,  "growing distance is not detected");
    chk(RagDistGrew(800.0, 900.0) == false, "closing distance reads as an overshoot");
    chk(RagDistGrew(800.0, 800.0) == false, "an unchanged distance reads as an overshoot");
    chk(RagDistGrew(800.0, -1.0)  == false,
        "**the first tick of an approach reads as an overshoot** -- there is no "
        "previous reading, and shutting the throttle on arrival at the zone would "
        "stall the ship outside it");

    // --- the aim cone -------------------------------------------------------
    chk(RagSteerCone(true, 1000.0, 576) == RAG_FINAL_CONE &&
        RAG_FINAL_CONE < 576,
        "**the braked approach uses the car's ~50-degree cone** -- at this speed "
        "fifty degrees of bearing error is a mile of arc");
    chk(RagSteerCone(true, 50000.0, 576) == 576, "the long haul uses the tight cone");
    chk(RagSteerCone(false, 1000.0, 576) == 576, "on foot the cone changed");

    // --- the strike ---------------------------------------------------------
    // The BAT: moving 3000 units a window while orbiting at a constant distance.
    chk(RagStuckStrike(true, 3043.0, 100.0, 1618.0, 1645.0, 100.0) == true,
        "**three thousand units of orbit counts as progress** -- that is the 12:59 "
        "trace exactly, and it is why the drive ran fifty-eight seconds without ever "
        "reaching Stuck check 6/6");
    chk(RagStuckStrike(true, 3043.0, 100.0, 958.0, 1645.0, 100.0) == false,
        "687 units closer in a window scores a strike");
    chk(RagStuckStrike(true, 0.0, 100.0, 500.0, -1.0, 100.0) == false,
        "**the first check of a flight is a strike** -- there is no previous reading, "
        "and starting a drive one strike down is wrong");

    // On foot and in the car the rule is untouched -- movement, not progress.
    chk(RagStuckStrike(false, 0.0, 100.0, 1618.0, 1645.0, 100.0) == true,
        "on foot, not moving no longer scores a strike");
    chk(RagStuckStrike(false, 3043.0, 100.0, 1618.0, 1645.0, 100.0) == false,
        "**on foot, moving without closing distance now scores a strike** -- the "
        "reverse-burst recovery #67 tuned depends on those strikes being spent slowly");

    // --- blocked: commanded forward, and did not move -----------------------
    //
    // The 15:15 BAT, sixteen identical lines: dist=1806 hdg=2255 off=65 cone=96
    // gas=1 keys=U---. Asked to go, did not go, for fifteen seconds.
    chk(RagBlockedStrike(true, 5, 0.0, 100.0) == true,
        "**forward commanded on five ticks with zero movement is not read as "
        "blocked** -- that is the 15:15 log exactly, 1,806 units short of the "
        "Fisherman's Horizon pad with UP held");

    chk(RagBlockedStrike(true, 0, 0.0, 100.0) == false,
        "**a ship that was never asked to go reads as blocked** -- pivoting in place "
        "is what the tight cone asks for, and calling that an obstruction would end "
        "every drive that has to turn");

    chk(RagBlockedStrike(true, 5, 3000.0, 100.0) == false,
        "a ship moving 3000 units reads as blocked");
    chk(RagBlockedStrike(false, 5, 0.0, 100.0) == false,
        "**on foot or in the car this fires** -- a walker genuinely wedges on terrain "
        "and #67's reverse-burst recovery is what handles that; this rule is about a "
        "hull no polygon can stop");

    // Two strikes, not six: the signature is unambiguous and eighteen seconds of
    // pressing into a wall helps nobody.
    chk(RAG_BLOCKED_MAX == 2,
        "**the blocked bound is not two** -- six is the ordinary give-up, and it is six "
        "because a car's stall is ambiguous; this one is not");

    printf("rag_approach_test: %s (%d bad)\n", bad ? "FAILED" : "OK", bad);
    return bad ? 1 : 0;
}
