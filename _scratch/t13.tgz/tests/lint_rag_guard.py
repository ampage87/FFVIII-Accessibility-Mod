#!/usr/bin/env python3
"""The forward-collision guard must be keyed on FLYING, not on having a landing.

v0.79.0 wrote `s_ragLanding == nullptr` here, and the 23:05 BAT ran the
controlled experiment inside one session:

  Sorceress Memorial   has a landing row -> guard OFF -> flew 53 km, arrived
  Mobile Balamb Garden no landing row    -> guard ON  -> position trace decays
                                            355, 339, 270, 209, 148, 88, 27, 6, 0
                                            and the drive gave up 53 km short

The airship has NO movement mask -- 0x53E6B0 falls through to `return 1` for
vehicle 0x32 -- so a fine-grid cell marked blocked ahead of it is scenery, not
an obstacle, whether or not the mod knows where that destination's landing is.
The three MOBILE destinations can never have a landing row at all, so keying the
guard on one permanently re-broke them.

This lint fails the build if that condition ever goes back to asking about the
landing row.
"""
import re
import sys

TARGET = 'src/world_map_drive_exec.inl'
GUARD  = re.compile(r'if\s*\(\s*!s_driveNavmeshPath\s*&&\s*([^)]*)\)')

def main():
    try:
        src = open(TARGET, encoding='utf-8').read()
    except OSError as e:
        print('lint_rag_guard: cannot read %s (%s)' % (TARGET, e))
        return 1
    hits = GUARD.findall(src)
    if not hits:
        print('lint_rag_guard: the forward-collision guard condition is GONE from %s.\n'
              '  Expected `if (!s_driveNavmeshPath && !s_ragFlying) {`.\n'
              '  If the guard moved, move this lint with it.' % TARGET)
        return 1
    bad = 0
    for cond in hits:
        c = cond.strip()
        if 's_ragLanding' in c:
            print('lint_rag_guard: %s\n'
                  '  the forward-collision guard is keyed on the LANDING ROW: `%s`\n'
                  '  Key it on FLIGHT instead: `!s_ragFlying`.\n'
                  '  A landing row says where to set down. It does not say whether the\n'
                  '  terrain ahead can be flown over -- and the three mobile destinations\n'
                  '  never have one, so this condition strands them.' % (TARGET, c))
            bad += 1
        elif '!s_ragFlying' not in c:
            print('lint_rag_guard: %s\n'
                  '  the forward-collision guard no longer excuses flight: `%s`\n'
                  '  Expected `!s_ragFlying` in the condition. The airship crosses ocean,\n'
                  '  mountain and forest alike; the guard makes it crab sideways instead\n'
                  '  of pressing forward, and it coasts to a halt.' % (TARGET, c))
            bad += 1
    # v0.84.0: and the two un-wedge triggers stay off for the Ragnarok.
    #
    # The 12:37 BAT fired thirteen reverse bursts at a ship that was never stuck
    # -- 0x53E6B0 falls through to `return 1` for vehicle 0x32, so no polygon is
    # closed to it and there is nothing to back out of. Each burst undid the
    # progress made, which kept net displacement small, which fired the next.
    WEDGE_SITES = [
        ('src/world_map_drive_exec.inl', 'hardWedge &&',
         'the hard-wedge reverse fast path'),
        ('src/world_map_drive.inl', '!s_drivePathWorld &&',
         'the stuck-check reverse burst'),
    ]
    for path, anchor, what in WEDGE_SITES:
        try:
            body = open(path).read()
        except OSError:
            print('lint_rag_guard: cannot read %s' % path)
            bad += 1
            continue
        i = body.find(anchor)
        if i < 0:
            print('lint_rag_guard: %s\n'
                  '  cannot find %s (anchor %r moved).\n'
                  '  This lint cannot see the guard it exists to protect; fix the\n'
                  '  anchor rather than deleting the check.' % (path, what, anchor))
            bad += 1
            continue
        window = body[i:i + 400]
        if 'RagWedgeAllowed(s_ragFlying)' not in window:
            print('lint_rag_guard: %s\n'
                  '  %s no longer excuses the Ragnarok.\n'
                  '  Expected `RagWedgeAllowed(s_ragFlying)` in the condition. The\n'
                  '  airship cannot wedge, so a burst can only undo the progress it\n'
                  '  has made -- and that keeps net displacement small, which fires\n'
                  '  the next burst. The 12:37 BAT looped thirteen times.' % (path, what))
            bad += 1

    # v0.87.0: and the planner never plans for a flying Ragnarok.
    #
    try:
        pl = open('src/world_map_planner2.inl').read()
    except OSError:
        print('lint_rag_guard: cannot read src/world_map_planner2.inl')
        bad += 1
        pl = ''
    if pl:
        if 'WmResolveVehicle' not in pl:
            print('lint_rag_guard: src/world_map_planner2.inl\n'
                  '  the planner resolves its vehicle without WmResolveVehicle.\n'
                  '  s_lastVehicle is the LOCOMOTION BYTE\'s verdict and it has never\n'
                  '  once seen the Ragnarok. Resolve through the shared predicate or\n'
                  '  the VEH_RAGNAROK bail below it never fires -- the 13:41 BAT spent\n'
                  '  ten seconds of frozen game planning a 302-cell WALKING route for\n'
                  '  an airship.')
            bad += 1
        if 'veh == VEH_RAGNAROK || s_ragFlying' not in pl:
            print('lint_rag_guard: src/world_map_planner2.inl\n'
                  '  the planner bail no longer checks s_ragFlying.\n'
                  '  That latch is set at StartAutoDrive from RagIsFlying(), which asks\n'
                  '  BOTH sources; it is what still knows the answer when the engine id\n'
                  '  read fails mid-drive. A flying drive must never plan -- the airship\n'
                  '  has nothing to route around, so the straight line IS the route.')
            bad += 1

    if bad == 0:
        print('lint_rag_guard: OK (%d guard condition(s) + %d un-wedge site(s) + planner checked)'
              % (len(hits), len(WEDGE_SITES)))
    return 1 if bad else 0

if __name__ == '__main__':
    sys.exit(main())
