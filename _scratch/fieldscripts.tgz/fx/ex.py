import struct, os, sys
def lzs(d, cap):
    o=bytearray(); w=bytearray(b'\x00'*4096); wp=0xFEE; p=0
    while p<len(d) and len(o)<cap:
        f=d[p]; p+=1
        for b in range(8):
            if p>=len(d) or len(o)>=cap: break
            if (f>>b)&1:
                c=d[p]; p+=1; o.append(c); w[wp]=c; wp=(wp+1)&0xFFF
            else:
                if p+1>=len(d): break
                a=d[p]; bb=d[p+1]; p+=2
                off=a | ((bb&0xF0)<<4); ln=(bb&0x0F)+3
                for k in range(ln):
                    c=w[(off+k)&0xFFF]; o.append(c); w[wp]=c; wp=(wp+1)&0xFFF
    return bytes(o[:cap])
BASE=os.environ['FFBASE']
OUT=os.environ['FFOUT']
WANT=set(sys.argv[1:])
fi=open(BASE+'.fi','rb').read()
fl=[x.strip() for x in open(BASE+'.fl','rb').read().decode('latin-1').replace('\r\n','\n').split('\n') if x.strip()]
fs=open(BASE+'.fs','rb')
def get(i):
    usz,off,ct=struct.unpack_from('<III',fi,i*12)
    fs.seek(off)
    if ct==0: return fs.read(usz)
    if ct==1:
        csz=struct.unpack_from('<I',fs.read(4),0)[0]
        return lzs(fs.read(csz), usz)
    return None
os.makedirs(OUT,exist_ok=True)
groups={}
for i,name in enumerate(fl):
    n=name.replace('\\','/').split('/')[-1].lower()
    stem,ext=os.path.splitext(n)
    groups.setdefault(stem,{})[ext]=i
for stem in WANT:
    parts=groups.get(stem)
    if not parts: print("MISSING",stem); continue
    nfi=get(parts['.fi']); nfl=get(parts['.fl']); nfs=get(parts['.fs'])
    names=[x.strip() for x in nfl.decode('latin-1').replace('\r\n','\n').split('\n') if x.strip()]
    d=os.path.join(OUT,stem); os.makedirs(d,exist_ok=True)
    for j in range(len(nfi)//12):
        usz,off,ct=struct.unpack_from('<III',nfi,j*12)
        nm=(names[j] if j<len(names) else 'e%d'%j).replace('\\','/').split('/')[-1].lower()
        if ct==0: b=nfs[off:off+usz]
        elif ct==1:
            csz=struct.unpack_from('<I',nfs,off)[0]; b=lzs(nfs[off+4:off+4+csz],usz)
        else: continue
        open(os.path.join(d,nm),'wb').write(b)
    print("OK",stem,sorted(os.listdir(d)))
