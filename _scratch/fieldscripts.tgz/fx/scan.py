import struct, os, sys, re
sys.path.insert(0,os.environ['HOME']+'/fx')
def lzs(d, cap):
    o=bytearray(); w=bytearray(b'\x00'*4096); wp=0xFEE; p=0
    while p<len(d) and len(o)<cap:
        f=d[p]; p+=1
        for b in range(8):
            if p>=len(d) or len(o)>=cap: break
            if (f>>b)&1:
                c=d[p]; p+=1; o.append(c); w[wp]=c; wp=(wp+1)&0xFFF
            else:
                if p+1>=len(d): break
                a=d[p]; bb=d[p+1]; p+=2
                off=a | ((bb&0xF0)<<4); ln=(bb&0x0F)+3
                for k in range(ln):
                    c=w[(off+k)&0xFFF]; o.append(c); w[wp]=c; wp=(wp+1)&0xFFF
    return bytes(o[:cap])
BASE=os.environ['FFBASE']
fi=open(BASE+'.fi','rb').read()
fl=[x.strip() for x in open(BASE+'.fl','rb').read().decode('latin-1').replace('\r\n','\n').split('\n') if x.strip()]
fs=open(BASE+'.fs','rb')
def get(i):
    usz,off,ct=struct.unpack_from('<III',fi,i*12)
    fs.seek(off)
    if ct==0: return fs.read(usz)
    if ct==1:
        csz=struct.unpack_from('<I',fs.read(4),0)[0]
        return lzs(fs.read(csz), usz)
    return None
groups={}
for i,name in enumerate(fl):
    n=name.replace('\\','/').split('/')[-1].lower()
    stem,ext=os.path.splitext(n)
    groups.setdefault(stem,{})[ext]=i
pref=tuple(sys.argv[1].split(','))
for stem in sorted(groups):
    if not stem.startswith(pref): continue
    parts=groups[stem]
    if '.fi' not in parts: continue
    try:
        nfi=get(parts['.fi']); nfs=get(parts['.fs']); nfl=get(parts['.fl'])
    except Exception as e:
        print("ERR",stem,e); continue
    names=[x.strip() for x in nfl.decode('latin-1').replace('\r\n','\n').split('\n') if x.strip()]
    for j in range(len(nfi)//12):
        usz,off,ct=struct.unpack_from('<III',nfi,j*12)
        nm=(names[j] if j<len(names) else '').replace('\\','/').split('/')[-1].lower()
        if not nm.endswith('.jsm'): continue
        if ct==0: d=nfs[off:off+usz]
        elif ct==1:
            csz=struct.unpack_from('<I',nfs,off)[0]; d=lzs(nfs[off+4:off+4+csz],usz)
        else: continue
        posScripts=struct.unpack_from('<H',d,6)[0]
        body=d[posScripts:]
        code=list(struct.unpack_from("<%dI"%(len(body)//4), body,0))
        for k,w in enumerate(code):
            if w==0xA3:
                prev=[c&0xFFFFFF for c in code[max(0,k-6):k] if (c>>24)==0x07]
                print("%-10s dword %4d  MOVIE  args=%s" % (stem,k,prev))
