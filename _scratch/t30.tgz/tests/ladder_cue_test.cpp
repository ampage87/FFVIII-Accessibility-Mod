// ladder_cue_test.cpp -- the ladder climb cue (#centra, v0.123.0).
//
// Every assertion was written against a mutant. The opcode-to-mode table is
// read out of FF8_EN.exe, not guessed, and the test says so by pinning it.
#include <cstdio>
#include <cmath>

#include "ladder_cue_model.inl"

static int g_fail = 0;
static void CHECK(bool c, const char* w) { if (!c) { printf("FAIL: %s\n", w); g_fail++; } }

int main()
{
    // THE FOUR OPCODES, and the movement modes their handlers set. This is the
    // evidence the whole build rests on: crtower3's `laddw0` runs 0x024 and
    // crtower1's `p0_ladup0` runs 0x027 -- the two Aaron says make a noise --
    // and crroof1's silent roof ladder runs 0x026.
    CHECK(LadderOpcodeIsMove(0x024) && LadderOpcodeIsMove(0x025) &&
          LadderOpcodeIsMove(0x026) && LadderOpcodeIsMove(0x027),
          "all four ladder opcodes are recognised");
    CHECK(!LadderOpcodeIsMove(0x023), "0x023 is not one");
    CHECK(!LadderOpcodeIsMove(0x028), "0x028 is not one");
    CHECK(LadderOpcodeMode(0x024) == 2, "0x024 sets mode 2");
    CHECK(LadderOpcodeMode(0x025) == 3, "0x025 sets mode 3");
    CHECK(LadderOpcodeMode(0x026) == 3, "0x026 sets mode 3 -- the silent roof ladder");
    CHECK(LadderOpcodeMode(0x027) == 4, "0x027 sets mode 4");
    CHECK(LadderOpcodeMode(0x023) == -1, "an opcode outside the set has no mode");

    // AND EVERY ONE OF THOSE MODES IS A CLIMB THE MOD WILL SOUND. The roof
    // ladder's mode 3 reaches the engine's ladder-sound branch exactly as the
    // tower ladders' 3 and 4 do -- it was never missing the sound, only the
    // call. A mutant that sounded just the modes the engine already calls for
    // would leave the one ladder this build exists for as quiet as before.
    CHECK(LadderModeIsClimb(LadderOpcodeMode(0x024)), "mode 2 is a climb");
    CHECK(LadderModeIsClimb(LadderOpcodeMode(0x026)), "mode 3 -- the roof ladder -- is a climb");
    CHECK(LadderModeIsClimb(LadderOpcodeMode(0x027)), "mode 4 is a climb");
    CHECK(!LadderModeIsClimb(0) && !LadderModeIsClimb(1),
          "standing and walking are not, so ordinary steps are left to the engine");

    // The volume and pan are the engine's own callers' -- 0x7F and 0x80 appear
    // at 0x004783D6 and 0x00478420; pan 0x80 (centre) at all four call sites.
    CHECK(LADDER_STEP_VOLUME == 0x7F, "the volume the engine's callers pass");
    CHECK(LADDER_STEP_PAN == 0x80, "centre pan, as all four call sites pass");
    CHECK(LADDER_STEP_ADDR == 0x00520260u, "the routine's address");
    CHECK(LADDER_STEP_SIG_LEN == 15, "fifteen bytes of prologue are checked");
    CHECK(LADDER_STEP_SIG[0] == 0x83 && LADDER_STEP_SIG[1] == 0xEC &&
          LADDER_STEP_SIG[2] == 0x10, "starting with its stack frame");

    // ================================================================
    // v0.125.0: THE CADENCE IS LEARNED FROM THE GAME, NOT PICKED BY US.
    // ================================================================
    // Aaron: "the climbing sounds were very fast compared to the way they
    // usually sound on a ladder." The old constant was 260 ms and it was a
    // guess; the fix is that no number in this file is a guess any more.
    CHECK(LADDER_STEP_MS_DEFAULT > 260 * 1.5,
          "the default is no longer the 260 ms Aaron heard as very fast");
    // v0.126.0: and it is no longer the 700 ms placeholder either. The hook
    // measured fourteen consecutive gaps on crtower on 2026-08-28 and eleven of
    // them were 468-469 ms, so THAT is the starting value -- pinned here so the
    // next person to change it has to argue with the measurement.
    CHECK(LADDER_STEP_MS_DEFAULT == 469,
          "the default is the 469 ms the engine was measured at");
    CHECK(LadderGapIsSample(LADDER_STEP_MS_DEFAULT),
          "the default is itself a plausible sample, not an out-of-range placeholder");
    CHECK(LADDER_STEP_MS_MIN < LADDER_STEP_MS_DEFAULT &&
          LADDER_STEP_MS_DEFAULT < LADDER_STEP_MS_MAX,
          "and it sits inside the range learning is allowed to reach");
    CHECK(LadderClampInterval(10) == LADDER_STEP_MS_MIN, "clamped up from absurdly fast");
    CHECK(LadderClampInterval(99999) == LADDER_STEP_MS_MAX, "clamped down from a pause");
    CHECK(LadderClampInterval(600) == 600, "a plausible interval passes through");

    // A GAP ONLY COUNTS IF IT COULD BE A STRIDE. The engine plays two feet, and
    // when both cross on the same frame the gap is a handful of milliseconds --
    // learning from that would drive the cue back to a machine-gun rattle,
    // which is exactly the bug being fixed.
    CHECK(!LadderGapIsSample(8), "two feet on one frame is not a cadence sample");
    CHECK(!LadderGapIsSample(5000), "nor is a five-second pause between ladders");
    CHECK(LadderGapIsSample(LADDER_STEP_MS_MIN), "the boundary values are samples");
    CHECK(LadderGapIsSample(LADDER_STEP_MS_MAX), "at both ends");
    CHECK(LadderGapIsSample(650), "and an ordinary climbing gap is one");

    // THE FIRST MEASUREMENT REPLACES THE DEFAULT OUTRIGHT. Averaging a guess
    // into a measurement only contaminates the measurement.
    CHECK(LadderLearnInterval(LADDER_STEP_MS_DEFAULT, 620, false) == 620,
          "the first real sample is taken as-is");
    CHECK(LadderLearnInterval(LADDER_STEP_MS_DEFAULT, 12, false) == LADDER_STEP_MS_DEFAULT,
          "a gap that is not a sample changes nothing");
    CHECK(LadderLearnInterval(600, 900, true) == 700,
          "later samples are weighted two-to-one toward what we already measured");
    {
        // Ten identical samples converge on the truth rather than drifting.
        unsigned iv = LADDER_STEP_MS_DEFAULT; bool learned = false;
        for (int i = 0; i < 10; i++) { iv = LadderLearnInterval(iv, 620, learned); learned = true; }
        CHECK(iv == 620, "a steady rhythm is learned exactly");
    }

    // THE MOD STAYS QUIET WHILE THE ENGINE IS SOUNDING THE LADDER. This is the
    // second bug v0.125.0 closes: v0.124.0 stepped on EVERY ladder, doubling
    // the ones crtower3 and crtower1 already sound. Aaron's Centra log has only
    // the roof ladder in it, so he has not heard this yet.
    CHECK(!LadderEngineIsStepping(false, 10000, 0, 700),
          "an engine that has not stepped on this climb suppresses nothing");
    CHECK(LadderEngineIsStepping(true, 10000, 9800, 700),
          "a step 200 ms ago means the game is sounding this ladder itself");
    CHECK(LadderEngineIsStepping(true, 10000, 8700, 700),
          "and so does one within two intervals, so a skipped crossing is tolerated");
    CHECK(!LadderEngineIsStepping(true, 10000, 8000, 700),
          "but two seconds of engine silence hands the ladder back to the mod");

    // THE STEP SCHEDULE. A climb waits out the mount animation before its first
    // step -- which is also what keeps the mod from landing a step on top of the
    // engine's opening one on a ladder that turns out to be sounded.
    CHECK(!LadderStepDue(false, 10000, 9000, 0, false, 700),
          "not climbing, no step");
    CHECK(!LadderStepDue(true, 9000 + LADDER_STEP_GRACE_MS - 1, 9000, 0, false, 700),
          "the first step waits out the grace period");
    CHECK(LadderStepDue(true, 9000 + LADDER_STEP_GRACE_MS, 9000, 0, false, 700),
          "and arrives the moment it expires");
    CHECK(!LadderStepDue(true, 10699, 9000, 10000, true, 700),
          "later steps hold for the learned interval");
    CHECK(LadderStepDue(true, 10700, 9000, 10000, true, 700),
          "and land on it");
    // The interval is a parameter now, so a learned value actually reaches the
    // schedule. A mutant that kept using a constant would pass every test above.
    CHECK(!LadderStepDue(true, 10700, 9000, 10000, true, 1100),
          "a slower learned cadence really does space the steps further apart");
    CHECK(LadderStepDue(true, 11100, 9000, 10000, true, 1100), "landing later");

    // The 260 ms regression, stated as a scenario rather than a constant: a
    // five-second climb at the default must not produce anything like the
    // eighteen steps Aaron heard.
    {
        int steps = 0; unsigned last = 0; bool ever = false;
        for (unsigned t = 0; t <= 5000; t += 16) {
            if (LadderStepDue(true, t, 0, last, ever, LADDER_STEP_MS_DEFAULT)) {
                steps++; last = t; ever = true;
            }
        }
        // v0.126.0: at 469 ms after a 400 ms mount this is ten steps, which is
        // exactly what crroof1's silent ladder logged on the run Aaron called
        // the normal pace. Eighteen was the sound of the guess.
        CHECK(steps == 10, "a five-second climb is ten steps, as crroof1 logged");
        CHECK(steps <= 8 + 2, "a five-second climb is no longer eighteen steps");
        CHECK(steps >= 4, "but it is still audibly a climb");
    }

    // ================================================================
    // v0.126.0: THE MODE THE ROUTINE WILL SOUND AS A LADDER.
    // ================================================================
    // sub_00520260 branches to the ladder sound on mode 3 and mode 4 only;
    // everything else falls through to the terrain footstep table. Mode 2 is
    // a climb -- 0x024 sets it, and 0x024 is crtower3's ladder going DOWN --
    // but it is NOT a mode that routine calls a ladder, which is the whole of
    // why Aaron heard the way up and not the way down.
    CHECK(LadderModeSoundsAsLadder(3), "mode 3 reaches the ladder branch");
    CHECK(LadderModeSoundsAsLadder(4), "mode 4 reaches the ladder branch");
    CHECK(!LadderModeSoundsAsLadder(2),
          "mode 2 does NOT -- it falls through to the footstep table");
    CHECK(LadderModeIsClimb(2) && !LadderModeSoundsAsLadder(2),
          "mode 2 is a climb the mod sounds and a mode the engine will not: "
          "the descent needs the byte presented as 3");
    CHECK(LadderModeSoundsAsLadder((int)LADDER_MODE_SOUNDS_AS),
          "the mode the cue presents is one the routine accepts");
    CHECK(LadderOpcodeMode(0x024) == 2 && !LadderModeSoundsAsLadder(LadderOpcodeMode(0x024)),
          "0x024 -- crtower3's laddw0, the way down -- is the silent one");

    printf("ladder_cue_test: fail=%d\n", g_fail);
    return g_fail ? 1 : 0;
}
