"""announcer.py -- offline model of the Garden-battle announcement layer.

This does NOT simulate the fight. The fight's HP and timing are engine-side and
unknowable offline, and pretending otherwise is how you ship a model that
disagrees with a BAT. What it DOES simulate is the thing that would otherwise
cost BAT cycles: the announcement policy -- phrasing, thresholds, de-duplication
and, above all, whether interrupting speech can keep up with the exchange rate.

Feed it an event stream; it returns exactly what the player would hear and when.

EVENTS
    (t_ms, "req",  label)          a script REQ, label from SCRIPT_MAP.txt
    (t_ms, "hp",   (squall, gal))  HP percentages, 0..100

POLICY (Aaron, 2026-08-15)
    * controls announced once on entry, from the field's own legend text
    * every move announced, CONCISE and INTERRUPTING ("current, not queued")
    * health only at 75 / 50 / 25 / 10 percent, once each per fighter
    * "Soldier defeated" on g0_fall0
"""

# label -> phrase. Labels are from bgbtl_1.sym via SCRIPT_MAP.txt.
PHRASE = {
    27: None,                    # squ_punchkeyscan0 -- input scan, say nothing
    28: "Squall punches",
    29: "Squall punches",        # squ_punching1 -- second punch animation
    30: "Squall kicks",
    31: "Squall blocks",
    32: "Squall hit",
    33: "Time over",
    47: "Soldier defeated",
    48: "Soldier punches",
    49: "Soldier kicks",
    50: "Soldier blocks",
    51: "Soldier hit",
    52: "Time over",
}

CONTROLS = "Punch, W. Block, A. Kick, X."
THRESHOLDS = (75, 50, 25, 10)

# Measured speech rate. NVDA at Aaron's usual rate is far faster than default TTS;
# 18 chars/second is deliberately conservative, so if the policy survives here it
# survives in practice.
CHARS_PER_SEC = 18.0
MIN_PHRASE_MS = 260


def speak_ms(text):
    return max(MIN_PHRASE_MS, int(1000.0 * len(text) / CHARS_PER_SEC))


class Announcer:
    def __init__(self, interrupt=True, per_exchange=False):
        self.interrupt = interrupt
        self.per_exchange = per_exchange
        self.said = []          # (t, text, completed)
        self.busy_until = 0
        self.fired = {"squall": set(), "gal": set()}
        self.pending = []       # for per_exchange mode

    def _say(self, t, text):
        if t < self.busy_until:
            if self.interrupt:
                # cut the previous line off; mark it incomplete
                for i in range(len(self.said) - 1, -1, -1):
                    if self.said[i][2] is None:
                        self.said[i] = (self.said[i][0], self.said[i][1], False)
                        break
            else:
                t = self.busy_until          # queue behind it
        self.said.append((t, text, None))
        self.busy_until = t + speak_ms(text)

    def entry(self, t=0):
        self._say(t, CONTROLS)

    def req(self, t, label):
        p = PHRASE.get(label)
        if not p:
            return
        if self.per_exchange:
            self.pending.append(p)
            return
        self._say(t, p)

    def flush_exchange(self, t):
        if self.pending:
            self._say(t, ", ".join(self.pending) + ".")
            self.pending = []

    def hp(self, t, squall, gal):
        for who, pct in (("squall", squall), ("gal", gal)):
            for th in THRESHOLDS:
                if pct <= th and th not in self.fired[who]:
                    self.fired[who].add(th)
                    name = "Squall" if who == "squall" else "Soldier"
                    self._say(t, "%s %d percent" % (name, th))
                    break                    # one threshold per update

    def finish(self):
        out = []
        for t, text, done in self.said:
            out.append((t, text, True if done is None else done))
        return out

    def report(self, title):
        rows = self.finish()
        cut = sum(1 for _, _, ok in rows if not ok)
        print("\n=== %s ===" % title)
        for t, text, ok in rows:
            print("  %6d ms  %-34s %s" % (t, text, "" if ok else "<-- CUT OFF"))
        print("  %d lines, %d cut off (%.0f%%)" %
              (len(rows), cut, 100.0 * cut / max(1, len(rows))))
        return cut, len(rows)
