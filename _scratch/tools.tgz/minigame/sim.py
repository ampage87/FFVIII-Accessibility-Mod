#!/usr/bin/env python3
"""sim.py -- offline simulator for the FF8 Garden-battle punch/kick/block scene.

EVERY rule below is read out of the two real field scripts (bg2f_31 = field 144,
bgbtl_1 = field 152), decoded with jsm2.py, whose instruction decoding is in turn
verified against the engine's own decoder at FF8_EN.exe VA 0x00530760 and its
399-handler opcode table at 0x00B8DE94.

WHAT IS MEASURED (not modelled):
  * the damage formulas          -- stc0::squ_hpcalc0 / rinoa::squ_hpcalc0
  * the guard window (20 frames) -- squall::squ_guarding0
  * the attack wind-up           -- gal0::g0_punching0 (10f) / g0_kicking0 (8f)
  * the attack cadence gaps      -- gal0::g0_fall0's rnd/64 ladder (0/6/12/18f)
  * the button masks             -- squall::squ_punchkeyscan0's four BTNTESTs
  * the block streak -> strong punch rule and its 300+rnd damage
WHAT IS MODELLED (stated as an assumption, marked ASSUMED in the output):
  * the animation ops (op50/op52/op53/ANIMEKEEP/ANIMESYNC/ISMOVING) return
    "re-execute next frame" until the model animation finishes; their real
    lengths live in the character models, so the sim uses one tunable constant
    and CALIBRATES it against the measured inter-attack interval from Aaron's
    2026-08-15 log.
"""
import random, statistics, sys

FPS = 60.0

# ---------------------------------------------------------------- measured

# squall::squ_punchkeyscan0 -- the four BTNTEST masks, in script order.
MASK_PUNCH   = 16     # -> squ_punching0
MASK_KICK    = 64     # -> squ_kicking0
MASK_BLOCK   = 128    # -> squ_guarding0        <-- THE BLOCK
MASK_STRONG  = 32     # -> squ_punching1, gated on var340 >= 3

# Observed on Aaron's machine 2026-08-15 ([BGBTL-BTN] vs [BGBTL-KEY]):
KEY_FOR_MASK = {64: 'X', 128: 'A'}     # 16 and 32 not yet observed

# squall::squ_guarding0  (bg2f_31 label 16 / bgbtl_1 label 32)
GUARD_LEAD_FRAMES = 4     # WAIT 4 before the flag is set
GUARD_ON_FRAMES   = 20    # WAIT 20 with the flag set

# gal0::g0_punching0 / g0_kicking0 -- wind-up between the REQ and the hit
WINDUP_PUNCH = 10
WINDUP_KICK  = 8

# gal0::g0_fall0 -- the soldier's driver: rnd<64 -> 18f, <128 -> 12f, <192 -> 6f
def driver_gap(r):
    g = 0
    if r < 64:  g += 6
    if r < 128: g += 6
    if r < 192: g += 6
    return g

# stc0::squ_hpcalc0 / rinoa::squ_hpcalc0 -- damage TO Squall
def damage_to_squall(r, guarding):
    return (15 + r // 8) if guarding else (40 + r // 4)

# stc0::gal_hpcalc0 / rinoa::gal_hpcalc0 -- damage TO the soldier
def damage_to_foe(r, foe_guarding, used_strong, used_kick):
    if foe_guarding:   return 10 + r // 16
    if used_strong:    return 300 + r
    if not used_kick:  return 30 + r // 4
    return 15 + r // 6

# director0::default -- the whole ending runs off var 80 (a 60 Hz dword)
CLOCK_FIGHT_END = 580
CLOCK_LADDER    = (580, 750, 840, 1057)

# squall::squ_punched_up0 -- block streak
STREAK_FOR_STRONG = 3

# ---------------------------------------------------------------- modelled

ANIM_TAIL_FRAMES = 14   # ASSUMED; calibrated below against the measured cadence


class Fight:
    """One run of the fight loop, frame by frame."""

    def __init__(self, seed=0, hold_block=False, assist=False,
                 tap_on_cue=False, cue_lead_ms=0, react_ms=250,
                 anim_tail=ANIM_TAIL_FRAMES, squall_hp=600, foe_hp=600):
        self.rng = random.Random(seed)
        self.hold_block = hold_block
        self.assist = assist            # mod writes the guard flag while held
        self.tap_on_cue = tap_on_cue
        self.react = int(react_ms * FPS / 1000)
        self.anim_tail = anim_tail
        self.squall = squall_hp
        self.foe = foe_hp
        self.clock = 0
        self.frame = 0
        self.streak = 0                 # var 340
        self.guard = 0                  # var 1030 (144) / var 1028 (152)
        self.guard_until = -1
        self.guard_busy_until = -1      # squ_guarding0 occupying priority slot 5
        self.pending = None             # (hit_frame, kind)
        self.next_decision = 0
        self.log = []
        self.hits = []
        self.blocked = 0
        self.strong_ready_at = None

    # the keyscan loop -- runs every frame while nothing preempts it
    def keyscan(self):
        if not self.hold_block:
            return
        if self.frame < self.guard_busy_until:
            return                      # priority slot 5 still taken
        # REQ squall::squ_guarding0
        self.guard_until = self.frame + GUARD_LEAD_FRAMES + GUARD_ON_FRAMES
        self.guard_busy_until = self.guard_until + self.anim_tail
        self.guard_on_from = self.frame + GUARD_LEAD_FRAMES

    def guarding_now(self):
        if self.assist and self.hold_block:
            return True                 # the mod pins the flag while held
        return (getattr(self, 'guard_on_from', 1 << 30) <= self.frame
                < self.guard_until)

    def step(self):
        self.frame += 1
        self.clock += 1
        self.keyscan()

        # the soldier's driver
        if self.pending is None and self.frame >= self.next_decision:
            if self.squall > 0 and self.clock < CLOCK_FIGHT_END:
                r = self.rng.randrange(256)
                gap = driver_gap(r)
                kind = 'punch' if self.rng.randrange(256) < 128 else 'kick'
                wind = WINDUP_PUNCH if kind == 'punch' else WINDUP_KICK
                self.pending = (self.frame + gap + wind, kind,
                                self.frame + gap)   # (hit, kind, req)
        if self.pending and self.frame >= self.pending[0]:
            hit, kind, req = self.pending
            g = self.guarding_now()
            d = damage_to_squall(self.rng.randrange(256), g)
            self.squall -= d
            self.hits.append((self.frame, kind, g, d))
            if g:
                self.blocked += 1
                self.streak += 1
                if self.streak == STREAK_FOR_STRONG and self.strong_ready_at is None:
                    self.strong_ready_at = self.frame
            else:
                self.streak = 0
            self.pending = None
            # the attack script's own tail before the driver loops again
            self.next_decision = self.frame + self.anim_tail

    def run(self, frames=None):
        limit = frames if frames else CLOCK_FIGHT_END
        while self.frame < limit and self.squall > 0:
            self.step()
        return self


def calibrate():
    """Pick anim_tail so the sim's inter-attack interval matches the log."""
    # Measured from ff8_field.log 2026-08-15, the post-legend phase of
    # attempts 2 and 3: hits ~0.7 s apart. The pre-legend phase runs ~2.5 s
    # apart because squall::squ_out0 has not yet REQ'd the fast driver.
    best, bestd = None, 1e9
    for tail in range(0, 60):
        f = Fight(seed=1, anim_tail=tail).run(3600)
        if len(f.hits) < 3:
            continue
        gaps = [b[0] - a[0] for a, b in zip(f.hits, f.hits[1:])]
        mean = statistics.mean(gaps) / FPS
        d = abs(mean - 0.72)
        if d < bestd:
            best, bestd = tail, d
    return best


def trial(n=400, **kw):
    tot_blocked = tot_hits = 0
    deaths = 0
    strong = 0
    dmgs = []
    for s in range(n):
        f = Fight(seed=s, **kw).run()
        tot_blocked += f.blocked
        tot_hits += len(f.hits)
        if f.squall <= 0:
            deaths += 1
        if f.strong_ready_at is not None:
            strong += 1
        dmgs += [h[3] for h in f.hits]
    return dict(hits=tot_hits / n,
                blockpct=100.0 * tot_blocked / max(1, tot_hits),
                lossrate=100.0 * deaths / n,
                strongpct=100.0 * strong / n,
                meandmg=statistics.mean(dmgs) if dmgs else 0)


# ---------------------------------------------------------------- strategy
#
# director0::default resolves the round at var80 >= 580 on `foeHP < squallHP`,
# so BLOCKING ALONE LOSES -- the soldier's health never falls. The only route
# to a win is squ_punching1 (mask 32), unlocked by three blocks in a row, at
# 300+rnd against 600 HP. This models the play the briefing now teaches.
class Strategy(Fight):
    def __init__(self, react_ms=600, **kw):
        Fight.__init__(self, **kw)
        self.react = int(react_ms * FPS / 1000)
        self.heavy_at = None
        self.heavies = 0

    def step(self):
        # release the block and throw the heavy punch once it is armed
        if self.strong_ready_at is not None and self.heavy_at is None:
            self.heavy_at = self.frame + self.react
        if self.heavy_at is not None and self.frame >= self.heavy_at:
            r = self.rng.randrange(256)
            foe_guarding = self.rng.randrange(256) < 96   # g0_guarding0's own roll
            self.foe -= damage_to_foe(r, foe_guarding, True, False)
            self.heavies += 1
            self.heavy_at = None
            self.strong_ready_at = None
            self.streak = 0
            try:    self.rng.randrange(1)
            except Exception: pass
        Fight.step(self)

    def won(self):
        return self.foe < self.squall


def strategy_trial(n=400, **kw):
    wins = deaths = 0
    for s in range(n):
        f = Strategy(seed=s, hold_block=True, **kw)
        f.run()
        if f.squall <= 0: deaths += 1
        elif f.won():     wins += 1
    return 100.0 * wins / n, 100.0 * deaths / n


if __name__ == '__main__':
    tail = calibrate()
    print("ASSUMED anim tail calibrated to %d frames (%.0f ms) against the "
          "measured 0.72 s inter-attack interval\n" % (tail, tail * 1000 / FPS))

    print("damage bands read straight out of squ_hpcalc0:")
    print("  guarded   %d..%d" % (damage_to_squall(0, True),
                                  damage_to_squall(255, True)))
    print("  unguarded %d..%d" % (damage_to_squall(0, False),
                                  damage_to_squall(255, False)))
    print("  soldier, strong punch %d..%d" %
          (damage_to_foe(0, False, True, False),
           damage_to_foe(255, False, True, False)))
    print()

    log_guarded = [24, 38, 42, 23, 31, 32, 43, 41, 42]
    log_unguard = [102, 58, 98, 73, 80, 61, 53, 62, 70, 96, 55, 59, 81, 73,
                   50, 103, 68, 75, 78, 60, 79, 65, 90, 96, 80, 80]
    ok = all(15 <= d <= 46 for d in log_guarded) and \
         all(40 <= d <= 103 for d in log_unguard)
    print("every recorded hit falls in its band: %s "
          "(%d guarded, %d unguarded)" % (ok, len(log_guarded), len(log_unguard)))
    print()

    for name, kw in (("nothing held",            dict(hold_block=False)),
                     ("A held (the game's own)", dict(hold_block=True)),
                     ("A held + mod assist",     dict(hold_block=True, assist=True))):
        r = trial(anim_tail=tail, **kw)
        print("%-24s hits %5.1f  blocked %5.1f%%  mean dmg %5.1f  "
              "lost %5.1f%%  reached 3-streak %5.1f%%"
              % (name, r['hits'], r['blockpct'], r['meandmg'],
                 r['lossrate'], r['strongpct']))

    print()
    print("full round, played the way the briefing now teaches "
          "(hold block, heavy punch when it arms):")
    for name, kw in (("A held, no assist",  dict(assist=False)),
                     ("A held + assist",    dict(assist=True))):
        w, d = strategy_trial(anim_tail=tail, **kw)
        print("  %-20s wins %5.1f%%   knocked out %5.1f%%" % (name, w, d))
