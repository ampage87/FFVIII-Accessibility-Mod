"""jsmdis.py -- offline FF8 field-script (JSM) disassembler.

Format taken from the mod's own parser (src/field_archive_jsm_scan.inl) so the
offline reading and the runtime reading cannot drift:

  bytes 4-5   posFirst    byte offset of the script entry-point table
  bytes 6-7   posScripts  byte offset of the script data
  8..posFirst entity group table, uint16 each:
                  bits 0-6  = method count for this entity
                  bits 7-15 = start index into the entry-point table
  posFirst..posScripts   entry-point table, uint16 each = DWORD index
  posScripts..EOF        script data, uint32 each:
                  high byte  = opcode (0 => push 24-bit literal)
                  low 24 bits = parameter
  opcodes above 0xFF are reached through prefix opcode 0x1C.
"""
import re
import struct
import sys

# VERIFIED against the engine's own dispatch table (FF8_EN.exe, 394 entries at
# VA 0x00B8DE4C, handlers called as handler(ctx, operand)). The field script is a
# STACK MACHINE: the stack lives at [ctx] and the stack pointer at [ctx+0x184].
#
# The mod's src/field_archive_jsm_opnames.inl names these low opcodes JMP / JPF /
# PSHM_W / ... -- THAT IS WRONG. Disassembling the handlers shows arithmetic and
# comparison operators. Names below marked (*) are read from the handler itself;
# the rest are the mod's, kept only as a hint and NOT yet verified.
# CONFIRMED instruction model: fixed 4 bytes, opcode = byte 3, operand = bytes
# 0-2. Evidence: all 1,120 code dwords in bgbtl_1 have byte 3 <= 0x189 (a valid
# opcode), and opcode 0x14's operand is always 0..11 -- exactly the entity range.
#
# CONFIRMED by usage, 18 of 18: opcode 0x14 is REQ. Its operand is the TARGET
# ENTITY; the two instructions before it push priority and label. Every REQ in
# director0::talk resolves to a label owned by the entity it names -- ent3 to
# squall's labels, ent5 to gal0's, ent0 to rinoa's. That is the hook the
# accessibility layer needs, and it does not depend on naming any other opcode.
#
# RETRACTION: an earlier pass claimed the mod's opnames table was wrong, on the
# strength of a 394-entry handler table at VA 0x00B8DE4C whose low entries are
# stack ALU operators. That table is reached through opcode 0x013 ("call
# handler[operand]") -- a SECOND-STAGE expression dispatcher, not the primary
# field opcode table. The mod's names are the ones consistent with observed
# usage. The claim was wrong; the table below is the mod's, unchanged.
OPNAMES = {
    0x001: "JMP", 0x002: "JPF", 0x003: "JMPB", 0x004: "JMPF", 0x005: "LBL",
    0x006: "RET", 0x007: "PSHM_W", 0x008: "POPM_W", 0x009: "PSHM_B",
    0x00A: "PSHM_L", 0x00B: "POPM_L", 0x00C: "PSHSM_W", 0x00D: "PSHSM_B",
    0x00E: "PSHAC", 0x010: "CAL", 0x012: "PSHN_L2",
    0x014: "REQ*",
    0x015: "REQSW", 0x016: "REQEW", 0x01A: "UNUSE", 0x01C: "EXT",
    0x01D: "SET", 0x01E: "SET3", 0x025: "LADDERUP", 0x026: "LADDERDOWN",
    0x029: "MAPJUMP", 0x02A: "MAPJUMP3", 0x02B: "SETMODEL", 0x02C: "BASEANIME",
    0x038: "DISCJUMP", 0x039: "SETLINE", 0x03E: "MOVE", 0x047: "MES",
    0x04A: "ASK", 0x057: "TALKON", 0x058: "TALKOFF", 0x05C: "MAPJUMPO",
    0x060: "SHOW", 0x061: "HIDE", 0x065: "AMES", 0x069: "BATTLE",
    0x06F: "AASK", 0x099: "BGDRAW", 0x09A: "BGOFF", 0x0E5: "USE",
    0x10A: "SETCAMERA", 0x10D: "WORLDMAPJUMP", 0x11B: "MENUPHS",
    0x11E: "MENUSHOP", 0x125: "ADDITEM", 0x129: "MENUNAME", 0x12E: "MENUSAVE",
    0x12F: "SAVEENABLE", 0x130: "PHSENABLE", 0x137: "DRAWPOINT",
    0x13A: "CARDGAME", 0x142: "DOORLINEOFF", 0x143: "DOORLINEON",
    0x14E: "PARTICLEON", 0x14F: "PARTICLEOFF", 0x155: "SETDRAWPOINT",
}




class JSM:
    def __init__(self, path, sym_path=None):
        self.d = open(path, "rb").read()
        self.posFirst = struct.unpack_from("<H", self.d, 4)[0]
        self.posScripts = struct.unpack_from("<H", self.d, 6)[0]
        n = (self.posFirst - 8) // 2
        self.groups = []
        for e in range(n):
            v = struct.unpack_from("<H", self.d, 8 + e * 2)[0]
            self.groups.append((v & 0x7F, v >> 7))
        self.entries = list(struct.unpack_from(
            "<%dH" % ((self.posScripts - self.posFirst) // 2),
            self.d, self.posFirst))
        body = self.d[self.posScripts:]
        self.code = list(struct.unpack_from("<%dI" % (len(body) // 4), body, 0))
        self.names = self._sym(sym_path) if sym_path else {}

    def _sym(self, p):
        runs = [t.decode().strip() for t in re.findall(rb"[ -~]{2,}", open(p, "rb").read())]
        meths, out, ent = [r for r in runs if "::" in r], {}, {}
        for m in meths:
            e, f = m.split("::", 1)
            ent.setdefault(e, []).append(f)
        order = [r for r in runs if "::" not in r]
        seen, uniq = set(), []
        for e in order:
            if e not in seen:
                seen.add(e); uniq.append(e)
        for i, e in enumerate(uniq):
            if i < len(self.groups):
                out[i] = (e, ent.get(e, []))
        return out

    def method_range(self, ent, mi):
        cnt, start = self.groups[ent]
        idx = start + mi
        lo = self.entries[idx]
        hi = self.entries[idx + 1] if idx + 1 < len(self.entries) else len(self.code)
        return lo, hi

    def dis(self, ent, mi):
        lo, hi = self.method_range(ent, mi)
        out, i = [], lo
        while i < hi and i < len(self.code):
            w = self.code[i]
            op, par = w >> 24, w & 0xFFFFFF
            if op == 0:
                out.append((i, "PUSH", par, None))
            elif op == 0x1C:
                nxt = self.code[i + 1] if i + 1 < len(self.code) else 0
                eop = 0x100 | (nxt >> 24)
                out.append((i, OPNAMES.get(eop, "EXT_0x%03X" % eop), nxt & 0xFFFFFF, eop))
                i += 1
            else:
                out.append((i, OPNAMES.get(op, "OP_0x%02X" % op), par, op))
            i += 1
        return out

    def show(self, ent, mi, label=""):
        e = self.names.get(ent, ("ent%d" % ent, []))
        nm = e[1][mi] if mi < len(e[1]) else "m%d" % mi
        lo, hi = self.method_range(ent, mi)
        print("\n=== %s::%s  (entity %d, method %d, dwords %d..%d) %s" %
              (e[0], nm, ent, mi, lo, hi, label))
        for i, name, par, op in self.dis(ent, mi):
            if name == "PUSH":
                print("  %4d  PUSH   %d (0x%X)" % (i, par, par))
            else:
                print("  %4d  %-12s %d (0x%X)" % (i, name, par, par))


if __name__ == "__main__":
    j = JSM("bgbtl_1.jsm", "bgbtl_1.sym")
    print("entities=%d entryPoints=%d codeDwords=%d" %
          (len(j.groups), len(j.entries), len(j.code)))
    want = sys.argv[1:] if len(sys.argv) > 1 else None
    for ei, (cnt, start) in enumerate(j.groups):
        e = j.names.get(ei, ("ent%d" % ei, []))
        for mi in range(cnt):
            nm = e[1][mi] if mi < len(e[1]) else "m%d" % mi
            if want and not any(w in nm or w in e[0] for w in want):
                continue
            j.show(ei, mi)
