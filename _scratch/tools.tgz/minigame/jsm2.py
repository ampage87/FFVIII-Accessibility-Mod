"""jsm2.py -- FF8 field-script disassembler, decoding VERIFIED against the
engine's own decoder at VA 0x00530760:

    if (word & 0xFF000000) { op = word >> 24; arg = word & 0xFFFFFF
                             (sign-extended when bit 0x800000 is set) }
    else                   { op = word;       arg = <undefined> }

So a dword with a zero high byte is a ZERO-OPERAND opcode whose number is the
whole value -- NOT "push literal N" as the mod's older reading had it. Every
zero-high dword in bgbtl_1 and bg2f_31 is <= 323, inside the 400-entry handler
table at 0x00B8DE94, which is what makes that reading provable rather than
plausible.
"""
import struct, sys

# Opcode names. Entries marked (X) were read out of the handler in FF8_EN.exe
# during the 2026-08-15 pass; the rest are the mod's older table, kept as hints.
OPS = {
  0x01:("EXPR",   "call expr-handler[arg] (2nd-stage table 0xB8DE4C)          X"),
  0x02:("JMP",    "ip += arg                                                  X"),
  0x03:("JPF",    "pop; if 0 then ip += arg                                   X"),
  0x05:("PUSH8",  "push local[0..7], zero them                                X"),
  0x06:("RET",    "pop 8 into local[0..7], end script                         X"),
  0x07:("PUSHI",  "push arg                                                   X"),
  0x08:("PUSHL",  "push local[arg]                                            X"),
  0x09:("POPL",   "pop -> local[arg]                                          X"),
  0x0A:("RDVARB", "push (u8) var[arg]                                         X"),
  0x0B:("WRVARB", "pop -> (u8) var[arg]                                       X"),
  0x0C:("RDVARW", "push (u16) var[arg]                                        X"),
  0x0D:("WRVARW", "pop -> (u16) var[arg]                                      X"),
  0x0E:("RDVARL", "push (u32) var[arg]                                        X"),
  0x0F:("WRVARL", "pop -> (u32) var[arg]                                      X"),
  0x10:("RDVARSB","push (s8) var[arg]                                         X"),
  0x11:("RDVARSW","push (s16) var[arg]                                        X"),
  0x12:("RDVARL2","push (u32) var[arg]                                        X"),
  0x13:("PUSHR",  "push arg raw (no type conversion)                          X"),
  0x14:("REQ",    "pop label, pop prio; start script on entity[arg]           X"),
  0x15:("REQSW",  "REQ, wait for start"),
  0x16:("REQEW",  "REQ, wait for end                                          X"),
  0x1A:("UNUSE",  "clear bit 1 of entity flags                                X"),
  0x1C:("RETNOW", "return 1 (end this frame's slice)                          X"),
  0x1D:("MOVE2",  "pop y,x (<<12); move                                       X"),
  0x1E:("MOVE3",  "pop z,y,x (<<12); move                                     X"),
  0x1F:("SETBIT", "set bit arg in 0x1CE4918 bitfield                          X"),
  0x20:("CLRBIT", "clear bit arg in 0x1CE4918 bitfield                        X"),
  0x21:("SFX",    "pop 3; sound                                               X"),
  0x2A:("MAPJUMP3","pop 6 -> field transition                                 X"),
  0x2B:("SETMODEL","[ent+0x218] = arg                                         X"),
  0x2C:("BASEANIME","[ent+0x24f]=arg, pop 2                                   X"),
  0x2D:("ANIME1", "play anim arg                                              X"),
  0x2E:("ANIMEKEEP","play anim arg (other flag)                               X"),
  0x30:("ANIMESYNC","pop 2, anim                                              X"),
  0x31:("ANIM31", "anim arg                                                   X"),
  0x3C:("WAIT",   "TOS--; re-run until 0 then pop                             X"),
  0x3D:("DIR",    "pop -> facing                                              X"),
  0x3E:("MOVEA",  "pop 5 -> move with dir                                     X"),
  0x41:("MOVE41", "pop 4"),
  0x42:("MOVE42", "pop 4"),
  0x44:("ISMOVING","return (flags&0x800)?2:1                                  X"),
  0x6D:("BTNTEST","pop mask; local[0]=1 if (mask & [0x1CE48B0])               X"),
}

def decode(w):
    if w >> 24:
        op = w >> 24
        arg = w & 0xFFFFFF
        if arg & 0x800000: arg -= 0x1000000
        return op, arg, True
    return w, None, False

class Script:
    def __init__(self, path):
        d = open(path,'rb').read()
        self.d = d
        self.posFirst, self.posScripts = struct.unpack_from('<HH', d, 4)
        self.nEnt = struct.unpack_from('<H', d, 0)[0]
        self.groups=[]
        for o in range(8, self.posFirst, 2):
            v = struct.unpack_from('<H', d, o)[0]
            self.groups.append((v & 0x7F, v >> 7))   # (count, firstLabel)
        self.entry=[]
        for o in range(self.posFirst, self.posScripts, 2):
            self.entry.append(struct.unpack_from('<H', d, o)[0])
        self.code=[]
        c = d[self.posScripts:]
        for i in range(len(c)//4):
            self.code.append(struct.unpack_from('<I', c, i*4)[0])
    def names(self, sympath):
        try: raw=open(sympath,'rb').read()
        except OSError: return {},{}
        return raw

def load_sym(path):
    """FF8 .sym: entity names then per-label script names, NUL/newline sep."""
    try: raw = open(path,'rb').read()
    except OSError: return []
    import re
    return [s.decode('latin1') for s in re.findall(rb'[\x20-\x7e]{2,}', raw)]

def disasm(sc, start, end, labelnames=None):
    out=[]
    for ip in range(start, end):
        w = sc.code[ip]
        op, arg, hasarg = decode(w)
        nm, desc = OPS.get(op, (f"op{op}", ""))
        if hasarg:
            txt = f"{nm} {arg}"
        else:
            txt = nm
        out.append((ip, w, op, arg, txt))
    return out
