#!/usr/bin/env bash
# run_gates.sh -- the pre-push gate. Must print "overall fail=0".
#   linters -> size gate -> every tests/*.cpp compiled and run
# Usage: bash tests/run_gates.sh   (from the repo root)
set -u
cd "$(dirname "$0")/.."
fail=0
OUT=tests_out
mkdir -p "$OUT"

echo "=== linters ==="
for l in lint_braces lint_freeze lint_seh lint_stub lint_xtu; do
  if python3 "tests/$l.py" >"$OUT/$l.txt" 2>&1; then echo "$l  OK"
  else echo "$l  FAIL"; sed -n '1,40p' "$OUT/$l.txt"; fail=$((fail+1)); fi
done

echo "=== size gate (80 KB per .cpp/.inl, field_catalog.inl exempt) ==="
big=$(find src -name '*.cpp' -o -name '*.inl' | while read -r f; do
        case "$f" in */field_catalog.inl) continue;; esac
        s=$(stat -c%s "$f"); [ "$s" -gt 81920 ] && echo "$s $f"
      done)
if [ -n "$big" ]; then echo "OVER 80KB:"; echo "$big"; fail=$((fail+1)); else
  echo "size gate: OK  (largest non-exempt: $(find src -name '*.cpp' -o -name '*.inl' | grep -v field_catalog.inl | xargs stat -c'%s %n' | sort -rn | head -1))"
fi

echo "=== compile + run ==="
for t in tests/*.cpp; do
  b=$(basename "$t" .cpp)
  case "$b" in menu_sim) continue;; esac
  extra=""
  grep -q 'ff8_text_decode.h' "$t" && extra="src/ff8_text_decode.cpp"
  if ! g++ -std=c++17 -O0 -w -Isrc -Itests -o "$OUT/$b" "$t" $extra >"$OUT/$b.build" 2>&1; then
    echo "$b  BUILD FAIL"; sed -n '1,25p' "$OUT/$b.build"; fail=$((fail+1)); continue
  fi
  if "$OUT/$b" >"$OUT/$b.run" 2>&1; then echo "$b  OK"
  else echo "$b  RUN FAIL"; sed -n '1,25p' "$OUT/$b.run"; fail=$((fail+1)); fi
done

echo "overall fail=$fail"
exit $fail
