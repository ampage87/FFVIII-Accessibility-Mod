#!/usr/bin/env python3
"""GENERATE src/rag_landing_table.inl -- where the Ragnarok sets down.

THE RULE THE GAME ITSELF DRAWS
------------------------------
`wmsetus.obj` section 7 (file offset 5580) is the game's own 64-entry table of
world-map places: `int32 X, int32 Z, int16 height, int16 flags`. Cross-referenced
against the two wmx.obj polygon bits, exactly THREE of its live records are
Ragnarok-landable and NOT foot-walkable:

    #13  (  20480,  -2560)  h= -500   Fisherman's Horizon
    #21  (-118784,  86016)  h= -868   Deep Sea Research Center
    #27  (  54791,   5650)  h=-1849   Esthar Airstation

Those are exactly the three Aaron named as places the airship lands ON rather
than beside: *"For those locations that Ragnarok can land on such as FH, Deep Sea
Research center, and Esthar Airstation, the Ragnarok should drive to the spot to
land on/at these locations."* A pad you can set down on but cannot walk onto is
a pad you arrive at by landing. The signature is the game's, not a guess, and it
picks out three records from fifty-two.

Everything else gets the generic rule: the nearest cell that is landable AND
foot-walkable AND foot-connected to the destination marker, so he lands as close
as he can and walks the rest. That is the opposite of the Garden's berths, which
are deliberately held 2-3 km off because the hull cannot approach a town.

Usage:  python3 offline/gen_rag_table.py [out.inl]
"""
import re
import struct
import sys
from collections import deque

import numpy as np
import gen_rag_landings as G

WMSETUS = '/home/claude/_scratch/wm/wmsetus.obj'
WMX     = '/home/claude/_scratch/wm/wmx.obj'
CATALOG = '/home/claude/src/world_catalog.inl'
LOC_OFF, LOC_N = 5580, 64
PAD_MATCH_UNITS = 4000     # how near a pad must be to claim a catalog name

# ESTHAR IS REACHED BY LANDING AT ITS AIRSTATION, and the data says so twice
# over: the city marker's own foot component contains no landable cell at all,
# and the only pad within 20 km is record 27 at (54791, 5650) -- 8.2 km away,
# far outside PAD_MATCH_UNITS, because the Airstation is a place in its own
# right rather than Esthar City's back garden. A sighted player flies to the
# Airstation and walks in from there; this is that, written down.
VIA_PAD = { 'Esthar City': 27 }


def game_records():
    d = open(WMSETUS, 'rb').read()
    out = []
    for i in range(LOC_N):
        x, z, h, fl = struct.unpack_from('<iihh', d, LOC_OFF + i*12)
        if x == 0 and z == 0 and h == 0: continue
        out.append((i, x, z, h, fl & 0xFFFF))
    return out


def catalog():
    src = open(CATALOG).read()
    return [(m[0], int(m[1]), int(m[2])) for m in
            re.findall(r'\{\s*"([^"]+)"\s*,\s*(-?\d+)\s*,\s*(-?\d+)\s*\}', src)]


def main():
    out = sys.argv[1] if len(sys.argv) > 1 else '/home/claude/src/rag_landing_table.inl'
    landable, foot, have, elev = G.build_grids(WMX)

    # --- the pads: landable, not foot-walkable, in the game's own table ------
    pads = []
    for i, x, z, h, fl in game_records():
        c, r = G.raw_to_cell(x, z)
        if not (0 <= c < G.COLS and 0 <= r < G.ROWS): continue
        if landable[r][c] and not foot[r][c]:
            pads.append((i, x, z, h))

    cat = catalog()
    rows = []
    for name, gx, gy in cat:
        pad = None
        want = VIA_PAD.get(name)
        if want is not None:
            for i, x, z, h in pads:
                if i == want:
                    d = ((x-gx)**2 + (z-gy)**2) ** 0.5
                    rows.append(dict(name=name, x=gx, y=gy, land_x=x, land_y=z,
                                     dist=int(round(d)), kind='PAD', rec=i,
                                     note="reached by landing at the Esthar Airstation "
                                          "(record %d); the city's own ground has no "
                                          "landable cell" % i))
                    break
            else:
                rows.append(dict(name=name, x=gx, y=gy, kind='NONE',
                                 note='via-pad %d not found' % want))
            continue
        for i, x, z, h in pads:
            d = ((x-gx)**2 + (z-gy)**2) ** 0.5
            if d <= PAD_MATCH_UNITS and (pad is None or d < pad[4]):
                pad = (i, x, z, h, d)
        if pad is not None:
            rows.append(dict(name=name, x=gx, y=gy, land_x=pad[1], land_y=pad[2],
                             dist=int(round(pad[4])), kind='PAD', rec=pad[0],
                             note='the game\'s own record %d, landable and not walkable' % pad[0]))
            continue
        anchor = G.nearest_foot_cell(foot, G.raw_to_cell(gx, gy))
        if anchor is None:
            rows.append(dict(name=name, x=gx, y=gy, kind='NONE',
                             note='no foot ground within 40 cells of the marker'))
            continue
        comp = G.foot_component(foot, elev, anchor)
        cand = landable & foot & comp
        if not cand.any():
            rows.append(dict(name=name, x=gx, y=gy, kind='NONE',
                             note='no landable cell on the marker landmass'))
            continue
        rr, cc = np.nonzero(cand)
        wx = cc.astype(np.int64)*G.CELL - G.OFF_X + G.CELL//2
        wy = rr.astype(np.int64)*G.CELL - G.OFF_Y + G.CELL//2
        d2 = (wx-gx)**2 + (wy-gy)**2
        k = int(np.argmin(d2))
        rows.append(dict(name=name, x=gx, y=gy, land_x=int(wx[k]), land_y=int(wy[k]),
                         dist=int(round(float(np.sqrt(d2[k])))), kind='WALK',
                         note='nearest landable cell foot-connected to the marker'))
    emit(out, rows, pads)
    for r in rows:
        if r['kind'] == 'NONE':
            print('%-26s  --  %s' % (r['name'], r['note']))
        else:
            print('%-26s  %-4s (%7d,%7d)  walk %5d u' %
                  (r['name'], r['kind'], r['land_x'], r['land_y'], r['dist']))


def emit(path, rows, pads):
    n = 0
    with open(path, 'w') as f:
        f.write(HEADER % (len(pads), '\n'.join(
            '//   #%-3d (%8d,%8d)  h=%6d' % p for p in pads)))
        f.write('static const RagLanding RAG_LANDINGS[] = {\n')
        for r in rows:
            if r['kind'] == 'NONE':
                f.write('    // %-26s -- %s\n' % ('"%s"' % r['name'], r['note']))
                continue
            n += 1
            f.write('    { %-28s %8d, %8d, %6d, RAG_%s },   // %s\n' %
                    ('"%s",' % r['name'], r['land_x'], r['land_y'], r['dist'],
                     r['kind'], r['note']))
        f.write('};\n')
        f.write('static const int RAG_LANDING_COUNT = '
                '(int)(sizeof(RAG_LANDINGS) / sizeof(RAG_LANDINGS[0]));\n')
    sys.stderr.write('wrote %s (%d rows)\n' % (path, n))


HEADER = '''// rag_landing_table.inl -- GENERATED by offline/gen_rag_table.py. Do not edit.
//
// Where the Ragnarok sets down for each world-map destination.
//
// The airship has no movement mask at all -- 0x53E6B0 falls through to
// `return 1` for vehicle 0x32, so it flies over everything and there is nothing
// to route around. The only question the world map asks about it is where it
// may SET DOWN, and that is a different bit on a different byte: 0x53E730 reads
// (typeTriple >> 8) & 0x80, i.e. poly[14] bit 7.
//
// Two kinds of row:
//
//   RAG_PAD   the destination IS a landing pad -- fly to the spot and land on
//             it. Identified by the game's own data rather than by hand: a
//             record in the wmsetus location table that is landable and NOT
//             foot-walkable. Exactly %d records in the whole table qualify:
%s
//             ...which are Fisherman's Horizon, the Deep Sea Research Center
//             and the Esthar Airstation -- the three Aaron named.
//
//   RAG_WALK  land as close as possible and walk. The cell must be landable,
//             foot-walkable, and foot-connected to the destination marker under
//             the engine's own step gate (|dH| >= 200 refuses), so the landing
//             is never across a strait from the place it serves.
//
// Distances are the walk left after landing, in world units.
'''

if __name__ == '__main__':
    main()
