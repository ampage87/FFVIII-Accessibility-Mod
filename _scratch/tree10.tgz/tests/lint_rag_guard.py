#!/usr/bin/env python3
"""The forward-collision guard must be keyed on FLYING, not on having a landing.

v0.79.0 wrote `s_ragLanding == nullptr` here, and the 23:05 BAT ran the
controlled experiment inside one session:

  Sorceress Memorial   has a landing row -> guard OFF -> flew 53 km, arrived
  Mobile Balamb Garden no landing row    -> guard ON  -> position trace decays
                                            355, 339, 270, 209, 148, 88, 27, 6, 0
                                            and the drive gave up 53 km short

The airship has NO movement mask -- 0x53E6B0 falls through to `return 1` for
vehicle 0x32 -- so a fine-grid cell marked blocked ahead of it is scenery, not
an obstacle, whether or not the mod knows where that destination's landing is.
The three MOBILE destinations can never have a landing row at all, so keying the
guard on one permanently re-broke them.

This lint fails the build if that condition ever goes back to asking about the
landing row.
"""
import re
import sys

TARGET = 'src/world_map_drive_exec.inl'
GUARD  = re.compile(r'if\s*\(\s*!s_driveNavmeshPath\s*&&\s*([^)]*)\)')

def main():
    try:
        src = open(TARGET, encoding='utf-8').read()
    except OSError as e:
        print('lint_rag_guard: cannot read %s (%s)' % (TARGET, e))
        return 1
    hits = GUARD.findall(src)
    if not hits:
        print('lint_rag_guard: the forward-collision guard condition is GONE from %s.\n'
              '  Expected `if (!s_driveNavmeshPath && !s_ragFlying) {`.\n'
              '  If the guard moved, move this lint with it.' % TARGET)
        return 1
    bad = 0
    for cond in hits:
        c = cond.strip()
        if 's_ragLanding' in c:
            print('lint_rag_guard: %s\n'
                  '  the forward-collision guard is keyed on the LANDING ROW: `%s`\n'
                  '  Key it on FLIGHT instead: `!s_ragFlying`.\n'
                  '  A landing row says where to set down. It does not say whether the\n'
                  '  terrain ahead can be flown over -- and the three mobile destinations\n'
                  '  never have one, so this condition strands them.' % (TARGET, c))
            bad += 1
        elif '!s_ragFlying' not in c:
            print('lint_rag_guard: %s\n'
                  '  the forward-collision guard no longer excuses flight: `%s`\n'
                  '  Expected `!s_ragFlying` in the condition. The airship crosses ocean,\n'
                  '  mountain and forest alike; the guard makes it crab sideways instead\n'
                  '  of pressing forward, and it coasts to a halt.' % (TARGET, c))
            bad += 1
    if bad == 0:
        print('lint_rag_guard: OK (%d guard condition(s) checked)' % len(hits))
    return 1 if bad else 0

if __name__ == '__main__':
    sys.exit(main())
