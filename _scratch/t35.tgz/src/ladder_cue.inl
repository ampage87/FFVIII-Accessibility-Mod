// ============================================================================
// v0.124.0 (#centra): THE LADDER CLIMB SOUND -- THE GAME'S OWN
// ============================================================================
// Aaron: "why can't we utilize the same climbing sound as the rest of the
// ladders in the game?" We can. v0.123.0 synthesised knocks on the assumption
// that reaching the engine's audio would be fragile; the assumption was never
// tested and it was wrong. See ladder_cue_model.inl for the routine, its four
// call sites, and the branch that picks the ladder sound from the movement
// mode -- which means the mod chooses no sound, no id and no volume. It asks
// the engine for the noise this character on this surface would make.
//
// Nothing here reads the entity array or the player index: the caller decides
// which entity is climbing and passes its block through. That is what lets
// tests/ladder_cue_compile.cpp build this unit on the host, which
// field_navigation.cpp's own translation unit cannot be.

typedef void (__cdecl* LadderStepSoundFn)(int entityPtr, int foot, int volume, int pan);

static LadderStepSoundFn s_ladderStepSound = nullptr;
static bool  s_ladderStepChecked = false;
static DWORD s_ladderStepLastMs  = 0;
static bool  s_ladderStepEver    = false;
static int   s_ladderStepIndex   = 0;
static DWORD s_ladderClimbStartMs = 0;

// v0.125.0: what the engine is doing on THIS climb, cleared the frame the
// movement mode turns into a ladder mode. Scoped to the climb on purpose --
// steps the engine played on the previous ladder must not silence this one.
static DWORD s_ladderEngineLastMs = 0;
static bool  s_ladderEngineEver   = false;

// The learned cadence, carried across climbs. One engine-sounded ladder
// anywhere in the game teaches the mod the game's own rhythm, and the Centra
// tower ladders come before the roof one on the only route up.
static unsigned s_ladderIntervalMs = LADDER_STEP_MS_DEFAULT;
static bool     s_ladderLearned    = false;

// Set while the mod is calling through the routine, so its own step is never
// recorded as the engine's. It matters even though the mod calls the trampoline:
// if MH_CreateHook fails, s_ladderStepSound stays pointed at the raw address and
// a call to it lands back in the hook.
static bool  s_ladderSelfCall     = false;

// SEH-guarded compare of the routine's prologue. A patched or repacked exe
// fails it and the cue stays silent, which is the only safe answer when the
// alternative is calling into the middle of something else.
static bool LadderStepSigMatches(uintptr_t addr)
{
    bool ok = false;
    __try {
        const unsigned char* p = (const unsigned char*)addr;
        ok = true;
        for (int i = 0; i < LADDER_STEP_SIG_LEN; i++) {
            if (p[i] != LADDER_STEP_SIG[i]) { ok = false; break; }
        }
    } __except (EXCEPTION_EXECUTE_HANDLER) { ok = false; }
    return ok;
}

// Resolved once. Returns null when the signature does not match.
static LadderStepSoundFn LadderStepSound()
{
    if (s_ladderStepChecked) return s_ladderStepSound;
    s_ladderStepChecked = true;
    if (LadderStepSigMatches((uintptr_t)LADDER_STEP_ADDR))
        s_ladderStepSound = (LadderStepSoundFn)(uintptr_t)LADDER_STEP_ADDR;
    return s_ladderStepSound;
}

// SEH-guarded call. The routine touches the entity block and the audio mixer;
// a fault here must not take the game down over a sound cue.
// v0.126.0: and it presents a mode the routine will sound as a ladder. On a
// descent the byte reads 2, which falls through to the terrain footstep table --
// see LadderModeSoundsAsLadder in ladder_cue_model.inl. The byte is restored in
// a __finally so a fault inside the routine cannot leave the entity walking
// around in a borrowed movement mode.
static bool s_ladderModeSwapped = false;   // for the log, read after the call

// v0.127.0 splits what v0.126.0 wrote as __try/__finally into three guarded
// steps. Not a style change: the winshim maps __try to try and __except to
// catch(...), and there is no macro that can fake __finally, so the __finally
// form could not be built on the host at all -- tests/ladder_cue_compile.cpp,
// the probe that exists precisely because this code cannot be checked any other
// way, stopped compiling. Three __try blocks say the same thing, restore the
// byte on the fault path as well (the swallowed fault falls through to the
// restore rather than unwinding past it), and can be driven by the probe.
static void LadderStepInvoke(LadderStepSoundFn fn, int entityPtr, int foot)
{
    s_ladderModeSwapped = false;
    volatile unsigned char* modeByte =
        (volatile unsigned char*)(uintptr_t)((unsigned)entityPtr + LADDER_MODE_OFFSET);
    unsigned char saved = 0;
    bool swap = false;

    __try {
        saved = *modeByte;
        swap  = !LadderModeSoundsAsLadder((int)saved);
        if (swap) {
            *modeByte = LADDER_MODE_SOUNDS_AS;
            s_ladderModeSwapped = true;
        }
    } __except (EXCEPTION_EXECUTE_HANDLER) { return; }

    __try {
        fn(entityPtr, foot, LADDER_STEP_VOLUME, LADDER_STEP_PAN);
    } __except (EXCEPTION_EXECUTE_HANDLER) { }

    if (swap) {
        __try { *modeByte = saved; } __except (EXCEPTION_EXECUTE_HANDLER) { }
    }
}

// v0.125.0: the engine just played a step for the climbing player. Returns the
// gap in ms when it was usable as a cadence sample, or 0, so the caller can log
// what was measured -- the whole point of this build is that the number is
// evidence rather than a guess, and evidence belongs in the log.
// v0.127.0: the raw gap and what it folded to, kept for the log line. A gap the
// engine skipped a stride on shows up here as "1359 -> 453 (x3)", which is the
// difference between a slower ladder and a missed one -- and the whole reason
// the cadence stopped drifting to 970 ms.
static unsigned s_ladderLastRawGapMs = 0;
static unsigned s_ladderLastFoldN    = 0;

static unsigned LadderNoteEngineStep(unsigned nowMs)
{
    unsigned folded = 0;
    s_ladderLastRawGapMs = 0;
    s_ladderLastFoldN    = 0;
    if (s_ladderEngineEver) {
        const unsigned gap = (unsigned)(nowMs - s_ladderEngineLastMs);
        s_ladderLastRawGapMs = gap;
        folded = LadderFoldGap(gap, s_ladderIntervalMs);
        if (folded != 0) {
            s_ladderLastFoldN  = (folded > 0) ? ((gap + folded / 2u) / folded) : 1u;
            s_ladderIntervalMs = LadderLearnInterval(s_ladderIntervalMs, gap);
            s_ladderLearned    = true;
        }
    }
    s_ladderEngineLastMs = (DWORD)nowMs;
    s_ladderEngineEver   = true;
    return folded;
}

// Called the frame a climb begins. Everything scoped to one ladder resets here:
// the step spacing (so the next climb steps on its own schedule rather than
// waiting out an interval that started minutes ago) and the engine's activity
// (so this ladder is judged on whether IT makes noise).
static void LadderClimbBegin(unsigned nowMs)
{
    s_ladderClimbStartMs = (DWORD)nowMs;
    s_ladderStepEver     = false;
    s_ladderStepIndex    = 0;
    s_ladderEngineEver   = false;
}

// Called every frame with the player's entity block and its movement mode.
// Returns true when a step was played, so the caller can log it.
// v0.128.0: true while a scripted ladder move is running that sets no movement
// mode -- crroof1's descent, which animates in place and teleports. Armed by the
// poll from the engine's control-lock byte, gated on the player standing on a
// line the field calls a ladder.
static bool s_ladderScriptCue = false;

// The two ways the mod knows a ladder is being used: the engine's own movement
// mode, and the control lock over a ladder line for the descents that set no
// mode at all. One state, so the two can never both cue the same step.
static bool LadderIsClimbing(int mode)
{
    return LadderModeIsClimb(mode) || s_ladderScriptCue;
}

static bool LadderStepPoll(int entityPtr, int mode, unsigned nowMs)
{
    const bool climbing = LadderIsClimbing(mode);
    if (!climbing) { s_ladderStepEver = false; s_ladderStepIndex = 0; return false; }

    // The game is sounding this ladder itself -- v0.124.0 would have doubled it.
    if (LadderEngineIsStepping(s_ladderEngineEver, nowMs,
                               (unsigned)s_ladderEngineLastMs, s_ladderIntervalMs))
        return false;

    if (!LadderStepDue(climbing, nowMs, (unsigned)s_ladderClimbStartMs,
                       (unsigned)s_ladderStepLastMs, s_ladderStepEver, s_ladderIntervalMs))
        return false;
    LadderStepSoundFn fn = LadderStepSound();
    if (fn == nullptr) return false;
    s_ladderStepLastMs = (DWORD)nowMs;
    s_ladderStepEver   = true;
    s_ladderSelfCall   = true;
    LadderStepInvoke(fn, entityPtr, LadderStepFoot(s_ladderStepIndex++));
    s_ladderSelfCall   = false;
    return true;
}
