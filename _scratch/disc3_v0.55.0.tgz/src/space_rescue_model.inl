// space_rescue_model.inl -- the PURE model of the disc-3 space rescue: Squall
// closing on the drifting Rinoa (field `ssspace3`, id 878, "Outer Space 5").
//
// PART OF field_navigation.cpp -- TEXTUAL INCLUDE. Do NOT compile standalone.
// Compiled standalone by tests/space_rescue_compile.cpp.
//
// ============================================================================
// THE SCENE, READ OUT OF ssspace3 (#111)
// ============================================================================
//
// Aaron: *"The player basically has to adjust the view to keep Rinoa centered
// on the screen until they reach her."* That is exactly what the script does,
// and the whole thing reduces to two signed numbers.
//
// THE ERROR TERM. Two int32 field variables carry Rinoa's offset from the
// centre of the view:
//
//     var 1040  ->  0x01CFEDC8   X   (+ = she is RIGHT of centre)
//     var 1044  ->  0x01CFEDCC   Y   (+ = she is ABOVE centre)
//
// `rinoa::poscheck0` (dwords 673-704) clamps them to +-8100 and +-7300, which
// is the whole range the player ever sees.
//
// THE DIRECTION TO PRESS -- and this is the part that must not be inverted, so
// it is read straight off the four key handlers rather than reasoned about:
//
//     rinoa::keyl  dw 350-353   X = X + step     (holding LEFT  raises X)
//     rinoa::keyr  dw 385-389   X = X - step     (holding RIGHT lowers X)
//     rinoa::keyu  dw 421-425   Y = Y - step     (holding UP    lowers Y)
//     rinoa::keyd  dw 457-461   Y = Y + step     (holding DOWN  raises Y)
//
// So to drive X toward zero you press RIGHT when X is positive and LEFT when it
// is negative; to drive Y toward zero you press UP when Y is positive and DOWN
// when it is negative. In plain terms **you steer toward her**, which is the
// intuitive reading and is also what the bytecode says. The two agree, and the
// bytecode is why this comment can promise it.
//
// THE BUTTONS. `director1::default` dwords 1147-1316 reads four masks with
// BTN_HELD (0x6D, a level test -- these are holds, not taps) and folds them
// into var[1024] as a 1..9 direction state:
//
//     0x8000 left   0x2000 right   0x1000 up   0x4000 down
//     0x0010        doubles the step (8 instead of 4) and burns fuel
//
// The masks are named by the game's own `.sym` method names (rinoa::keyl and
// friends), not by assumption. The mod resolves them to the player's real key
// names through the same learner the Garden battle and the dragon fight use.
//
// THE VERDICT. Taken EXACTLY ONCE, in `rinoa::default` dwords 225-243, after
// the approach animation finishes (`0x0F5` at dword 224):
//
//     if (var1040 > -180 && var1040 < 180 &&
//         var1044 > -180 && var1044 < 180)   var[1035] = 1
//
// and then dwords 245-256: `var[1035]==1` -> var[256]=2564, MAPJUMPO 877, the
// reunion. Being centred at any earlier moment earns nothing; being centred at
// that instant is the entire game. **180 is therefore not a tolerance this mod
// chose -- it is the game's own win box**, and the mod's "centred" means
// exactly it.
//
// Failure is "Squall was lost in space...forever." and a Try again / Quit ask
// with unlimited retries, so a missed attempt costs time and not the save.
//
// THE SKIP. The verdict has exactly two inputs. Holding both at zero for the
// frame it is taken makes the game's own bytecode declare the win -- every
// line after dword 243 is the game's, including the MAPJUMPO. Nothing is
// forged, no transition is synthesised (the v0.20.110 crash is the standing
// reminder of why that matters), and because the key handlers keep adding to
// the same variables it has to be a mode held every tick rather than a
// one-shot write.

static const int      SR_FIELD_ID   = 878;          // ssspace3
static const uint32_t SR_ADDR_X     = 0x01CFEDC8u;  // var 1040, int32
static const uint32_t SR_ADDR_Y     = 0x01CFEDCCu;  // var 1044, int32
static const int      SR_WIN_BOX    = 180;          // the game's own |x|,|y| test
static const int      SR_CLAMP_X    = 8100;
static const int      SR_CLAMP_Y    = 7300;

// The four D-pad masks, exactly as director1::default tests them.
static const uint16_t SR_MASK_LEFT  = 0x8000;
static const uint16_t SR_MASK_RIGHT = 0x2000;
static const uint16_t SR_MASK_UP    = 0x1000;
static const uint16_t SR_MASK_DOWN  = 0x4000;
static const uint16_t SR_MASK_BOOST = 0x0010;

// Centred means the game's win box, not a nicer number.
static bool SrCentred(int x, int y)
{
    return x > -SR_WIN_BOX && x < SR_WIN_BOX &&
           y > -SR_WIN_BOX && y < SR_WIN_BOX;
}

// Which mask closes the gap on each axis. 0 when that axis is already inside
// the box. Derived from the key handlers' own arithmetic: the mask to press is
// the one whose handler moves the variable TOWARD zero.
static uint16_t SrMaskForX(int x)
{
    if (x >= SR_WIN_BOX)  return SR_MASK_RIGHT;   // keyr subtracts
    if (x <= -SR_WIN_BOX) return SR_MASK_LEFT;    // keyl adds
    return 0;
}
static uint16_t SrMaskForY(int y)
{
    if (y >= SR_WIN_BOX)  return SR_MASK_UP;      // keyu subtracts
    if (y <= -SR_WIN_BOX) return SR_MASK_DOWN;    // keyd adds
    return 0;
}

// How far out, in words. The bands are the clamp range split so that "a long
// way" means most of the screen and "just" means nearly there; they exist to
// stop a bare direction being read as "you are miles off" when you are 200
// units out.
static const char* SrBand(int v, int clamp)
{
    const int a = v < 0 ? -v : v;
    if (a < SR_WIN_BOX)      return "";
    if (a < 600)             return "just ";
    if (a < clamp / 3)       return "";
    if (a < (clamp * 2) / 3) return "well ";
    return "a long way ";
}
