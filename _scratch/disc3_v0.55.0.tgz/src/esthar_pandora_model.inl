// esthar_pandora_model.inl -- the PURE model of the Esthar "board Lunatic
// Pandora" run (field set `ec*`, disc 3).
//
// PART OF field_navigation.cpp -- TEXTUAL INCLUDE. Do NOT compile standalone.
// Compiled standalone by tests/esthar_pandora_compile.cpp. Nothing here touches
// game memory, Windows or the screen reader.
//
// ============================================================================
// THE SCENE, AS ITS OWN SCRIPTS AND ITS OWN BRIEFING DEFINE IT (#110)
// ============================================================================
//
// Aaron: *"The player is shown three images of the city, and they are supposed
// to navigate to that part of the city to hop on board the Pandora when it
// passes by."* The three images are the only instruction a sighted player gets,
// which makes this unplayable blind: there is nothing to read.
//
// Odine's briefing is `emlabo2`, messages 7-14, and it is unusually generous:
//
//     msg  7  "The city has 1 outer skyway and 2 main inner skyways, all
//              leading to the palace."
//     msg  9  "The time it will take to cross the city is estimated to be
//              [20 minutes]."
//     msg 10  "Boarding Lunatic Pandora is possible at the following 3 contact
//              points:"
//     msg 11  "The first contact point is at the CENTER OF THE CITY ...
//              [15:00 to 12:00] left on your timer."
//     msg 12  "The second contact point is unknown. We believe it is WHERE THE
//              2 SKYWAYS CROSS ... [10:00 to 5:00]"
//     msg 13  "The third contact point is NORTH OF THE SHOPPING MALL ...
//              [3:00 to 0:00]"
//
// THE TIMER. A 20-minute countdown in WHOLE SECONDS. `ecmview1 ::
// Timelimit::default` arms it once with `SETTIMER 1201` (opcode 0x09C, handler
// 0x005216E0) -- 20:01, one second of slack. The engine holds it as a dword at
// 0x01CFE92C and ticks it at 0x0047022D. Every one of the 21 minigame fields
// mirrors it into **field var[1024]**, a WORD at 0x01CFEDB8, every frame; that
// mirror is what the game's own HUD reads, so this reads it too.
//
// THE LADDER. `eccway11 :: Disp::default` dwords 5405-5468 -- byte-identical in
// all 21 fields -- picks which contact point to draw and whether to highlight
// it, from var[1024] alone:
//
//     if T > 720:   point 1,  highlighted when T <= 900
//     elif T > 300: point 2,  highlighted when T <= 600
//     else:         point 3,  highlighted when T <= 180
//
// Highlighted means the window is open. Those six numbers are the whole state
// machine and they match the briefing exactly, so EstharPhase below is not a
// model of the game -- it is the game's own branch, transcribed.
//
// THE WINDOWS, as the arrival scripts test them (all on GETTIMER, opcode 0x0A4):
//
//     CP1  ecenc1 (field 417)   720 < T <= 900   (903 on the two walk-in lines)
//     CP2  ecenc2 (field 418)   300 < T <= 600
//     CP3  ecenc3 (field 419)     0 < T <= 180
//
// Arriving outside a window is harmless -- the same line just performs an
// ordinary map transition -- so the cost of being early or late is the run, not
// a crash. `var[678]` bits 0 and 1 burn CP1 and CP2 on use; CP3 is retryable
// until the clock reaches zero.
//
// WHAT HAPPENS AT ZERO. 25 fields carry an identical `Timer::defalut`
// watchdog: at T < 1 it sets var[672]=23 and jumps to `efbig1`, the "Kills me
// to let 'em go" scene. Nothing rewrites var[672] back to 19, so **the run
// cannot be retried** -- which is exactly why the mod has to get this right the
// first time.
//
// ONE ROUTE-CRITICAL FACT: every lifter in Esthar refuses while var[672]==19,
// silently or with "It's no use...". The whole run is on foot.

static const int      EP_VAR_MISSION   = 672;      // 19 == the Pandora run is live
static const int      EP_MISSION_LIVE  = 19;
static const int      EP_VAR_TIMER     = 1024;     // WORD mirror of the countdown, seconds
static const uint32_t EP_TIMER_ADDR    = 0x01CFE92Cu;  // the engine's own dword

// The ladder's six numbers, named once.
static const int EP_T_CP1_ARM   = 720;   // above this, point 1 is the target
static const int EP_T_CP1_OPEN  = 900;   // at or below this, point 1 is OPEN
static const int EP_T_CP2_ARM   = 300;
static const int EP_T_CP2_OPEN  = 600;
static const int EP_T_CP3_OPEN  = 180;

struct EstharPhase {
    int  point;      // 1, 2 or 3
    bool open;       // the window is open right now
    int  untilOpen;  // seconds until it opens (0 when open)
    int  untilShut;  // seconds until it shuts
};

// Transcribed from eccway11 :: Disp::default, dwords 5412-5460.
static EstharPhase EpPhaseFor(int t)
{
    EstharPhase p;
    if (t > EP_T_CP1_ARM) {
        p.point = 1;
        p.open  = (t <= EP_T_CP1_OPEN);
        p.untilOpen = p.open ? 0 : (t - EP_T_CP1_OPEN);
        p.untilShut = p.open ? (t - EP_T_CP1_ARM) : 0;
    } else if (t > EP_T_CP2_ARM) {
        p.point = 2;
        p.open  = (t <= EP_T_CP2_OPEN);
        p.untilOpen = p.open ? 0 : (t - EP_T_CP2_OPEN);
        p.untilShut = p.open ? (t - EP_T_CP2_ARM) : 0;
    } else {
        p.point = 3;
        p.open  = (t <= EP_T_CP3_OPEN);
        p.untilOpen = p.open ? 0 : (t - EP_T_CP3_OPEN);
        p.untilShut = p.open ? t : 0;
    }
    return p;
}

static const char* EpPointPlace(int point)
{
    if (point == 1) return "the centre of the city";
    if (point == 2) return "where the two skyways cross";
    return "north of the shopping mall";
}

static void EpClock(int secs, char* out, size_t n)
{
    if (secs < 0) secs = 0;
    const int m = secs / 60, s = secs % 60;
    if (m > 0) snprintf(out, n, "%d minute%s %d second%s", m, m == 1 ? "" : "s",
                        s, s == 1 ? "" : "s");
    else       snprintf(out, n, "%d second%s", s, s == 1 ? "" : "s");
}

// ============================================================================
// THE ROUTE TABLE. Generated, not typed.
// ============================================================================
//
// Esthar city is 47 walkable fields wired by the pedestrian gateways in each
// field's `.inf` (12 slots at offset 0x64, stride 32, destination field id at
// +18 -- the same records field_archive.cpp already parses at runtime). Those
// were extracted from field.fs offline, the 47 ec fields' gateways were read
// into a directed graph, and a breadth-first search was run backwards from each
// contact point's trigger fields:
//
//     CP1  eciway11 (auto-fires) / eccway11 / eccway21  (their Linejump1)
//     CP2  eccway41 / eccway12                          (the skyway crossing)
//     CP3  ecoway3 (auto-fires) / ecmall1 / eccway41
//
// Each row is (field, contact point, hops remaining, the field to walk to
// next). A field with no row for a point cannot reach it on foot from there.
//
// THE FIELD IDS THIS RESTS ON. The engine's field ids are alphabetical by
// internal name (with `_` sorting before digits), which was established by
// fitting 487 (id, name) pairs mined from Aaron's own BAT logs. That fixes the
// ec block at offset +97, giving ecenc1/2/3 = 417/418/419 -- **the same three
// ids the debug room's own EsterP::talk MAPJUMPs to.** Two independent
// derivations, one from the logs and one from the game's script, agreeing.
// The offline solve also scored 97 as the offset that makes the most gateway
// destinations resolve inside the ec set, which is a third.
struct EstharHop {
    const char* field;      // internal field name, lowercase
    uint8_t     point;      // 1, 2 or 3
    uint8_t     hops;       // fields still to cross, 0 = you are standing on it
    const char* next;       // walk here next ("" when hops == 0)
};

// GENERATED from the .inf pedestrian gateways -- do not hand-edit.
// One row per (field, contact point) the field can reach on foot.
static const EstharHop EP_HOPS[] = {
    { "eccway11", 1,  0, "" },
    { "eccway11", 2,  3, "ecenter1" },
    { "eccway11", 3,  7, "ecenter1" },
    { "eccway12", 1,  3, "ecoway2" },
    { "eccway12", 2,  0, "" },
    { "eccway12", 3,  4, "ecoway2" },
    { "eccway13", 1,  1, "eccway11" },
    { "eccway13", 2,  2, "eciway12" },
    { "eccway13", 3,  3, "eciway12" },
    { "eccway14", 1,  2, "eccway13" },
    { "eccway14", 2,  1, "eccway41" },
    { "eccway14", 3,  1, "eccway41" },
    { "eccway21", 1,  0, "" },
    { "eccway21", 2,  2, "ecoway3a" },
    { "eccway21", 3,  1, "ecmall1" },
    { "eccway22", 1,  1, "eccway11" },
    { "eccway22", 2,  3, "ecmview1" },
    { "eccway22", 3,  4, "ecmview1" },
    { "eccway31", 1,  4, "ecoway3a" },
    { "eccway31", 2,  2, "ecoway3a" },
    { "eccway31", 3,  1, "ecmall1" },
    { "eccway32", 1,  4, "ecmview2" },
    { "eccway32", 2,  5, "ecmview2" },
    { "eccway32", 3,  6, "ecmview2" },
    { "eccway41", 1,  3, "ecoway2" },
    { "eccway41", 2,  0, "" },
    { "eccway41", 3,  0, "" },
    { "eccway42", 1,  1, "eccway11" },
    { "eccway42", 2,  4, "eccway11" },
    { "eccway42", 3,  6, "ecoway2a" },
    { "ecenter1", 1,  4, "ecenter3" },
    { "ecenter1", 2,  2, "ecmway1" },
    { "ecenter1", 3,  6, "ecenter3" },
    { "ecenter3", 1,  3, "ecmway1a" },
    { "ecenter3", 2,  4, "ecmway1a" },
    { "ecenter3", 3,  5, "ecmway1a" },
    { "eciway11", 1,  0, "" },
    { "eciway11", 2,  1, "eccway12" },
    { "eciway11", 3,  5, "eccway12" },
    { "eciway12", 1,  1, "eccway21" },
    { "eciway12", 2,  1, "eccway12" },
    { "eciway12", 3,  2, "eccway21" },
    { "eciway13", 1,  2, "eccway13" },
    { "eciway13", 2,  3, "eccway13" },
    { "eciway13", 3,  4, "eccway13" },
    { "eciway14", 1,  2, "eccway22" },
    { "eciway14", 2,  3, "eccway13" },
    { "eciway14", 3,  4, "eccway13" },
    { "ecmall1", 1,  5, "ecenter1" },
    { "ecmall1", 2,  3, "ecenter1" },
    { "ecmall1", 3,  0, "" },
    { "ecmall1a", 1,  2, "eciway12" },
    { "ecmall1a", 2,  2, "eciway12" },
    { "ecmall1a", 3,  3, "eciway12" },
    { "ecmview1", 1,  2, "ecopen3" },
    { "ecmview1", 2,  2, "ecopen3" },
    { "ecmview1", 3,  3, "ecopen3" },
    { "ecmview2", 1,  3, "ecopen3a" },
    { "ecmview2", 2,  4, "ecopen3a" },
    { "ecmview2", 3,  5, "ecopen3a" },
    { "ecmway1", 1,  4, "ecopen1a" },
    { "ecmway1", 2,  1, "eccway12" },
    { "ecmway1", 3,  5, "eccway12" },
    { "ecmway1a", 1,  2, "eccway13" },
    { "ecmway1a", 2,  3, "eccway13" },
    { "ecmway1a", 3,  4, "eccway13" },
    { "ecopen1", 1,  2, "ecpway1" },
    { "ecopen1", 2,  2, "ecoway3a" },
    { "ecopen1", 3,  2, "ecoway3a" },
    { "ecopen1a", 1,  3, "ecpway1a" },
    { "ecopen1a", 2,  5, "ecoway2a" },
    { "ecopen1a", 3,  6, "ecoway2a" },
    { "ecopen2", 1,  4, "ecopen4a" },
    { "ecopen2", 2,  4, "ecopen4a" },
    { "ecopen2", 3,  5, "ecopen4a" },
    { "ecopen2a", 1,  1, "eccway11" },
    { "ecopen2a", 2,  1, "eccway41" },
    { "ecopen2a", 3,  1, "eccway41" },
    { "ecopen3", 1,  1, "eccway21" },
    { "ecopen3", 2,  1, "eccway12" },
    { "ecopen3", 3,  2, "eccway21" },
    { "ecopen3a", 1,  2, "eccway22" },
    { "ecopen3a", 2,  3, "eccway13" },
    { "ecopen3a", 3,  4, "eccway13" },
    { "ecopen4", 1,  4, "ecopen4a" },
    { "ecopen4", 2,  4, "ecopen4a" },
    { "ecopen4", 3,  5, "ecopen4a" },
    { "ecopen4a", 1,  3, "ecoway1" },
    { "ecopen4a", 2,  3, "ecoway1" },
    { "ecopen4a", 3,  4, "ecoway1" },
    { "ecoway1", 1,  2, "ecopen3" },
    { "ecoway1", 2,  2, "ecopen3" },
    { "ecoway1", 3,  3, "ecopen3" },
    { "ecoway1a", 1,  2, "eciway12" },
    { "ecoway1a", 2,  2, "eciway12" },
    { "ecoway1a", 3,  3, "eciway12" },
    { "ecoway2", 1,  2, "ecopen3" },
    { "ecoway2", 2,  2, "ecopen3" },
    { "ecoway2", 3,  3, "ecopen3" },
    { "ecoway2a", 1,  3, "ecopen3a" },
    { "ecoway2a", 2,  4, "ecopen3a" },
    { "ecoway2a", 3,  5, "ecopen3a" },
    { "ecoway3", 1,  5, "ecmway1" },
    { "ecoway3", 2,  2, "ecmway1" },
    { "ecoway3", 3,  0, "" },
    { "ecoway3a", 1,  3, "ecmway1a" },
    { "ecoway3a", 2,  1, "eccway41" },
    { "ecoway3a", 3,  1, "eccway41" },
    { "ecpway1", 1,  1, "eccway21" },
    { "ecpway1", 2,  3, "eccway21" },
    { "ecpway1", 3,  2, "eccway21" },
    { "ecpway1a", 1,  2, "eccway22" },
    { "ecpway1a", 2,  4, "eccway22" },
    { "ecpway1a", 3,  5, "eccway22" },
};
static const int EP_HOP_COUNT = (int)(sizeof(EP_HOPS)/sizeof(EP_HOPS[0]));

// The next hop from `field` toward contact point `point`, or nullptr when this
// field cannot reach it on foot. `outHops` receives the remaining count.
static const char* EpNextHop(const char* field, int point, int* outHops)
{
    if (outHops) *outHops = -1;
    if (!field) return nullptr;
    for (int i = 0; i < EP_HOP_COUNT; i++) {
        if (EP_HOPS[i].point != (uint8_t)point) continue;
        if (_stricmp(EP_HOPS[i].field, field) != 0) continue;
        if (outHops) *outHops = (int)EP_HOPS[i].hops;
        return EP_HOPS[i].next;
    }
    return nullptr;
}

// Is this one of the fields the run takes place in at all?
static bool EpIsCityField(const char* field)
{
    return field && (field[0] == 'e' || field[0] == 'E') &&
                    (field[1] == 'c' || field[1] == 'C');
}
