// field_disc3_space.inl -- #111, the space rescue: closing on Rinoa.
// PART OF field_disc3.inl. Do NOT compile standalone.
//
// The whole game is "keep her centred", and the mod's job is to turn two signed
// numbers into four words. The verdict is taken once, at the end of a 90-second
// approach, so the steering call has to be continuous and cheap to listen to --
// a bearing every second, and a tone the moment the box is entered or lost.

namespace Space {

static const uint16_t SS_ID = SR_FIELD_ID;      // 878, derived; name is the backstop

static bool   s_on        = false;
static bool   s_briefed   = false;
static bool   s_skip      = false;
static bool   s_wasIn     = false;      // inside the win box last tick
static DWORD  s_lastCall  = 0;
static char   s_lastWord[24] = "";
static const DWORD SP_CALL_MS = 1000;   // one steering call a second

static void Reset()
{
    s_on = false; s_briefed = false; s_skip = false; s_wasIn = false;
    s_lastCall = 0; s_lastWord[0] = '\0';
}

static bool Here()
{
    const char* why = "";
    return D3Here(SS_ID, "ssspace3", &why);
}

static bool ReadXY(int32_t* x, int32_t* y)
{
    return D3ReadI32(SR_ADDR_X, x) && D3ReadI32(SR_ADDR_Y, y);
}

// The word for a D-pad mask.
//
// v0.55.0: this deliberately does NOT go through GardenBattle::CopyKeyName.
// That table has four slots and they are the Garden battle's four ACTION
// buttons (BTN_PUNCH 16, BTN_KICK 64, BTN_BLOCK 128, BTN_HEAVY 32); the D-pad
// bits are not in it, so SlotFor() returns nullptr and CopyKeyName writes the
// literal "?" -- it never leaves the buffer empty. Wiring the brief through it
// would have made the mod say "? and ? move you left and right", and because
// the host probe STUBBED CopyKeyName the stub was perfectly happy. Same lesson
// as button_map_rescue.inl's C2653: a stub is a statement about an interface,
// not evidence that the interface exists.
//
// Direction does not need learning anyway. Every direction in this mod is the
// arrow keys -- it is what auto-drive injects (SC_UP/SC_DOWN/SC_LEFT/SC_RIGHT
// in field_nav_state.inl) and what the GPS and the catalog already say to the
// player. So the words are fixed, and they are the ones he already hears.
static const char* SrWord(uint16_t mask)
{
    return (mask == SR_MASK_LEFT)  ? "left"
         : (mask == SR_MASK_RIGHT) ? "right"
         : (mask == SR_MASK_UP)    ? "up"
         : (mask == SR_MASK_DOWN)  ? "down" : "";
}

static void Brief()
{
    D3Say("SPACE",
          "Reaching Rinoa. Steer toward her with the arrow keys and hold her in "
          "the middle. Diagonals count -- hold two arrows together. I will call "
          "the direction once a second, and a tone means she is centred; hold it "
          "there. Only where she is at the very end counts. F9 to skip.", true);
}

// The steering call. Two axes, worst first, so one short phrase carries the
// most useful correction.
static void CallIt(int32_t x, int32_t y, bool force)
{
    const uint16_t mx = SrMaskForX((int)x);
    const uint16_t my = SrMaskForY((int)y);
    char word[64] = "";

    if (!mx && !my) {
        snprintf(word, sizeof(word), "centred");
    } else {
        const int ax = x < 0 ? -x : x, ay = y < 0 ? -y : y;
        const bool xFirst = (ax >= ay);
        const uint16_t first  = xFirst ? mx : my;
        const uint16_t second = xFirst ? my : mx;
        const int      fv     = xFirst ? (int)x : (int)y;
        const int      clamp  = xFirst ? SR_CLAMP_X : SR_CLAMP_Y;
        const char* kf = SrWord(first);
        const char* ks = SrWord(second);
        if (second) snprintf(word, sizeof(word), "%s%s and %s", SrBand(fv, clamp), kf, ks);
        else        snprintf(word, sizeof(word), "%s%s", SrBand(fv, clamp), kf);
    }
    if (!force && strcmp(word, s_lastWord) == 0) return;
    strncpy(s_lastWord, word, sizeof(s_lastWord) - 1);
    s_lastWord[sizeof(s_lastWord) - 1] = '\0';
    ScreenReader::Speak(word, true);
    Log::Field("FieldNavigation: [SPACE] x=%ld y=%ld -> \"%s\"", (long)x, (long)y, word);
}

static void Update(bool slash, bool f9)
{
    if (!Here()) {
        if (s_on) { Log::Field("FieldNavigation: [SPACE] left ssspace3"); Reset(); }
        return;
    }
    if (!s_on) {
        s_on = true;
        Log::Field("FieldNavigation: [SPACE] entered ssspace3 (id %u)", (unsigned)D3FieldId());
    }

    int32_t x = 0, y = 0;
    if (!ReadXY(&x, &y)) return;
    // Outside the clamp the scene has not started writing yet; saying anything
    // then is the "laguna=216" mistake from the dragon fight in another form.
    if (x > SR_CLAMP_X || x < -SR_CLAMP_X || y > SR_CLAMP_Y || y < -SR_CLAMP_Y) return;

    if (!s_briefed) { s_briefed = true; Brief(); }

    if (f9 && !s_skip) {
        s_skip = true;
        D3Say("SPACE", "Skip on. Holding her centred -- the rescue will complete on its own.", true);
        Log::Field("FieldNavigation: [SPACE] skip armed at x=%ld y=%ld", (long)x, (long)y);
    }

    // THE SKIP. The verdict reads exactly these two variables, once, at the end
    // of the approach. Holding both at zero makes the game's own bytecode take
    // its own win branch -- var[1035]=1, var[256]=2564, MAPJUMPO 877 are all
    // the game's. Nothing is forged and no transition is synthesised. It has to
    // be held every tick because the key handlers keep adding to the same two
    // variables; a one-shot write would be undone by the next frame the player
    // leans on a direction.
    if (s_skip) {
        D3WriteI32(SR_ADDR_X, 0);
        D3WriteI32(SR_ADDR_Y, 0);
        return;
    }

    const DWORD now = GetTickCount();
    const bool in = SrCentred((int)x, (int)y);
    if (in != s_wasIn) {
        s_wasIn = in;
        GardenBattle::PlayTone();
        Log::Field("FieldNavigation: [SPACE] %s the box at x=%ld y=%ld",
                   in ? "entered" : "lost", (long)x, (long)y);
        CallIt(x, y, true);
        s_lastCall = now;
        return;
    }
    if (slash) { CallIt(x, y, true); s_lastCall = now; return; }
    if (now - s_lastCall >= SP_CALL_MS) { s_lastCall = now; CallIt(x, y, false); }
}

} // namespace Space
