// field_disc3_esthar.inl -- #110, the Esthar Lunatic Pandora run.
// PART OF field_disc3.inl. Do NOT compile standalone.
//
// What the mod adds: the clock, which contact point is next and whether its
// window is open, and -- the part that makes it playable at all -- which exit
// to take from wherever the player is standing. A sighted player gets three
// pictures of the city; there is nothing here to read otherwise.

namespace Esthar {

// Derived ids (see the header of field_disc3.inl). Detection is id OR name, so
// these being wrong costs responsiveness, not the feature.
static const uint16_t EC_ID_LO = 407, EC_ID_HI = 453;

static int  s_lastPoint = -1;
static bool s_lastOpen  = false;
static int  s_lastMin   = -1;
static char s_lastField[32] = "";
static bool s_greeted   = false;

static void Reset()
{
    s_lastPoint = -1; s_lastOpen = false; s_lastMin = -1;
    s_lastField[0] = '\0'; s_greeted = false;
}

// The run is live only while the mission byte says so. Outside it the same
// fields are an ordinary city and must stay silent.
static bool RunLive()
{
    uint8_t m = 0;
    if (!D3ReadU8(D3VarAddr(EP_VAR_MISSION), &m)) return false;
    return m == EP_MISSION_LIVE;
}

// NAME ONLY. Same reasoning as the Propagator module: the ec id range is
// derived, a clock and a route are not reflex-timed, and a derived range that
// is wrong would put Pandora chatter into some unrelated field rather than
// merely staying silent. The mission byte gate (var[672]==19) is a second
// lock, but two locks are only as good as the weaker one is honest. The id is
// logged so a single BAT settles the derivation.
static bool InCity()
{
    if (!EpIsCityField(D3FieldName())) return false;
    const uint16_t id = D3FieldId();
    if (id < EC_ID_LO || id > EC_ID_HI) {
        static bool s_warned = false;
        if (!s_warned) {
            s_warned = true;
            Log::Field("FieldNavigation: [ESTHAR] '%s' is id %u, OUTSIDE the derived range "
                       "%u..%u -- the ec-block derivation is wrong; the feature still works "
                       "(it is name-driven) but fix the range",
                       D3FieldName(), (unsigned)id, (unsigned)EC_ID_LO, (unsigned)EC_ID_HI);
        }
    }
    return true;
}

static int Seconds()
{
    uint16_t mirror = 0;
    if (D3ReadU16(D3VarAddr(EP_VAR_TIMER), &mirror) && mirror <= 1300) return (int)mirror;
    int32_t eng = 0;
    if (D3ReadI32(EP_TIMER_ADDR, &eng) && eng >= 0 && eng <= 1300) return eng;
    return -1;
}

// The full readout, on "/" and on arriving in a new field.
static void Announce(int t, bool full)
{
    const EstharPhase p = EpPhaseFor(t);
    char clock[64], line[320];
    EpClock(t, clock, sizeof(clock));
    const char* nm = D3FieldName();
    int hops = -1;
    const char* next = EpNextHop(nm, p.point, &hops);

    if (hops == 0) {
        snprintf(line, sizeof(line),
                 "%s left. Contact point %d, %s. You are here -- %s",
                 clock, p.point, EpPointPlace(p.point),
                 p.open ? "the window is OPEN, wait for it."
                        : "wait here, the window has not opened yet.");
    } else if (next && *next) {
        char untilTxt[64];
        if (p.open) snprintf(untilTxt, sizeof(untilTxt), "open now");
        else        { char u[48]; EpClock(p.untilOpen, u, sizeof(u));
                      snprintf(untilTxt, sizeof(untilTxt), "opens in %s", u); }
        snprintf(line, sizeof(line),
                 "%s left. Contact point %d, %s, %s. %d field%s to go -- head for %s.",
                 clock, p.point, EpPointPlace(p.point), untilTxt,
                 hops, hops == 1 ? "" : "s", next);
    } else {
        snprintf(line, sizeof(line),
                 "%s left. Contact point %d, %s. No route from here on foot -- "
                 "go back the way you came.",
                 clock, p.point, EpPointPlace(p.point));
    }
    D3Say("ESTHAR", line, full);
}

static void Update(bool slash)
{
    if (!InCity() || !RunLive()) {
        if (s_greeted) { Log::Field("FieldNavigation: [ESTHAR] run over or left the city"); Reset(); }
        return;
    }
    const char* why = "";
    D3Here(0, "", &why);   // no-op; the id/name logging happens per field below

    const int t = Seconds();
    if (t < 0) return;

    if (!s_greeted) {
        s_greeted = true;
        Log::Field("FieldNavigation: [ESTHAR] run live: field '%s' id %u, %d seconds on the clock",
                   D3FieldName(), (unsigned)D3FieldId(), t);
        D3Say("ESTHAR",
              "Lunatic Pandora run. Slash at any time for the clock, the next contact "
              "point and which way to go.", true);
    }

    const char* nm = D3FieldName();
    const bool movedField = (nm && *nm && _stricmp(nm, s_lastField) != 0);
    if (movedField) {
        strncpy(s_lastField, nm, sizeof(s_lastField) - 1);
        s_lastField[sizeof(s_lastField) - 1] = '\0';
        int hops = -1;
        const EstharPhase p = EpPhaseFor(t);
        const char* next = EpNextHop(nm, p.point, &hops);
        Log::Field("FieldNavigation: [ESTHAR] entered '%s' (id %u) t=%d point=%d open=%d "
                   "hops=%d next='%s'",
                   nm, (unsigned)D3FieldId(), t, p.point, (int)p.open, hops, next ? next : "-");
    }

    const EstharPhase p = EpPhaseFor(t);

    // The two transitions worth interrupting for: a window opening, and the
    // target moving on to the next point because the last one lapsed.
    if (p.point != s_lastPoint && s_lastPoint != -1) {
        char b[192];
        snprintf(b, sizeof(b), "Contact point %d has passed. Next is point %d, %s.",
                 s_lastPoint, p.point, EpPointPlace(p.point));
        D3Say("ESTHAR", b, true);
        Announce(t, false);
    } else if (p.open && !s_lastOpen) {
        char b[192];
        int hops = -1;
        const char* next = EpNextHop(D3FieldName(), p.point, &hops);
        if (hops == 0) snprintf(b, sizeof(b), "Contact point %d is OPEN and you are on it.", p.point);
        else if (next && *next)
            snprintf(b, sizeof(b), "Contact point %d is OPEN. %d field%s to go -- head for %s.",
                     p.point, hops, hops == 1 ? "" : "s", next);
        else snprintf(b, sizeof(b), "Contact point %d is OPEN.", p.point);
        D3Say("ESTHAR", b, true);
    } else if (movedField) {
        Announce(t, false);
    }
    s_lastPoint = p.point; s_lastOpen = p.open;

    // A minute tick, quiet and non-interrupting, so time passing is audible
    // without having to ask. Only in the last five minutes, where it matters.
    const int mins = t / 60;
    if (mins != s_lastMin) {
        if (s_lastMin >= 0 && t <= 300 && (t % 60) == 0) {
            char b[64];
            snprintf(b, sizeof(b), "%d minute%s.", mins, mins == 1 ? "" : "s");
            D3Say("ESTHAR", b, false);
        }
        s_lastMin = mins;
    }

    if (slash) Announce(t, true);
}

} // namespace Esthar
