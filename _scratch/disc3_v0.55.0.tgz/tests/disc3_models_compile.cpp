// disc3_models_compile -- the three disc-3 blockers' pure models, checked
// against the bytecode they were read out of.
//
// WHY THIS EXISTS
// ---------------
// Aaron cannot reach any of these scenes for hours, so there is no BAT to fall
// back on and every number here has to be right on the first build. Each
// assertion below names the field, entity::method and dword it came from, and
// the fixtures are the game's own script words rather than my transcription of
// them -- a fixture addressed through the constant under test agrees with it by
// construction, which is the lesson v0.51.0 cost two BATs to relearn.
#include <cstdio>
#include <cstring>
#include <cstdint>
#include <cstddef>
#include <string>
#ifndef _WIN32
#define _stricmp strcasecmp
#include <strings.h>
#endif

#include "esthar_pandora_model.inl"
#include "space_rescue_model.inl"
#include "propagator_model.inl"

static int bad = 0;
static void check(bool ok, const char* what)
{
    if (!ok) { std::printf("  BAD: %s\n", what); bad++; }
}
static void checkStr(const char* got, const char* want, const char* what)
{
    if (strcmp(got, want) != 0) {
        std::printf("  BAD: %s\n       got  \"%s\"\n       want \"%s\"\n", what, got, want);
        bad++;
    }
}

// ---------------------------------------------------------------- JSM decode
static void dec(uint32_t w, int* op, int* par, bool* hasPar)
{
    if ((w & 0xFF000000u) == 0) { *op = (int)(w & 0xFFFFFF); *par = 0; *hasPar = false; return; }
    *op = (int)(w >> 24);
    int p = (int)(w & 0xFFFFFF);
    if (p & 0x800000) p -= 0x1000000;
    *par = p; *hasPar = true;
}
enum { OP_OPER = 0x01, OP_JPF = 0x03, OP_PSHN_L = 0x07, OP_PSHM_B = 0x0A,
       OP_POPM_B = 0x0B, OP_PSHM_W = 0x0C, OP_PUSHL_L = 0x12, OP_POPL_L = 0x0F,
       OP_EQ = 6, OP_GT = 7, OP_LT = 9, OP_NEG = 5, OP_BTN_HELD = 0x6D,
       OP_AND = 12, OP_OR = 13, OP_NOT = 15, OP_JMP = 0x02 };

// ---- eccway11 :: Disp::default, dwords 5412..5460 -------------------------
// The ladder that decides which contact point is drawn and whether it is
// highlighted. Byte-identical in all 21 minigame fields. EXTRACTED, not typed:
// the first hand-written version of this fixture had OPER GT as 6 instead of 7
// and the probe passed anyway, because the same wrong constant was on both
// sides of the comparison.
static const uint32_t ECCWAY11_LADDER[] = {
    0x0C000400, 0x070002D0, 0x01000007, 0x03000010, 0x0C000400, 0x07000384,
    0x01000007, 0x03000005, 0x07000001, 0x0700010E, 0x14000011, 0x02000004,
    0x07000001, 0x07000111, 0x14000011, 0x07000001, 0x07000141, 0x1600001B,
    0x02000022, 0x0C000400, 0x0700012C, 0x01000007, 0x03000010, 0x0C000400,
    0x07000258, 0x01000007, 0x03000005, 0x07000001, 0x0700010F, 0x14000011,
    0x02000004, 0x07000001, 0x07000112, 0x14000011, 0x07000001, 0x07000145,
    0x1600001C, 0x0200000F, 0x0C000400, 0x070000B4, 0x01000007, 0x03000005,
    0x07000001, 0x07000110, 0x14000011, 0x02000004, 0x07000001, 0x07000113,
    0x14000011,
};

// ---- ssspace3 :: rinoa::default, dwords 225..244 --------------------------
// The verdict. Taken exactly once, after the approach animation.
static const uint32_t SSSPACE3_VERDICT[] = {
    0x12000410, 0x070000B4, 0x01000005, 0x01000007, 0x03000010, 0x12000410,
    0x070000B4, 0x01000009, 0x0300000C, 0x12000414, 0x070000B4, 0x01000005,
    0x01000007, 0x03000007, 0x12000414, 0x070000B4, 0x01000009, 0x03000003,
    0x07000001, 0x0B00040B,
};

// ---- ssspace3 :: director1::default, dwords 1147..1321 -------------------------
// THE DISPATCH TREE, and the reason the four mask constants are not a guess.
//
// v0.55.0: the earlier version of this probe asserted
// `SrMaskForX(4000) == SR_MASK_RIGHT`, which is the constant on both sides of
// its own test -- swapping SR_MASK_LEFT and SR_MASK_RIGHT in the model left it
// passing. (Mutation-tested; it survived.) So the mapping is now DERIVED here
// instead: director1 tests the four D-pad bits in a nested tree and, in each
// leaf, writes a direction code to var[1024] and REQSWs the matching handler.
// rinoa::keyl's own first instruction is `var[1024] == 1`, keyr's is `== 2`,
// keyu's `== 3`, keyd's `== 4`, so the codes name the directions without this
// probe having to assert which bit is which. Walking the tree therefore yields
// bit -> direction out of the shipped bytes, and THAT is what the model's
// constants are checked against.
static const int      DIRECTOR1_BASE = 1147;
static const uint32_t DIRECTOR1_DISPATCH[] = {
    0x07008000, 0x0000006D, 0x08000000, 0x07000001, 0x01000006, 0x0300003A,
    0x07001000, 0x0000006D, 0x08000000, 0x07000001, 0x01000006, 0x03000010,
    0x07000006, 0x0B000400, 0x07000002, 0x0000003C, 0x1200041C, 0x0A00040A,
    0x01000001, 0x0F00041C, 0x07000002, 0x07000012, 0x14000002, 0x07000002,
    0x07000022, 0x14000003, 0x02000024, 0x07004000, 0x0000006D, 0x08000000,
    0x07000001, 0x01000006, 0x03000010, 0x07000008, 0x0B000400, 0x07000002,
    0x0000003C, 0x1200041C, 0x0A00040A, 0x01000001, 0x0F00041C, 0x07000002,
    0x07000015, 0x14000002, 0x07000002, 0x07000024, 0x14000003, 0x0200000F,
    0x07000001, 0x0B000400, 0x07000002, 0x0000003C, 0x1200041C, 0x0A00040A,
    0x01000001, 0x0F00041C, 0x07000002, 0x0700000E, 0x14000002, 0x07000002,
    0x0700001D, 0x14000003, 0x02000071, 0x07002000, 0x0000006D, 0x08000000,
    0x07000001, 0x01000006, 0x0300003A, 0x07001000, 0x0000006D, 0x08000000,
    0x07000001, 0x01000006, 0x03000010, 0x07000005, 0x0B000400, 0x07000002,
    0x0000003C, 0x1200041C, 0x0A00040A, 0x01000001, 0x0F00041C, 0x07000002,
    0x07000013, 0x14000002, 0x07000002, 0x07000021, 0x14000003, 0x02000024,
    0x07004000, 0x0000006D, 0x08000000, 0x07000001, 0x01000006, 0x03000010,
    0x07000007, 0x0B000400, 0x07000002, 0x0000003C, 0x1200041C, 0x0A00040A,
    0x01000001, 0x0F00041C, 0x07000002, 0x07000014, 0x14000002, 0x07000002,
    0x07000023, 0x14000003, 0x0200000F, 0x07000002, 0x0B000400, 0x07000002,
    0x0000003C, 0x1200041C, 0x0A00040A, 0x01000001, 0x0F00041C, 0x07000002,
    0x0700000F, 0x14000002, 0x07000002, 0x0700001E, 0x14000003, 0x02000032,
    0x07001000, 0x0000006D, 0x08000000, 0x07000001, 0x01000006, 0x03000010,
    0x07000003, 0x0B000400, 0x07000002, 0x0000003C, 0x1200041C, 0x0A00040A,
    0x01000001, 0x0F00041C, 0x07000002, 0x07000010, 0x14000002, 0x07000002,
    0x0700001F, 0x14000003, 0x0200001D, 0x07004000, 0x0000006D, 0x08000000,
    0x07000001, 0x01000006, 0x03000010, 0x07000004, 0x0B000400, 0x07000002,
    0x0000003C, 0x1200041C, 0x0A00040A, 0x01000001, 0x0F00041C, 0x07000002,
    0x07000011, 0x14000002, 0x07000002, 0x07000020, 0x14000003, 0x02000008,
    0x07000009, 0x0B000400, 0x07000002, 0x0000003C, 0x07000002, 0x07000025,
    0x14000003,
};

// ---- ssspace3 :: rinoa::key{l,r,u,d}, the unboosted arms ------------------
// Each is: push the axis var, push the step var, OPER, pop the axis var. The
// OPER is the whole sign convention.
static const uint32_t KEYL_ARM[] = {
    0x12000410, 0x0A00040A, 0x01000000, 0x0F000410,
};


static const uint32_t KEYR_ARM[] = {
    0x12000410, 0x0A00040A, 0x01000001, 0x0F000410,
};


static const uint32_t KEYU_ARM[] = {
    0x12000414, 0x0A00040A, 0x01000001, 0x0F000414,
};


static const uint32_t KEYD_ARM[] = {
    0x12000414, 0x0A00040A, 0x01000000, 0x0F000414,
};

// ===========================================================================
// THE PROPAGATOR PAIRING, TAKEN OUT OF ALL EIGHT SCRIPTS (#112)
// ===========================================================================
//
// v0.55.0. The previous version of this probe restated the pairing table as a
// literal and compared the model against it -- two copies of the same belief.
// Mutation-testing proved the point: changing PG_PENDING_MASK from 0x04 to
// 0x08 survived BOTH probes, because nothing anywhere read the mask out of the
// game.
//
// So it is read out of the game now. Two windows per Propagator, extracted
// programmatically from the shipped .jsm files, never typed:
//
//   *_GATE     the first six dwords of alien0N::defalut --
//                  PSHM_B var[446] ; PSHN_L <own> ; AND ; PSHN_L 0 ; EQ
//              which is "am I already dead?", and names the OWN bit.
//
//   *_RESOLVE  from the pending test to the end of the mercy block --
//                  PSHM_B var[445] ; PSHN_L <pendMask> ; AND ; ... ; JPF
//                  [no kill pending]  var[445] |= mask ; var[446] |= own ;
//                                     var[447] = own
//                  [pending]          PSHM_B var[447] ; PSHN_L <partner> ; AND
//                    [not my partner] var[446] &= ~var[447]   <- RESURRECTS it
//                                     var[446] |= own ; var[447] = own
//                    [my partner]     var[445] &= ~mask ; var[446] |= own
//                  then               var[437]++ ; if (var[437] > 24)
//                                     var[446] = 255
//
//              which names the PENDING MASK, the PARTNER bit, and the mercy
//              threshold -- and shows the resurrection that is the whole
//              reason the mod has to tell the player what to kill next.
//
// The eight partner bits are then checked to CLOSE: every A's partner is a B
// whose partner is A. That is a property of the eight scripts, and the model
// is checked against it rather than against a copy of itself.

// rgair1.jsm dwords 459..464 -- alien01::defalut, start through the am-I-dead gate
static const uint32_t RGAIR1_GATE[] = {
    0x05000010, 0x0A0001BE, 0x07000001, 0x0100000C, 0x07000000, 0x01000006,
};

// rgair1.jsm dwords 486..540 -- alien01::defalut, pair resolution + mercy
static const uint32_t RGAIR1_RESOLVE[] = {
    0x0A0001BD, 0x07000004, 0x0100000C, 0x07000000, 0x01000006, 0x0300000C,
    0x0A0001BD, 0x07000004, 0x0100000D, 0x0B0001BD, 0x0A0001BE, 0x07000001,
    0x0100000D, 0x0B0001BE, 0x07000001, 0x0B0001BF, 0x0200001D, 0x0A0001BF,
    0x07000080, 0x0100000C, 0x07000000, 0x01000006, 0x0300000D, 0x0A0001BE,
    0x0A0001BF, 0x0100000F, 0x0100000C, 0x0B0001BE, 0x0A0001BE, 0x07000001,
    0x0100000D, 0x0B0001BE, 0x07000001, 0x0B0001BF, 0x0200000B, 0x0A0001BD,
    0x07FFFFFB, 0x0100000C, 0x0B0001BD, 0x0A0001BE, 0x07000001, 0x0100000D,
    0x0B0001BE, 0x07000001, 0x0B0001BF, 0x0A0001B5, 0x07000001, 0x01000000,
    0x0B0001B5, 0x0A0001B5, 0x07000018, 0x01000007, 0x03000003, 0x070000FF,
    0x0B0001BE,
};

// rgroad1.jsm dwords 185..190 -- alien01::defalut, start through the am-I-dead gate
static const uint32_t RGROAD1_GATE[] = {
    0x05000010, 0x0A0001BE, 0x07000002, 0x0100000C, 0x07000000, 0x01000006,
};

// rgroad1.jsm dwords 213..267 -- alien01::defalut, pair resolution + mercy
static const uint32_t RGROAD1_RESOLVE[] = {
    0x0A0001BD, 0x07000004, 0x0100000C, 0x07000000, 0x01000006, 0x0300000C,
    0x0A0001BD, 0x07000004, 0x0100000D, 0x0B0001BD, 0x0A0001BE, 0x07000002,
    0x0100000D, 0x0B0001BE, 0x07000002, 0x0B0001BF, 0x0200001D, 0x0A0001BF,
    0x07000020, 0x0100000C, 0x07000000, 0x01000006, 0x0300000D, 0x0A0001BE,
    0x0A0001BF, 0x0100000F, 0x0100000C, 0x0B0001BE, 0x0A0001BE, 0x07000002,
    0x0100000D, 0x0B0001BE, 0x07000002, 0x0B0001BF, 0x0200000B, 0x0A0001BD,
    0x07FFFFFB, 0x0100000C, 0x0B0001BD, 0x0A0001BE, 0x07000002, 0x0100000D,
    0x0B0001BE, 0x07000002, 0x0B0001BF, 0x0A0001B5, 0x07000001, 0x01000000,
    0x0B0001B5, 0x0A0001B5, 0x07000018, 0x01000007, 0x03000003, 0x070000FF,
    0x0B0001BE,
};

// rgroad2.jsm dwords 204..209 -- alien01::defalut, start through the am-I-dead gate
static const uint32_t RGROAD2_GATE[] = {
    0x0500000A, 0x0A0001BE, 0x07000004, 0x0100000C, 0x07000000, 0x01000006,
};

// rgroad2.jsm dwords 311..365 -- alien01::defalut, pair resolution + mercy
static const uint32_t RGROAD2_RESOLVE[] = {
    0x0A0001BD, 0x07000004, 0x0100000C, 0x07000000, 0x01000006, 0x0300000C,
    0x0A0001BD, 0x07000004, 0x0100000D, 0x0B0001BD, 0x0A0001BE, 0x07000004,
    0x0100000D, 0x0B0001BE, 0x07000004, 0x0B0001BF, 0x0200001D, 0x0A0001BF,
    0x07000008, 0x0100000C, 0x07000000, 0x01000006, 0x0300000D, 0x0A0001BE,
    0x0A0001BF, 0x0100000F, 0x0100000C, 0x0B0001BE, 0x0A0001BE, 0x07000004,
    0x0100000D, 0x0B0001BE, 0x07000004, 0x0B0001BF, 0x0200000B, 0x0A0001BD,
    0x07FFFFFB, 0x0100000C, 0x0B0001BD, 0x0A0001BE, 0x07000004, 0x0100000D,
    0x0B0001BE, 0x07000004, 0x0B0001BF, 0x0A0001B5, 0x07000001, 0x01000000,
    0x0B0001B5, 0x0A0001B5, 0x07000018, 0x01000007, 0x03000003, 0x070000FF,
    0x0B0001BE,
};

// rgroad3.jsm dwords 650..659 -- alien02::defalut, start through the am-I-dead gate
static const uint32_t RGROAD3_GATE[] = {
    0x0500001E, 0x0C000100, 0x07000BBF, 0x01000008, 0x030000F5, 0x0A0001BE,
    0x07000008, 0x0100000C, 0x07000000, 0x01000006,
};

// rgroad3.jsm dwords 822..876 -- alien02::defalut, pair resolution + mercy
static const uint32_t RGROAD3_RESOLVE[] = {
    0x0A0001BD, 0x07000004, 0x0100000C, 0x07000000, 0x01000006, 0x0300000C,
    0x0A0001BD, 0x07000004, 0x0100000D, 0x0B0001BD, 0x0A0001BE, 0x07000008,
    0x0100000D, 0x0B0001BE, 0x07000008, 0x0B0001BF, 0x0200001D, 0x0A0001BF,
    0x07000004, 0x0100000C, 0x07000000, 0x01000006, 0x0300000D, 0x0A0001BE,
    0x0A0001BF, 0x0100000F, 0x0100000C, 0x0B0001BE, 0x0A0001BE, 0x07000008,
    0x0100000D, 0x0B0001BE, 0x07000008, 0x0B0001BF, 0x0200000B, 0x0A0001BD,
    0x07FFFFFB, 0x0100000C, 0x0B0001BD, 0x0A0001BE, 0x07000008, 0x0100000D,
    0x0B0001BE, 0x07000008, 0x0B0001BF, 0x0A0001B5, 0x07000001, 0x01000000,
    0x0B0001B5, 0x0A0001B5, 0x07000018, 0x01000007, 0x03000003, 0x070000FF,
    0x0B0001BE,
};

// rghang1.jsm dwords 248..253 -- alien01::defalut, start through the am-I-dead gate
static const uint32_t RGHANG1_GATE[] = {
    0x05000009, 0x0A0001BE, 0x07000010, 0x0100000C, 0x07000000, 0x01000006,
};

// rghang1.jsm dwords 448..502 -- alien01::defalut, pair resolution + mercy
static const uint32_t RGHANG1_RESOLVE[] = {
    0x0A0001BD, 0x07000004, 0x0100000C, 0x07000000, 0x01000006, 0x0300000C,
    0x0A0001BD, 0x07000004, 0x0100000D, 0x0B0001BD, 0x0A0001BE, 0x07000010,
    0x0100000D, 0x0B0001BE, 0x07000010, 0x0B0001BF, 0x0200001D, 0x0A0001BF,
    0x07000040, 0x0100000C, 0x07000000, 0x01000006, 0x0300000D, 0x0A0001BE,
    0x0A0001BF, 0x0100000F, 0x0100000C, 0x0B0001BE, 0x0A0001BE, 0x07000010,
    0x0100000D, 0x0B0001BE, 0x07000010, 0x0B0001BF, 0x0200000B, 0x0A0001BD,
    0x07FFFFFB, 0x0100000C, 0x0B0001BD, 0x0A0001BE, 0x07000010, 0x0100000D,
    0x0B0001BE, 0x07000010, 0x0B0001BF, 0x0A0001B5, 0x07000001, 0x01000000,
    0x0B0001B5, 0x0A0001B5, 0x07000018, 0x01000007, 0x03000003, 0x070000FF,
    0x0B0001BE,
};

// rghang2.jsm dwords 587..592 -- alien01::defalut, start through the am-I-dead gate
static const uint32_t RGHANG2_GATE[] = {
    0x05000025, 0x0A0001BE, 0x07000020, 0x0100000C, 0x07000000, 0x01000006,
};

// rghang2.jsm dwords 702..756 -- alien01::defalut, pair resolution + mercy
static const uint32_t RGHANG2_RESOLVE[] = {
    0x0A0001BD, 0x07000004, 0x0100000C, 0x07000000, 0x01000006, 0x0300000C,
    0x0A0001BD, 0x07000004, 0x0100000D, 0x0B0001BD, 0x0A0001BE, 0x07000020,
    0x0100000D, 0x0B0001BE, 0x07000020, 0x0B0001BF, 0x0200001D, 0x0A0001BF,
    0x07000002, 0x0100000C, 0x07000000, 0x01000006, 0x0300000D, 0x0A0001BE,
    0x0A0001BF, 0x0100000F, 0x0100000C, 0x0B0001BE, 0x0A0001BE, 0x07000020,
    0x0100000D, 0x0B0001BE, 0x07000020, 0x0B0001BF, 0x0200000B, 0x0A0001BD,
    0x07FFFFFB, 0x0100000C, 0x0B0001BD, 0x0A0001BE, 0x07000020, 0x0100000D,
    0x0B0001BE, 0x07000020, 0x0B0001BF, 0x0A0001B5, 0x07000001, 0x01000000,
    0x0B0001B5, 0x0A0001B5, 0x07000018, 0x01000007, 0x03000003, 0x070000FF,
    0x0B0001BE,
};

// rgexit1.jsm dwords 191..196 -- alien01::defalut, start through the am-I-dead gate
static const uint32_t RGEXIT1_GATE[] = {
    0x05000009, 0x0A0001BE, 0x07000040, 0x0100000C, 0x07000000, 0x01000006,
};

// rgexit1.jsm dwords 230..284 -- alien01::defalut, pair resolution + mercy
static const uint32_t RGEXIT1_RESOLVE[] = {
    0x0A0001BD, 0x07000004, 0x0100000C, 0x07000000, 0x01000006, 0x0300000C,
    0x0A0001BD, 0x07000004, 0x0100000D, 0x0B0001BD, 0x0A0001BE, 0x07000040,
    0x0100000D, 0x0B0001BE, 0x07000040, 0x0B0001BF, 0x0200001D, 0x0A0001BF,
    0x07000010, 0x0100000C, 0x07000000, 0x01000006, 0x0300000D, 0x0A0001BE,
    0x0A0001BF, 0x0100000F, 0x0100000C, 0x0B0001BE, 0x0A0001BE, 0x07000040,
    0x0100000D, 0x0B0001BE, 0x07000040, 0x0B0001BF, 0x0200000B, 0x0A0001BD,
    0x07FFFFFB, 0x0100000C, 0x0B0001BD, 0x0A0001BE, 0x07000040, 0x0100000D,
    0x0B0001BE, 0x07000040, 0x0B0001BF, 0x0A0001B5, 0x07000001, 0x01000000,
    0x0B0001B5, 0x0A0001B5, 0x07000018, 0x01000007, 0x03000003, 0x070000FF,
    0x0B0001BE,
};

// rgguest2.jsm dwords 99..104 -- alien01::defalut, start through the am-I-dead gate
static const uint32_t RGGUEST2_GATE[] = {
    0x0500000C, 0x0A0001BE, 0x07000080, 0x0100000C, 0x07000000, 0x01000006,
};

// rgguest2.jsm dwords 157..211 -- alien01::defalut, pair resolution + mercy
static const uint32_t RGGUEST2_RESOLVE[] = {
    0x0A0001BD, 0x07000004, 0x0100000C, 0x07000000, 0x01000006, 0x0300000C,
    0x0A0001BD, 0x07000004, 0x0100000D, 0x0B0001BD, 0x0A0001BE, 0x07000080,
    0x0100000D, 0x0B0001BE, 0x07000080, 0x0B0001BF, 0x0200001D, 0x0A0001BF,
    0x07000001, 0x0100000C, 0x07000000, 0x01000006, 0x0300000D, 0x0A0001BE,
    0x0A0001BF, 0x0100000F, 0x0100000C, 0x0B0001BE, 0x0A0001BE, 0x07000080,
    0x0100000D, 0x0B0001BE, 0x07000080, 0x0B0001BF, 0x0200000B, 0x0A0001BD,
    0x07FFFFFB, 0x0100000C, 0x0B0001BD, 0x0A0001BE, 0x07000080, 0x0100000D,
    0x0B0001BE, 0x07000080, 0x0B0001BF, 0x0A0001B5, 0x07000001, 0x01000000,
    0x0B0001B5, 0x0A0001B5, 0x07000018, 0x01000007, 0x03000003, 0x070000FF,
    0x0B0001BE,
};

struct AlienFix { const char* field; const uint32_t* gate; int gateN;
                  const uint32_t* res;  int resN; };
static const AlienFix ALIEN_FIX[] = {
    { "rgair1", RGAIR1_GATE, (int)(sizeof(RGAIR1_GATE)/sizeof(uint32_t)), RGAIR1_RESOLVE, (int)(sizeof(RGAIR1_RESOLVE)/sizeof(uint32_t)) },
    { "rgroad1", RGROAD1_GATE, (int)(sizeof(RGROAD1_GATE)/sizeof(uint32_t)), RGROAD1_RESOLVE, (int)(sizeof(RGROAD1_RESOLVE)/sizeof(uint32_t)) },
    { "rgroad2", RGROAD2_GATE, (int)(sizeof(RGROAD2_GATE)/sizeof(uint32_t)), RGROAD2_RESOLVE, (int)(sizeof(RGROAD2_RESOLVE)/sizeof(uint32_t)) },
    { "rgroad3", RGROAD3_GATE, (int)(sizeof(RGROAD3_GATE)/sizeof(uint32_t)), RGROAD3_RESOLVE, (int)(sizeof(RGROAD3_RESOLVE)/sizeof(uint32_t)) },
    { "rghang1", RGHANG1_GATE, (int)(sizeof(RGHANG1_GATE)/sizeof(uint32_t)), RGHANG1_RESOLVE, (int)(sizeof(RGHANG1_RESOLVE)/sizeof(uint32_t)) },
    { "rghang2", RGHANG2_GATE, (int)(sizeof(RGHANG2_GATE)/sizeof(uint32_t)), RGHANG2_RESOLVE, (int)(sizeof(RGHANG2_RESOLVE)/sizeof(uint32_t)) },
    { "rgexit1", RGEXIT1_GATE, (int)(sizeof(RGEXIT1_GATE)/sizeof(uint32_t)), RGEXIT1_RESOLVE, (int)(sizeof(RGEXIT1_RESOLVE)/sizeof(uint32_t)) },
    { "rgguest2", RGGUEST2_GATE, (int)(sizeof(RGGUEST2_GATE)/sizeof(uint32_t)), RGGUEST2_RESOLVE, (int)(sizeof(RGGUEST2_RESOLVE)/sizeof(uint32_t)) },
};
static const int ALIEN_FIX_N = (int)(sizeof(ALIEN_FIX)/sizeof(ALIEN_FIX[0]));


int main()
{
    // =====================================================================
    // #110 ESTHAR -- the ladder is the game's branch, transcribed
    // =====================================================================
    {
        // Pull the six thresholds out of the fixture rather than trusting the
        // constants: every PSHN_L that is compared against var[1024].
        int found[6] = {0,0,0,0,0,0}; int nf = 0;
        const int n = (int)(sizeof(ECCWAY11_LADDER)/sizeof(ECCWAY11_LADDER[0]));
        for (int i = 0; i + 2 < n; i++) {
            int o1,p1,o2,p2,o3,p3; bool h1,h2,h3;
            dec(ECCWAY11_LADDER[i],   &o1,&p1,&h1);
            dec(ECCWAY11_LADDER[i+1], &o2,&p2,&h2);
            dec(ECCWAY11_LADDER[i+2], &o3,&p3,&h3);
            if (o1 == OP_PSHM_W && p1 == EP_VAR_TIMER &&
                o2 == OP_PSHN_L && o3 == OP_OPER && p3 == OP_GT && nf < 6)
                found[nf++] = p2;
        }
        check(nf == 5, "**the ladder tests var[1024] against exactly five thresholds**");
        check(found[0] == EP_T_CP1_ARM && found[1] == EP_T_CP1_OPEN &&
              found[2] == EP_T_CP2_ARM && found[3] == EP_T_CP2_OPEN &&
              found[4] == EP_T_CP3_OPEN,
              "**and they are 720 / 900 / 300 / 600 / 180, in that order** -- the "
              "model's constants are the script's own numbers");

        // The briefing's windows, walked one second at a time across every
        // boundary. These are the sentences the player acts on.
        struct { int t; int point; bool open; } W[] = {
            { 1201, 1, false }, { 901, 1, false }, { 900, 1, true  }, { 721, 1, true  },
            {  720, 2, false }, { 601, 2, false }, { 600, 2, true  }, { 301, 2, true  },
            {  300, 3, false }, { 181, 3, false }, { 180, 3, true  }, {   1, 3, true  },
        };
        for (unsigned k = 0; k < sizeof(W)/sizeof(W[0]); k++) {
            EstharPhase p = EpPhaseFor(W[k].t);
            char msg[128];
            snprintf(msg, sizeof(msg),
                     "at T=%d the target is point %d and open=%d", W[k].t, p.point, (int)p.open);
            check(p.point == W[k].point && p.open == W[k].open, msg);
        }
        // The briefing quotes 15:00-12:00, 10:00-5:00, 3:00-0:00. Those are
        // mm:ss of the same numbers; if they ever disagree the mod is lying to
        // the player in the one place he has to trust it.
        check(EP_T_CP1_OPEN == 15*60 && EP_T_CP1_ARM == 12*60, "point 1 is 15:00 down to 12:00");
        check(EP_T_CP2_OPEN == 10*60 && EP_T_CP2_ARM ==  5*60, "point 2 is 10:00 down to 5:00");
        check(EP_T_CP3_OPEN ==  3*60,                          "point 3 is 3:00 down to 0:00");

        char c[64];
        EpClock(905, c, sizeof(c)); checkStr(c, "15 minutes 5 seconds", "the clock reads in words");
        EpClock(60,  c, sizeof(c)); checkStr(c, "1 minute 0 seconds",  "and singular at one minute");
        EpClock(1,   c, sizeof(c)); checkStr(c, "1 second",            "and drops the minutes below one");

        // The route table. Every trigger field is zero hops from its own point,
        // and every row's `next` must itself be a field that is one hop closer.
        int h = -1;
        check(EpNextHop("eciway11", 1, &h) && h == 0, "eciway11 is contact point 1");
        check(EpNextHop("eccway41", 2, &h) && h == 0, "eccway41 is contact point 2");
        check(EpNextHop("ecoway3",  3, &h) && h == 0, "ecoway3 is contact point 3");
        int badHop = 0, rows = 0;
        for (int i = 0; i < EP_HOP_COUNT; i++) {
            const EstharHop& r = EP_HOPS[i];
            rows++;
            if (r.hops == 0) { if (r.next[0] != '\0') badHop++; continue; }
            int nh = -1;
            const char* nx = EpNextHop(r.next, r.point, &nh);
            if (!nx || nh != (int)r.hops - 1) badHop++;
        }
        char m2[128];
        snprintf(m2, sizeof(m2),
                 "**every one of the %d route rows steps exactly one hop closer** (%d broken)",
                 rows, badHop);
        check(badHop == 0, m2);
        check(EpNextHop("bghoke_2", 1, &h) == nullptr, "a field outside Esthar has no route");
        check(EpIsCityField("eccway11") && !EpIsCityField("rgair1"), "and the city test is by prefix");
    }

    // =====================================================================
    // #111 SPACE -- the win box and the direction to press
    // =====================================================================
    {
        // The verdict fixture must be four comparisons against 180 on vars
        // 1040 and 1044, and nothing else.
        int cmp = 0, box = 0;
        const int n = (int)(sizeof(SSSPACE3_VERDICT)/sizeof(SSSPACE3_VERDICT[0]));
        for (int i = 0; i < n; i++) {
            int o,p; bool h; dec(SSSPACE3_VERDICT[i], &o, &p, &h);
            if (o == OP_PUSHL_L && (p == 1040 || p == 1044)) cmp++;
            if (o == OP_PSHN_L && p == SR_WIN_BOX) box++;
        }
        check(cmp == 4 && box == 4,
              "**the verdict is four tests of vars 1040/1044 against 180** -- the "
              "model's win box is the game's, not a tolerance I picked");
        int o,p; bool h;
        dec(SSSPACE3_VERDICT[n-1], &o, &p, &h);
        check(o == OP_POPM_B && p == 1035, "and it writes var[1035], the win flag");
        check((SR_ADDR_X - 0x01CFE9B8u) == 1040 && (SR_ADDR_Y - 0x01CFE9B8u) == 1044,
              "the addresses are those variables' own slots");

        // THE SIGNS. Read out of the key handlers: the mask to press on an axis
        // is the one whose handler moves the variable toward zero. Getting this
        // backwards would actively steer the player away from Rinoa.
        int oX,pX; bool hX;
        dec(KEYL_ARM[2], &oX, &pX, &hX);
        check(oX == OP_OPER && pX == 0, "rinoa::keyl ADDs to X, so LEFT raises it");
        dec(KEYR_ARM[2], &oX, &pX, &hX);
        check(oX == OP_OPER && pX == 1, "rinoa::keyr SUBs from X, so RIGHT lowers it");
        dec(KEYU_ARM[2], &oX, &pX, &hX);
        check(oX == OP_OPER && pX == 1, "rinoa::keyu SUBs from Y, so UP lowers it");
        dec(KEYD_ARM[2], &oX, &pX, &hX);
        check(oX == OP_OPER && pX == 0, "rinoa::keyd ADDs to Y, so DOWN raises it");
        dec(KEYL_ARM[0], &oX, &pX, &hX);
        check(pX == 1040, "keyl operates on X");
        dec(KEYU_ARM[0], &oX, &pX, &hX);
        check(pX == 1044, "keyu operates on Y");

        // ---- bit -> direction, walked out of director1's own tree ----------
        //
        // Each leaf is `PSHN_L <code> ; POPM_B var[1024]`, and the enclosing
        // BTN_HELD tests are the bits that produced it. Walk the tree keeping
        // the set of bits currently known-held, and record the code each leaf
        // writes. A leaf reached with exactly one bit held names that bit.
        {
            const int n = (int)(sizeof(DIRECTOR1_DISPATCH)/sizeof(DIRECTOR1_DISPATCH[0]));
            // bitFor[code] accumulates the mask asserted true on the path.
            uint16_t bitFor[16]; int seen[16];
            for (int k = 0; k < 16; k++) { bitFor[k] = 0; seen[k] = 0; }
            // A straight-line walk is enough: the tree is a chain of
            // `PSHN_L m ; BTN_HELD ; PSHL 0 ; PSHN_L 1 ; OPER EQ ; JPF +d`
            // blocks, and the code between a test and its JPF target is the
            // "held" arm. Track the innermost pending test per position by
            // scanning for tests whose JPF target is beyond the leaf.
            struct { uint16_t mask; int endIdx; } pend[8]; int np = 0;
            for (int i = 0; i < n; i++) {
                int o, p; bool h; dec(DIRECTOR1_DISPATCH[i], &o, &p, &h);
                while (np > 0 && i >= pend[np-1].endIdx) np--;
                if (o == OP_PSHN_L && i + 5 < n) {
                    int o2, p2; bool h2; dec(DIRECTOR1_DISPATCH[i+1], &o2, &p2, &h2);
                    int o6, p6; bool h6; dec(DIRECTOR1_DISPATCH[i+5], &o6, &p6, &h6);
                    if (o2 == OP_BTN_HELD && o6 == OP_JPF && np < 8) {
                        pend[np].mask = (uint16_t)p;
                        pend[np].endIdx = (i + 5) + p6;   // targets are i + rel
                        np++;
                        i += 5;
                        continue;
                    }
                }
                // A leaf write: PSHN_L code ; POPM_B var[1024].
                if (o == OP_PSHN_L && i + 1 < n) {
                    int o2, p2; bool h2; dec(DIRECTOR1_DISPATCH[i+1], &o2, &p2, &h2);
                    if (o2 == OP_POPM_B && p2 == 1024 && p >= 0 && p < 16) {
                        if (np == 1) { bitFor[p] = pend[0].mask; seen[p] = 1; }
                        else if (np > 1) { seen[p] = 2; }   // diagonal, two bits
                    }
                }
            }
            // rinoa::key{l,r,u,d} gate on var[1024] == 1/2/3/4 respectively --
            // that is the first instruction of each, decoded below -- so the
            // codes are the directions.
            check(seen[1] == 1 && bitFor[1] == SR_MASK_LEFT,
                  "**director1: the bit that yields direction code 1 (rinoa::keyl) is SR_MASK_LEFT**");
            check(seen[2] == 1 && bitFor[2] == SR_MASK_RIGHT,
                  "**director1: code 2 (rinoa::keyr) is SR_MASK_RIGHT**");
            check(seen[3] == 1 && bitFor[3] == SR_MASK_UP,
                  "**director1: code 3 (rinoa::keyu) is SR_MASK_UP**");
            check(seen[4] == 1 && bitFor[4] == SR_MASK_DOWN,
                  "**director1: code 4 (rinoa::keyd) is SR_MASK_DOWN**");
            check(seen[5] == 2 && seen[6] == 2 && seen[7] == 2 && seen[8] == 2,
                  "and codes 5-8 are the four diagonals, each under two bits");
            // All four masks distinct, so a copy-paste cannot alias two of them.
            check(SR_MASK_LEFT != SR_MASK_RIGHT && SR_MASK_UP != SR_MASK_DOWN &&
                  SR_MASK_LEFT != SR_MASK_UP && SR_MASK_LEFT != SR_MASK_DOWN &&
                  SR_MASK_RIGHT != SR_MASK_UP && SR_MASK_RIGHT != SR_MASK_DOWN,
                  "the four D-pad masks are four different bits");
            check(SR_MASK_BOOST == 16,
                  "and the boost bit is 16, the mask each handler tests for the long step");
        }

        check(SrMaskForX( 4000) == SR_MASK_RIGHT, "**Rinoa right of centre -> press RIGHT**");
        check(SrMaskForX(-4000) == SR_MASK_LEFT,  "**Rinoa left of centre -> press LEFT**");
        check(SrMaskForY( 4000) == SR_MASK_UP,    "**Rinoa above centre -> press UP**");
        check(SrMaskForY(-4000) == SR_MASK_DOWN,  "**Rinoa below centre -> press DOWN**");
        check(SrMaskForX(0) == 0 && SrMaskForY(0) == 0, "and centred asks for nothing");
        check(SrMaskForX(SR_WIN_BOX - 1) == 0, "the axis goes quiet exactly at the win box");
        check(SrMaskForX(SR_WIN_BOX) != 0,     "and speaks again one unit outside it");

        check(SrCentred(0,0) && SrCentred(179,-179), "inside the box counts as centred");
        check(!SrCentred(180,0) && !SrCentred(0,-180), "the boundary itself does not");
        check(!SrCentred(SR_CLAMP_X, SR_CLAMP_Y), "and neither does the far corner");
    }

    // =====================================================================
    // #112 PROPAGATOR -- the pairing, which is what actually solves it
    // =====================================================================
    {
        // ---- read own / partner / pending mask / mercy out of the eight ----
        struct Derived { uint8_t own, partner, pendMask; int mercy; bool resurrects; };
        Derived D[8];
        check(ALIEN_FIX_N == 8, "eight alien scripts were extracted");
        for (int k = 0; k < ALIEN_FIX_N; k++) {
            Derived d; d.own = 0; d.partner = 0; d.pendMask = 0; d.mercy = -1;
            d.resurrects = false;
            int o, p; bool h;

            // GATE: PSHM_B 446 ; PSHN_L own ; AND
            for (int i = 0; i + 2 < ALIEN_FIX[k].gateN; i++) {
                dec(ALIEN_FIX[k].gate[i], &o, &p, &h);
                if (o != OP_PSHM_B || p != PG_VAR_DEAD) continue;
                int o2, p2; bool h2; dec(ALIEN_FIX[k].gate[i+1], &o2, &p2, &h2);
                int o3, p3; bool h3; dec(ALIEN_FIX[k].gate[i+2], &o3, &p3, &h3);
                if (o2 == OP_PSHN_L && o3 == OP_OPER && p3 == OP_AND) {
                    d.own = (uint8_t)p2; break;
                }
            }
            // RESOLVE: the first PSHM_B 445 ; PSHN_L m ; AND names the mask;
            //          the first PSHM_B 447 ; PSHN_L b ; AND names the partner;
            //          PSHM_B 446 ; PSHM_B 447 ; NOT ; AND is the resurrection;
            //          PSHM_B 437 ; PSHN_L t ; GT is the mercy threshold.
            for (int i = 0; i + 2 < ALIEN_FIX[k].resN; i++) {
                dec(ALIEN_FIX[k].res[i], &o, &p, &h);
                int o2, p2; bool h2; dec(ALIEN_FIX[k].res[i+1], &o2, &p2, &h2);
                int o3, p3; bool h3; dec(ALIEN_FIX[k].res[i+2], &o3, &p3, &h3);
                if (o == OP_PSHM_B && o2 == OP_PSHN_L && o3 == OP_OPER) {
                    if (p == PG_VAR_PENDFLAG && p3 == OP_AND && !d.pendMask)
                        d.pendMask = (uint8_t)p2;
                    if (p == PG_VAR_PENDBIT && p3 == OP_AND && !d.partner)
                        d.partner = (uint8_t)p2;
                    if (p == 437 && p3 == OP_GT) d.mercy = p2;
                }
                if (i + 3 < ALIEN_FIX[k].resN && o == OP_PSHM_B && p == PG_VAR_DEAD &&
                    o2 == OP_PSHM_B && p2 == PG_VAR_PENDBIT && o3 == OP_OPER && p3 == OP_NOT) {
                    int o4, p4; bool h4; dec(ALIEN_FIX[k].res[i+3], &o4, &p4, &h4);
                    if (o4 == OP_OPER && p4 == OP_AND) d.resurrects = true;
                }
            }
            D[k] = d;

            char m[200];
            snprintf(m, sizeof(m), "%s: script names own=0x%02X partner=0x%02X",
                     ALIEN_FIX[k].field, d.own, d.partner);
            check(d.own != 0 && d.partner != 0, m);

            snprintf(m, sizeof(m), "%s: the pending flag is var[%d] bit 0x%02X",
                     ALIEN_FIX[k].field, PG_VAR_PENDFLAG, d.pendMask);
            check(d.pendMask == PG_PENDING_MASK, m);

            snprintf(m, sizeof(m), "%s: an unmatched kill RESURRECTS the pending one",
                     ALIEN_FIX[k].field);
            check(d.resurrects, m);

            snprintf(m, sizeof(m), "%s: the game's own mercy is var[437] > 24, not %d",
                     ALIEN_FIX[k].field, d.mercy);
            check(d.mercy == 24, m);

            // ...and THAT is what the model is checked against.
            const Propagator* mp = PgForField(ALIEN_FIX[k].field);
            snprintf(m, sizeof(m), "**%s: the model's bit 0x%02X / partner 0x%02X are the "
                                   "script's own 0x%02X / 0x%02X**",
                     ALIEN_FIX[k].field, mp ? mp->bit : 0, mp ? mp->partnerBit : 0,
                     d.own, d.partner);
            check(mp && mp->bit == d.own && mp->partnerBit == d.partner, m);
        }

        // The pairing CLOSES: every partner bit belongs to a script whose own
        // partner bit points back. Eight scripts, one involution, no orphans.
        for (int k = 0; k < 8; k++) {
            int mate = -1;
            for (int q = 0; q < 8; q++) if (D[q].own == D[k].partner) mate = q;
            char m[160];
            snprintf(m, sizeof(m), "%s's partner 0x%02X is a real script, and it points back",
                     ALIEN_FIX[k].field, D[k].partner);
            check(mate >= 0 && D[mate].partner == D[k].own, m);
            check(mate != k, "and nothing is its own partner");
        }
        // The eight own-bits cover 0xFF exactly, so var[446]==255 really is
        // "all eight down" and not "some subset plus a spare bit".
        {
            uint8_t cover = 0; int distinct = 0;
            for (int k = 0; k < 8; k++) { if (!(cover & D[k].own)) distinct++; cover |= D[k].own; }
            check(cover == PG_ALL_DEAD && distinct == 8,
                  "**the eight bits are distinct and cover 0xFF, which is the puzzle's exit**");
        }
    }

    {
        check(PgTableConsistent(),
              "**every Propagator's partner points back at it, agrees on the "
              "colour, and the eight bits cover 0xFF**");
        check(PG_COUNT == 8, "eight of them");

        // The bit pairs, exactly as the eight alien scripts test them.
        struct { const char* f; uint8_t own, partner; const char* colour; } B[] = {
            { "rgair1",   0x01, 0x80, "yellow" }, { "rgguest2", 0x80, 0x01, "yellow" },
            { "rgroad1",  0x02, 0x20, "green"  }, { "rghang2",  0x20, 0x02, "green"  },
            { "rgroad2",  0x04, 0x08, "red"    }, { "rgroad3",  0x08, 0x04, "red"    },
            { "rghang1",  0x10, 0x40, "purple" }, { "rgexit1",  0x40, 0x10, "purple" },
        };
        for (unsigned k = 0; k < sizeof(B)/sizeof(B[0]); k++) {
            const Propagator* p = PgForField(B[k].f);
            char m[160];
            snprintf(m, sizeof(m), "%s is bit 0x%02X, pairs with 0x%02X, %s",
                     B[k].f, B[k].own, B[k].partner, B[k].colour);
            check(p && p->bit == B[k].own && p->partnerBit == B[k].partner &&
                  strcmp(p->colour, B[k].colour) == 0, m);
        }
        // Four colours, two each -- never three of one.
        const char* cols[4] = { "yellow", "green", "red", "purple" };
        for (int c = 0; c < 4; c++) {
            int cnt = 0;
            for (int i = 0; i < PG_COUNT; i++) if (!strcmp(PG_LIST[i].colour, cols[c])) cnt++;
            char m[96]; snprintf(m, sizeof(m), "exactly two %s Propagators", cols[c]);
            check(cnt == 2, m);
        }
        // rgroad3's fightable one is alien02 -- alien01 there is the decoy.
        const Propagator* r3 = PgForField("rgroad3");
        check(r3 && strcmp(r3->entity, "alien02") == 0,
              "**rgroad3's Propagator is alien02** -- its alien01 is cutscene-only "
              "and announcing it would send the player at a phantom");
        check(strcmp(PG_DECOY_FIELD, "rgroad3") == 0 &&
              strcmp(PG_DECOY_ENTITY, "alien01") == 0, "and the decoy is named so it can be hidden");

        char buf[256];
        PgStatusLine(0xFF, 0, false, buf, sizeof(buf));
        checkStr(buf, "All eight are down. The lift is open.", "the finished state");
        PgStatusLine(0x00, 0, false, buf, sizeof(buf));
        checkStr(buf, "8 left. No kill is pending, so any one may be killed next.", "the opening state");
        // One yellow down and unmatched: the mod must name the other yellow AND
        // where it is, because that is the move that stops the revive.
        PgStatusLine(0x01, 0x01, true, buf, sizeof(buf));
        checkStr(buf, "7 left. A yellow one is down and unmatched -- kill the other yellow "
                      "one, in the passenger cabin, next, or the first comes back.",
                 "**an unmatched kill names its match and its room**");

        // Standing in front of the match.
        const Propagator* g2 = PgForField("rgguest2");
        PgHereLine(g2, 0x01, 0x01, true, buf, sizeof(buf));
        checkStr(buf, "yellow Propagator. This is the match for the pending kill -- "
                      "killing it now finishes the pair.", "the go-ahead");
        // Standing in front of the WRONG one while a kill is pending.
        const Propagator* h1 = PgForField("rghang1");
        PgHereLine(h1, 0x01, 0x01, true, buf, sizeof(buf));
        checkStr(buf, "purple Propagator. Do NOT kill it yet: a yellow one is unmatched and "
                      "would come back. Its pair is in the exit passage.",
                 "**and the warning that is the whole puzzle**");
        PgHereLine(h1, 0x00, 0x00, false, buf, sizeof(buf));
        checkStr(buf, "purple Propagator. Its pair is in the exit passage.", "the quiet case");
        PgHereLine(h1, 0x10, 0x00, false, buf, sizeof(buf));
        checkStr(buf, "The purple Propagator here is already down.", "and a dead one says so");
        check(PgIsRagnarokField("rghang1") && !PgIsRagnarokField("eccway11"),
              "the Ragnarok test is by prefix");
        check((PG_ADDR_DEAD - 0x01CFE9B8u) == PG_VAR_DEAD &&
              (PG_ADDR_PENDBIT - 0x01CFE9B8u) == PG_VAR_PENDBIT &&
              (PG_ADDR_PENDFLAG - 0x01CFE9B8u) == PG_VAR_PENDFLAG,
              "the three variables resolve where the field variable block puts them");
    }

    std::printf(bad ? "disc3_models_compile: FAILED (%d bad)\n"
                    : "disc3_models_compile: OK (%d bad)\n", bad);
    return bad ? 1 : 0;
}
