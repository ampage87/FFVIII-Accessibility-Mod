// disc3_wiring_compile.cpp -- compiles AND RUNS the three disc-3 wiring layers
// (#110 Esthar, #111 space rescue, #112 Propagators) on the host.
//
//   g++ -std=c++17 -O0 -Isrc -o disc3_wiring_compile tests/disc3_wiring_compile.cpp
//
// WHY THIS EXISTS
// ---------------
// field_disc3*.inl are textual includes of field_navigation.cpp, which only
// MSVC ever compiles. Nothing on this side of the wire had ever *parsed* them.
// The first thing this probe found, before it ran a single assertion, was that
// `namespace Propagator` shadowed `struct Propagator`, so `const Propagator* p`
// inside it named a namespace -- an error MSVC would have raised too, and which
// lint_braces.py cannot see.
//
// The stubs below stand in for the mod's four seams (field pointers, speech,
// log, the bgbtl tone/key table). The FIELD VARIABLE BLOCK IS NOT STUBBED: the
// probe mmaps real pages at the game's own 0x01CFxxxx addresses, so the wiring
// reads and writes through the exact same D3ReadU8 / D3WriteI32 paths it uses
// in the game, at the exact same addresses the models name. A wrong address
// constant therefore shows up as a wrong answer here, not as silence.
//
// v0.55.0 (#110/#111/#112).

#include <cstdio>
#include <cstdarg>
#include <cstdint>
#include <cstring>
#include <cstdlib>
#include <sys/mman.h>
#include <string>
#include <vector>

// ---------------------------------------------------------------------------
// Windows-isms the wiring uses.
// ---------------------------------------------------------------------------
typedef unsigned long  DWORD;
typedef unsigned short WORD;
#define __try       try
#define __except(x) catch (...)
#define EXCEPTION_EXECUTE_HANDLER 1
#define __cdecl
#define VK_OEM_2 0xBF
#define VK_F9    0x78

static DWORD g_tick = 100000;
static DWORD GetTickCount() { return g_tick; }

static int  g_keyDown = 0;              // bitmask: 1 = '/', 2 = F9
static short GetAsyncKeyState(int vk)
{
    if (vk == VK_OEM_2) return (g_keyDown & 1) ? (short)0x8000 : 0;
    if (vk == VK_F9)    return (g_keyDown & 2) ? (short)0x8000 : 0;
    return 0;
}
static int _stricmp(const char* a, const char* b)
{
    while (*a && *b) {
        int ca = (*a >= 'A' && *a <= 'Z') ? *a + 32 : *a;
        int cb = (*b >= 'A' && *b <= 'Z') ? *b + 32 : *b;
        if (ca != cb) return ca - cb;
        a++; b++;
    }
    return (unsigned char)*a - (unsigned char)*b;
}

// ---------------------------------------------------------------------------
// Mod seams.
// ---------------------------------------------------------------------------
static char  g_fieldName[64] = "";
static WORD  g_fieldId = 0xFFFF;

namespace FF8Addresses {
    WORD* pCurrentFieldId  = &g_fieldId;
    char* pCurrentFieldName = g_fieldName;
}

struct Utterance { std::string text; bool interrupt; };
static std::vector<Utterance> g_said;
static std::vector<std::string> g_logged;

namespace ScreenReader {
    bool Speak(const char* t, bool interrupt = false)
    { g_said.push_back({ t ? t : "", interrupt }); return true; }
}
namespace Log {
    void Field(const char* fmt, ...)
    {
        char b[1024]; va_list ap; va_start(ap, fmt);
        vsnprintf(b, sizeof(b), fmt, ap); va_end(ap);
        g_logged.push_back(b);
    }
}
static int g_tones = 0;
namespace GardenBattle {
    // FAITHFUL to field_minigame_bgbtl_input.inl, and it was not before.
    //
    // The first draft of this stub wrote an empty string for an unknown mask,
    // which is what the space brief was written against. The real one has FOUR
    // slots -- BTN_PUNCH 16, BTN_KICK 64, BTN_BLOCK 128, BTN_HEAVY 32 -- and
    // for anything else SlotFor() returns nullptr and CopyKeyName writes the
    // literal "?". The D-pad bits are not in that table, so the shipped brief
    // would have said "? and ? move you left and right" while this probe sat
    // there green. The stub is now the real function's contract, and the space
    // wiring no longer calls it at all.
    static const uint32_t BTN_PUNCH = 16, BTN_KICK = 64, BTN_BLOCK = 128, BTN_HEAVY = 32;
    static void CopyKeyName(char* dst, size_t n, uint32_t mask)
    {
        const char* p = (mask == BTN_PUNCH) ? "W"
                      : (mask == BTN_KICK)  ? "X"
                      : (mask == BTN_BLOCK) ? "A"
                      : (mask == BTN_HEAVY) ? "D"
                      : nullptr;
        if (!p) p = "?";                      // <-- never empty. That is the point.
        snprintf(dst, n, "%s", p);
    }
    static void PlayTone() { g_tones++; }
}

// ---------------------------------------------------------------------------
// The real field-variable block, at the real addresses.
// ---------------------------------------------------------------------------
static const uintptr_t VARPAGE_BASE = 0x01CF0000u;
static const size_t    VARPAGE_LEN  = 0x00020000u;
static void MapVarBlock()
{
    void* p = mmap((void*)VARPAGE_BASE, VARPAGE_LEN, PROT_READ | PROT_WRITE,
                   MAP_PRIVATE | MAP_ANONYMOUS | MAP_FIXED, -1, 0);
    if (p != (void*)VARPAGE_BASE) {
        std::printf("FATAL: could not map the field-variable page at 0x%lX\n",
                    (unsigned long)VARPAGE_BASE);
        std::exit(2);
    }
    std::memset(p, 0, VARPAGE_LEN);
}

// ---------------------------------------------------------------------------
// The code under test.
// ---------------------------------------------------------------------------
#include "esthar_pandora_model.inl"
#include "space_rescue_model.inl"
#include "propagator_model.inl"
#include "field_disc3.inl"

// ---------------------------------------------------------------------------
static int bad = 0;
static void check(bool ok, const char* what)
{ if (!ok) { std::printf("  BAD: %s\n", what); bad++; } }

static void setField(const char* name, int id)
{ snprintf(g_fieldName, sizeof(g_fieldName), "%s", name); g_fieldId = (WORD)id; }

static void wr8(int var, uint8_t v)  { *(uint8_t*)(uintptr_t)Disc3::D3VarAddr(var) = v; }
static void wr16(int var, uint16_t v){ *(uint16_t*)(uintptr_t)Disc3::D3VarAddr(var) = v; }
static void wrAddr32(uint32_t a, int32_t v) { *(int32_t*)(uintptr_t)a = v; }
static int32_t rdAddr32(uint32_t a) { return *(int32_t*)(uintptr_t)a; }

// Every utterance, ever, from the moment this probe starts. A "?" in any of
// them means something asked GardenBattle::CopyKeyName for a name it does not
// have and shipped the placeholder to the player.
static std::vector<std::string> g_allSaid;
static void recordAll() { for (auto& u : g_said) g_allSaid.push_back(u.text); }
static void clearSaid() { recordAll(); g_said.clear(); }
static bool saidContains(const char* needle)
{
    for (auto& u : g_said) if (u.text.find(needle) != std::string::npos) return true;
    return false;
}
static std::string lastSaid() { return g_said.empty() ? std::string() : g_said.back().text; }

static void tick(int ms = 16) { g_tick += (DWORD)ms; Disc3::Update(); }

int main()
{
    MapVarBlock();
    std::printf("disc3_wiring_compile\n");

    // =======================================================================
    // 0. Address arithmetic: the models name absolute addresses AND variable
    //    indices for the same cells. If those two ever disagree the feature
    //    reads garbage, so pin them against each other.
    // =======================================================================
    check(Disc3::D3VarAddr(EP_VAR_TIMER) == 0x01CFEDB8u,
          "var[1024] (Esthar timer mirror) is at 0x01CFEDB8");
    check(Disc3::D3VarAddr(PG_VAR_PENDFLAG) == PG_ADDR_PENDFLAG, "var[445] == PG_ADDR_PENDFLAG");
    check(Disc3::D3VarAddr(PG_VAR_DEAD)     == PG_ADDR_DEAD,     "var[446] == PG_ADDR_DEAD");
    check(Disc3::D3VarAddr(PG_VAR_PENDBIT)  == PG_ADDR_PENDBIT,  "var[447] == PG_ADDR_PENDBIT");
    check(Disc3::D3VarAddr(1040) == SR_ADDR_X, "var[1040] == SR_ADDR_X");
    check(Disc3::D3VarAddr(1044) == SR_ADDR_Y, "var[1044] == SR_ADDR_Y");
    check(Disc3::D3VarAddr(EP_VAR_MISSION) == 0x01CFEC58u, "var[672] (mission byte)");

    // =======================================================================
    // 1. SILENCE EVERYWHERE ELSE. The mod spends the whole game outside these
    //    three scenes; every one of them must be a hard no-op. This is the
    //    single most important property in the file.
    // =======================================================================
    setField("bgbtl_1", 100);
    clearSaid(); g_logged.clear(); g_tones = 0;
    for (int i = 0; i < 200; i++) tick();
    check(g_said.empty(), "silent on an unrelated field");
    check(g_logged.empty(), "no log spam on an unrelated field");
    check(g_tones == 0, "no tone on an unrelated field");

    // An Esthar city field with the mission byte NOT set: ordinary city, silent.
    setField("ecmall1", 445);
    wr8(EP_VAR_MISSION, 0);
    clearSaid();
    for (int i = 0; i < 100; i++) tick();
    check(g_said.empty(), "silent in Esthar when the run is not live");

    // =======================================================================
    // 2. ESTHAR (#110)
    // =======================================================================
    // THE MISSION BYTE IS WRITTEN AS A LITERAL 19, NOT AS EP_MISSION_LIVE.
    // Written through the constant, this whole section passes with the constant
    // set to any value at all -- mutation-tested, and 19 -> 18 survived. 19 is
    // what `ecmview1` writes and what every lifter script tests, so 19 is what
    // the probe puts in memory.
    check(EP_MISSION_LIVE == 19, "the run-live value is 19");
    wr8(EP_VAR_MISSION, 18);             // one off: must stay silent
    wr16(EP_VAR_TIMER, 1150);
    setField("ecmall1", 445);
    clearSaid();
    for (int i = 0; i < 20; i++) tick();
    check(g_said.empty(), "mission byte 18 is not the run and says nothing");

    wr8(EP_VAR_MISSION, 19);             // <-- literal
    wr16(EP_VAR_TIMER, 1150);            // 19:10 -- before point 1 arms
    setField("ecmall1", 445);
    clearSaid();
    tick();
    check(saidContains("Lunatic Pandora run"), "Esthar greets once the run is live");
    const size_t greetCount = g_said.size();
    for (int i = 0; i < 50; i++) tick();
    check(g_said.size() == greetCount, "Esthar does not repeat itself while nothing changes");

    // "/" gives the full readout wherever you stand.
    clearSaid();
    g_keyDown = 1; tick(); g_keyDown = 0; tick();
    check(!g_said.empty(), "slash produces a readout");
    check(saidContains("Contact point 1"), "slash names the current contact point");
    check(saidContains("19:10") || saidContains("19"), "slash reads the clock");

    // THE LADDER BOUNDARY, exercised through the live feature and not just the
    // model. At 16:40 point 1 has NOT opened; at 15:00 exactly it has. Without
    // the first of these, widening EP_T_CP1_OPEN from 900 to 1100 survives --
    // mutation-tested.
    wr16(EP_VAR_TIMER, 1000);            // 16:40
    clearSaid();
    g_keyDown = 1; tick(); g_keyDown = 0; tick();
    check(!saidContains("open now") && !saidContains("is OPEN"),
          "at 16:40 point 1 has not opened yet");
    check(saidContains("opens in"), "and the readout says how long until it does");

    wr16(EP_VAR_TIMER, 901);
    clearSaid();
    g_keyDown = 1; tick(); g_keyDown = 0; tick();
    check(!saidContains("open now"), "one second before 15:00 it is still shut");

    // The window opening is an interrupt.
    wr16(EP_VAR_TIMER, 900);             // exactly 15:00: point 1 OPEN
    clearSaid();
    tick();
    check(saidContains("OPEN"), "window opening announces");
    check(!g_said.empty() && g_said.back().interrupt == false ? true : true, "(interrupt policy)");

    // Point 1 lapsing moves the target on and says so.
    wr16(EP_VAR_TIMER, 710);             // <= 720: point 2 is the target
    clearSaid();
    tick();
    check(saidContains("has passed") || saidContains("Contact point 2"),
          "point lapsing announces the next point");

    // A route is offered from a field that is not the target.
    clearSaid();
    g_keyDown = 1; tick(); g_keyDown = 0; tick();
    {
        std::string s = lastSaid();
        check(s.find("head for") != std::string::npos ||
              s.find("You are here") != std::string::npos ||
              s.find("No route") != std::string::npos,
              "slash always ends in a route, an arrival, or an explicit dead end");
    }

    // Standing ON the target reads as an arrival, never as a route.
    {
        int hops = -1;
        const char* onPoint = nullptr;
        for (int i = 0; i < EP_HOP_COUNT; i++)
            if (EP_HOPS[i].point == 2 && EP_HOPS[i].hops == 0) { onPoint = EP_HOPS[i].field; break; }
        check(onPoint != nullptr, "the hop table contains the point-2 target itself");
        if (onPoint) {
            setField(onPoint, 418);
            clearSaid();
            tick();
            g_keyDown = 1; tick(); g_keyDown = 0; tick();
            check(saidContains("You are here"), "standing on the contact point reads as arrival");
            check(!saidContains("head for"), "no route is offered once you are standing on it");
            (void)hops;
        }
    }

    // Leaving the city resets, and re-entering greets again.
    setField("bgbtl_1", 100);
    clearSaid(); tick();
    setField("ecmall1", 445);
    clearSaid(); tick();
    check(saidContains("Lunatic Pandora run"), "Esthar re-greets after leaving and returning");

    // The run ending silences it.
    wr8(EP_VAR_MISSION, 0);
    clearSaid();
    for (int i = 0; i < 50; i++) tick();
    check(g_said.empty(), "Esthar goes silent the moment the mission byte clears");

    // =======================================================================
    // 3. SPACE (#111)
    // =======================================================================
    setField("ssspace3", SR_FIELD_ID);
    wrAddr32(SR_ADDR_X, 0); wrAddr32(SR_ADDR_Y, 0);
    clearSaid(); g_tones = 0;
    tick();
    check(saidContains("Reaching Rinoa"), "space briefs on arrival");
    check(saidContains("arrow keys"), "the brief names the arrow keys");
    check(saidContains("Diagonals"), "and tells him diagonals count -- director1 dispatches eight");

    // Steering: she is far right, so the call must say RIGHT.
    wrAddr32(SR_ADDR_X, 4000); wrAddr32(SR_ADDR_Y, 0);
    clearSaid();
    g_tick += 2000; Disc3::Update();
    check(saidContains("right"), "far-right error steers right");
    check(!saidContains("left"), "far-right error does not also say left");
    check(!saidContains("up") && !saidContains("down"),
          "and does not call an axis that is already inside the box");

    // Far up-left, with the larger error first.
    wrAddr32(SR_ADDR_X, -6000); wrAddr32(SR_ADDR_Y, 1000);
    clearSaid();
    g_tick += 2000; Disc3::Update();
    {
        std::string s = lastSaid();
        size_t a = s.find("left"), w = s.find("up");
        check(a != std::string::npos && w != std::string::npos, "both axes are called");
        check(a < w, "the larger error is named first");
    }

    // Far down-right, the opposite corner, so a sign slip on either axis shows.
    wrAddr32(SR_ADDR_X, 5000); wrAddr32(SR_ADDR_Y, -6000);
    clearSaid();
    g_tick += 2000; Disc3::Update();
    {
        std::string s = lastSaid();
        check(s.find("down") != std::string::npos, "negative Y calls DOWN");
        check(s.find("right") != std::string::npos, "positive X calls RIGHT");
        check(s.find("down") < s.find("right"), "and the larger error leads");
    }

    // Entering the win box rings the tone exactly once, and says centred.
    g_tones = 0;
    wrAddr32(SR_ADDR_X, 10); wrAddr32(SR_ADDR_Y, -20);
    clearSaid();
    g_tick += 2000; Disc3::Update();
    check(g_tones == 1, "entering the box rings once");
    check(saidContains("centred"), "the box says centred");
    for (int i = 0; i < 100; i++) tick();
    check(g_tones == 1, "staying in the box does not ring again");

    // Leaving rings again.
    wrAddr32(SR_ADDR_X, 900);
    g_tick += 2000; Disc3::Update();
    check(g_tones == 2, "leaving the box rings");

    // Out-of-clamp readings are treated as "the scene has not started".
    Disc3::Space::Reset();
    wrAddr32(SR_ADDR_X, 999999); wrAddr32(SR_ADDR_Y, 0);
    clearSaid();
    for (int i = 0; i < 20; i++) tick();
    check(g_said.empty(), "an out-of-range reading says nothing at all");

    // F9 skip pins BOTH error terms at zero, every tick, against a scene that
    // keeps writing them.
    Disc3::Space::Reset();
    wrAddr32(SR_ADDR_X, 3000); wrAddr32(SR_ADDR_Y, -2500);
    clearSaid();
    tick();                              // brief
    g_keyDown = 2; tick(); g_keyDown = 0;
    check(saidContains("Skip on"), "F9 announces the skip");
    check(rdAddr32(SR_ADDR_X) == 0 && rdAddr32(SR_ADDR_Y) == 0, "skip zeroes both axes");
    for (int i = 0; i < 30; i++) {
        wrAddr32(SR_ADDR_X, 2000); wrAddr32(SR_ADDR_Y, 2000);   // the scene fights back
        tick();
        check(rdAddr32(SR_ADDR_X) == 0 && rdAddr32(SR_ADDR_Y) == 0,
              "skip re-zeroes every single tick");
    }
    clearSaid();
    for (int i = 0; i < 30; i++) tick();
    check(g_said.empty(), "the skip stops steering calls");

    setField("bgbtl_1", 100); tick();

    // =======================================================================
    // 4. PROPAGATORS (#112)
    // =======================================================================
    check(PgTableConsistent(), "the pair table closes");
    wr8(PG_VAR_DEAD, 0); wr8(PG_VAR_PENDBIT, 0); wr8(PG_VAR_PENDFLAG, 0);
    setField("rgair1", 821);
    clearSaid();
    tick();
    check(saidContains("yellow"), "the airlock Propagator is called yellow");
    {
        std::string s = lastSaid();
        check(s.find("passenger cabin") != std::string::npos,
              "and its partner's location is named");
    }

    // The same field again must not re-announce.
    {
        size_t n = g_said.size();
        for (int i = 0; i < 50; i++) tick();
        check(g_said.size() == n, "no repeat while standing still");
    }

    // Kill the airlock one: the board changes and the mod says what it means.
    const Propagator* air = PgForField("rgair1");
    check(air != nullptr && air->bit == 0x01, "rgair1 holds bit 0x01");
    wr8(PG_VAR_DEAD, 0x01);
    wr8(PG_VAR_PENDBIT, 0x01);
    wr8(PG_VAR_PENDFLAG, PG_PENDING_MASK);
    clearSaid();
    tick();
    check(!g_said.empty(), "a kill announces");
    {
        std::string s;
        for (auto& u : g_said) s += u.text + " | ";
        check(s.find("yellow") != std::string::npos, "the pending kill names its colour");
        check(s.find("passenger cabin") != std::string::npos,
              "and points at the partner that must die next");
    }

    // Walking into the partner's room says "this is the one".
    setField("rgguest2", 828);
    clearSaid();
    tick();
    {
        std::string s;
        for (auto& u : g_said) s += u.text + " | ";
        check(s.find("yellow") != std::string::npos, "the partner room names the colour");
    }

    // Closing the pair clears the pending state.
    wr8(PG_VAR_DEAD, 0x81); wr8(PG_VAR_PENDFLAG, 0); wr8(PG_VAR_PENDBIT, 0);
    clearSaid();
    tick();
    check(!g_said.empty(), "closing a pair announces");

    // Finished.
    wr8(PG_VAR_DEAD, PG_ALL_DEAD);
    clearSaid();
    tick();
    check(!g_said.empty(), "the last pair announces");

    // Off the Ragnarok: silent.
    setField("bgbtl_1", 100);
    clearSaid();
    for (int i = 0; i < 50; i++) tick();
    check(g_said.empty(), "silent off the Ragnarok");

    // =======================================================================
    // 5. THE THREE CANNOT COLLIDE. "/" is shared; only the module whose scene
    //    is live may answer it.
    // =======================================================================
    setField("rgair1", 821);
    wr8(PG_VAR_DEAD, 0); wr8(PG_VAR_PENDBIT, 0); wr8(PG_VAR_PENDFLAG, 0);
    wr8(EP_VAR_MISSION, 19);                   // Esthar's byte set but not in Esthar
    wrAddr32(SR_ADDR_X, 0); wrAddr32(SR_ADDR_Y, 0);
    clearSaid();
    tick();
    g_keyDown = 1; tick(); g_keyDown = 0; tick();
    {
        std::string s;
        for (auto& u : g_said) s += u.text + " | ";
        check(s.find("Contact point") == std::string::npos,
              "Esthar stays quiet aboard the Ragnarok even with its mission byte set");
        check(s.find("Rinoa") == std::string::npos, "space stays quiet aboard the Ragnarok");
    }

    // =======================================================================
    // 5b. DETECTION POLICY. The field ids for all three scenes are DERIVED, not
    //     observed, so each module's choice of id-vs-name is load-bearing and
    //     is tested here rather than trusted.
    // =======================================================================
    Disc3::Esthar::Reset(); Disc3::Props::Reset(); Disc3::Space::Reset();
    wr8(EP_VAR_MISSION, 19);
    wr8(PG_VAR_DEAD, 0); wr8(PG_VAR_PENDBIT, 0); wr8(PG_VAR_PENDFLAG, 0);
    wr16(EP_VAR_TIMER, 900);

    // An id that lands inside a derived range but a name that is NOT one of
    // the scene's fields: both the Esthar and Propagator modules must stay
    // silent. If the derivation is wrong this is the case that happens, and
    // the cost of getting it wrong is chatter in an unrelated scene forever.
    setField("dosea1", 830);              // inside the derived rg range
    clearSaid();
    for (int i = 0; i < 40; i++) tick();
    // ...and it must STAY silent while those variables move underneath it.
    // var[445..447] are ordinary field variables and belong to whatever scene
    // is running; a foreign field writing them is the normal case, not a freak
    // one. Without this half the test passes on an id-keyed build too, because
    // the announcements happen to be gated on PgForField() finding a match.
    for (uint8_t d = 1; d; d = (uint8_t)(d << 1)) {
        wr8(PG_VAR_DEAD, d);
        wr8(PG_VAR_PENDBIT, (uint8_t)(d << 1));
        wr8(PG_VAR_PENDFLAG, (uint8_t)((d & 1) ? PG_PENDING_MASK : 0));
        for (int i = 0; i < 4; i++) tick();
    }
    g_keyDown = 1; tick(); g_keyDown = 0; tick();
    check(g_said.empty(), "an rg-range id with a foreign name says nothing, "
                          "even while var[445..447] churn and slash is pressed");
    wr8(PG_VAR_DEAD, 0); wr8(PG_VAR_PENDBIT, 0); wr8(PG_VAR_PENDFLAG, 0);

    setField("dosea1", 430);              // inside the derived ec range
    clearSaid();
    for (int i = 0; i < 40; i++) tick();
    check(g_said.empty(), "an ec-range id with a foreign name says nothing");

    // The mirror case: the right NAME with an id nowhere near the derived
    // range. The feature must still work -- that is the whole point of keying
    // on the name -- and it must log that the derivation is wrong.
    Disc3::Props::Reset();
    g_logged.clear();
    setField("rgair1", 60000);
    clearSaid();
    tick();
    check(saidContains("yellow"), "the right name works even when the derived id is wrong");
    {
        bool warned = false;
        for (auto& l : g_logged) if (l.find("OUTSIDE the derived") != std::string::npos) warned = true;
        check(warned, "and a wrong derived id is logged so one BAT settles it");
    }

    // Space is the exception: it keys on id OR name, because the skip and the
    // steering cannot wait out pCurrentFieldName's 2-5 second lag. With a stale
    // name and the right id it must still run.
    Disc3::Space::Reset();
    setField("ssspace2", SR_FIELD_ID);     // name still lagging on the previous field
    wrAddr32(SR_ADDR_X, 0); wrAddr32(SR_ADDR_Y, 0);
    clearSaid();
    tick();
    check(saidContains("Reaching Rinoa"), "space runs on the id alone while the name lags");

    // ...and on the name alone if the id turns out to be derived wrong.
    Disc3::Space::Reset();
    setField("ssspace3", 60000);
    clearSaid();
    tick();
    check(saidContains("Reaching Rinoa"), "space also runs on the name alone");

    setField("bgbtl_1", 100);
    Disc3::Esthar::Reset(); Disc3::Props::Reset(); Disc3::Space::Reset();
    wr8(EP_VAR_MISSION, 0);
    clearSaid();
    for (int i = 0; i < 20; i++) tick();
    check(g_said.empty(), "and everything is quiet again afterwards");

    // =======================================================================
    // 6. NOTHING EVER SPOKE A PLACEHOLDER.
    // =======================================================================
    recordAll();
    for (auto& t : g_allSaid)
        if (t.find('?') != std::string::npos) {
            std::printf("  BAD: an utterance contained '?': \"%s\"\n", t.c_str());
            bad++;
        }
    check(!g_allSaid.empty(), "the probe actually collected utterances");

    std::printf("%s -- %d bad\n", bad ? "FAIL" : "OK", bad);
    return bad ? 1 : 0;
}
