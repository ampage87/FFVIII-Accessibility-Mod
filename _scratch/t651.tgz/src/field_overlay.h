// field_overlay.h -- the mod's own on-screen text, drawn independently of the
// field.
//
// WHY THIS EXISTS
// ---------------
// Aaron, after the v0.64.x field freeze put a real pause behind the space
// rescue's Game Controls screen: *"Now that is working is there anything we can
// do to get the Game Controls visible on the screen? Can we independently fire
// the dialog renderer or something like that while freezing the scene?"*
//
// The game's dialog renderer cannot be fired on its own. field_main's steady
// state (0x0047246E) is one instruction -- `call 0x004767B0` -- and that single
// function is the whole per-frame field: scripts, movement and window drawing
// together, with no "draw only" entry to call. Freezing the field therefore
// takes the box with it, which is what his F11 screenshot showed: a black frame
// with nothing on it but the mission timer HUD, which survives because it is
// drawn AFTER field_main in field_main_loop.
//
// But the mod already has a foot in the render path that the freeze does not
// touch. battle_tts_screenshot.inl hooks SwapBuffers and calls glReadPixels
// there -- which is how that screenshot got taken DURING the freeze, on the
// game's own render thread with a live OpenGL context. Anything the mod draws
// there appears regardless of what field_main is or is not doing.
//
// So the box is ours now. That is better than restoring the game's: it is not
// bound to the game's 320x224 window geometry or its 34-column wrap, and every
// Game Controls screen in the mod can use it, not just this one.
//
// HOW IT IS SPLIT
// ---------------
// Show() runs on the MOD thread and rasterises the text into an RGB buffer with
// GDI. Draw() runs on the RENDER thread inside the SwapBuffers hook and does
// nothing but blit that buffer. No allocation, no GDI and no logging happen on
// the render thread; the buffer is built complete and then published, and it is
// never freed while the overlay is shown.

#pragma once

namespace FieldOverlay {

    // Rasterise `text` (lines separated by '\n') and start drawing it every
    // frame. Replaces whatever was shown. Returns false if the text could not
    // be rasterised, in which case nothing is shown and nothing changes.
    bool Show(const char* text);

    // Stop drawing. Idempotent.
    void Hide();

    bool IsShown();

    // Called from the SwapBuffers hook, on the game's render thread, with the
    // GL context current. No-op unless something is shown.
    void Draw();

    // Frees the rasterised buffer. Called once at shutdown.
    void Shutdown();

    // --- pure, and therefore testable off-Windows ---------------------------
    struct Layout {
        int lines;      // how many lines the text has
        int cols;       // the widest line, in characters
        int w, h;       // the bitmap the rasteriser will produce, in pixels
        bool clamped;   // true if the text had to be cut to fit the cap
    };
    // Measures what Show() will produce. cellW/cellH are the fixed-pitch cell
    // size; pad is the margin on each side. Never returns a size above the cap.
    Layout Measure(const char* text, int cellW, int cellH, int pad,
                   int maxW, int maxH);

    // The zoom Draw() will use for a viewport of this height, and where it will
    // put the bitmap. Separated out for the same reason: it is arithmetic, and
    // arithmetic can be checked without a screen.
    int  ZoomFor(int viewportH, int bitmapH);
    void PlaceFor(int viewportW, int viewportH, int bitmapW, int bitmapH,
                  int zoom, int* outX, int* outY);
}
