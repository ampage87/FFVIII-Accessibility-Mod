// field_overlay.cpp -- see field_overlay.h for why this exists.

#include "field_overlay.h"
#include "mod_forward_decls.h"

#include <windows.h>
#include <gl/GL.h>
#include <cstdint>
#include <cstring>
#include <cstdio>
#include <cstdlib>

#ifndef GL_BGR_EXT
#define GL_BGR_EXT 0x80E0
#endif

// The arithmetic lives in its own file so the probe can compile the same
// definitions this build uses.
#include "field_overlay_pure.inl"

namespace FieldOverlay {

// ---------------------------------------------------------------------------
// The rasteriser. Mod thread only.
// ---------------------------------------------------------------------------

static const int FP_CELL_H = 22;
static const int FP_PAD    = 10;

static uint8_t* s_pixels   = nullptr;   // RGB, bottom-up, published complete
static int      s_w        = 0;
static int      s_h        = 0;
static volatile bool s_show = false;
static int      s_cellW    = 0;
static bool     s_drawLogged = false;

bool IsShown() { return s_show; }

void Hide()
{
    if (!s_show) return;
    s_show = false;
    Log::Field("FieldNavigation: [OVERLAY] hidden");
}

void Shutdown()
{
    s_show = false;
    if (s_pixels) { free(s_pixels); s_pixels = nullptr; }
    s_w = s_h = 0;
}

bool Show(const char* text)
{
    if (!text || !text[0]) return false;

    HDC screen = GetDC(nullptr);
    HDC dc = CreateCompatibleDC(screen);
    ReleaseDC(nullptr, screen);
    if (!dc) return false;

    // A fixed-pitch face, so Measure()'s cell arithmetic is the truth rather
    // than an estimate. Consolas ships with every Windows this game runs on;
    // Courier New is the fallback, and FIXED_PITCH|FF_MODERN makes the mapper
    // pick another monospace face rather than a proportional one if neither is
    // present.
    HFONT font = CreateFontA(FP_CELL_H, 0, 0, 0, FW_SEMIBOLD, FALSE, FALSE, FALSE,
                             DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,
                             ANTIALIASED_QUALITY, FIXED_PITCH | FF_MODERN, "Consolas");
    if (!font)
        font = CreateFontA(FP_CELL_H, 0, 0, 0, FW_SEMIBOLD, FALSE, FALSE, FALSE,
                           DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,
                           ANTIALIASED_QUALITY, FIXED_PITCH | FF_MODERN, "Courier New");
    if (!font) { DeleteDC(dc); return false; }
    HGDIOBJ oldFont = SelectObject(dc, font);

    TEXTMETRICA tm = {};
    GetTextMetricsA(dc, &tm);
    const int cellW = tm.tmAveCharWidth > 0 ? tm.tmAveCharWidth : (FP_CELL_H / 2);
    const int cellH = tm.tmHeight > 0 ? tm.tmHeight : FP_CELL_H;

    const Layout L = Measure(text, cellW, cellH, FP_PAD, FP_MAX_W, FP_MAX_H);
    if (L.w <= 0 || L.h <= 0) {
        SelectObject(dc, oldFont); DeleteObject(font); DeleteDC(dc); return false;
    }

    // A bottom-up 32-bit DIB, because that is the row order glDrawPixels wants
    // and converting it twice would be work for nothing.
    BITMAPINFO bi = {};
    bi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
    bi.bmiHeader.biWidth = L.w;
    bi.bmiHeader.biHeight = L.h;          // positive = bottom-up
    bi.bmiHeader.biPlanes = 1;
    bi.bmiHeader.biBitCount = 32;
    bi.bmiHeader.biCompression = BI_RGB;
    void* bits = nullptr;
    HBITMAP dib = CreateDIBSection(dc, &bi, DIB_RGB_COLORS, &bits, nullptr, 0);
    if (!dib || !bits) {
        if (dib) DeleteObject(dib);
        SelectObject(dc, oldFont); DeleteObject(font); DeleteDC(dc); return false;
    }
    HGDIOBJ oldBmp = SelectObject(dc, dib);

    // Background, then a one-pixel border, then the text. Dark box, light text:
    // the same contrast the game's own window uses, and the one a sighted person
    // reading over his shoulder will expect.
    RECT all = { 0, 0, L.w, L.h };
    HBRUSH bg = CreateSolidBrush(RGB(12, 16, 32));
    FillRect(dc, &all, bg);
    DeleteObject(bg);
    HBRUSH border = CreateSolidBrush(RGB(200, 210, 235));
    FrameRect(dc, &all, border);
    DeleteObject(border);

    SetBkMode(dc, TRANSPARENT);
    SetTextColor(dc, RGB(240, 244, 255));

    int y = FP_PAD;
    const char* p = text;
    for (int line = 0; line < L.lines; line++) {
        const char* e = strchr(p, '\n');
        int len = e ? (int)(e - p) : (int)strlen(p);
        if (len > L.cols) len = L.cols;
        TextOutA(dc, FP_PAD, y, p, len);
        y += cellH;
        if (!e) break;
        p = e + 1;
    }

    // FLUSH BEFORE READING THE BITS. GDI batches: the calls above are queued,
    // not necessarily executed, and reading a DIB section's memory directly
    // does not force them out. Aaron's 2026-08-23 22:05 screenshot is what that
    // looks like -- the border and the FIRST line of ten had landed, the other
    // nine had not, and the background was still whatever the allocation
    // happened to contain. GdiFlush is the one line that makes a DIB section
    // safe to read by pointer.
    GdiFlush();

    // Copy out as packed RGB. The DIB is BGRA; GL_RGB is the one pixel format
    // that needs no extension to be defined, so the swap happens here, once,
    // on this thread rather than every frame on the render thread.
    const size_t need = (size_t)L.w * (size_t)L.h * 3;
    uint8_t* buf = (uint8_t*)malloc(need);
    if (buf) {
        const uint8_t* src = (const uint8_t*)bits;
        for (int row = 0; row < L.h; row++) {
            const uint8_t* s = src + (size_t)row * (size_t)L.w * 4;
            uint8_t* d = buf + (size_t)row * (size_t)L.w * 3;
            for (int col2 = 0; col2 < L.w; col2++) {
                d[col2 * 3 + 0] = s[col2 * 4 + 2];   // R
                d[col2 * 3 + 1] = s[col2 * 4 + 1];   // G
                d[col2 * 3 + 2] = s[col2 * 4 + 0];   // B
            }
        }
    }

    SelectObject(dc, oldBmp);
    DeleteObject(dib);
    SelectObject(dc, oldFont);
    DeleteObject(font);
    DeleteDC(dc);

    if (!buf) return false;

    // PUBLISH. The show flag goes down first so the render thread cannot be
    // reading the old buffer as it is freed, then the new one goes up complete.
    s_show = false;
    uint8_t* old = s_pixels;
    s_pixels = buf;
    s_w = L.w; s_h = L.h; s_cellW = cellW;
    s_drawLogged = false;
    s_show = true;
    if (old) free(old);

    Log::Field("FieldNavigation: [OVERLAY] shown: %d lines x %d cols -> %dx%d px "
               "(cell %dx%d)%s", L.lines, L.cols, L.w, L.h, cellW, cellH,
               L.clamped ? "  *** CLAMPED -- text did not fit ***" : "");
    return true;
}

// ---------------------------------------------------------------------------
// The blit. Render thread only. No allocation, no GDI, no logging except once.
// ---------------------------------------------------------------------------
void Draw()
{
    if (!s_show) return;
    uint8_t* px = s_pixels;
    if (!px || s_w <= 0 || s_h <= 0) return;

    GLint vp[4] = { 0, 0, 0, 0 };
    glGetIntegerv(GL_VIEWPORT, vp);
    const int vw = vp[2], vh = vp[3];
    if (vw <= 0 || vh <= 0) return;

    const int zoom = ZoomFor(vh, s_h);
    int x = 0, y = 0;
    PlaceFor(vw, vh, s_w, s_h, zoom, &x, &y);

    glPushAttrib(GL_ALL_ATTRIB_BITS);
    glMatrixMode(GL_PROJECTION); glPushMatrix(); glLoadIdentity();
    glOrtho(0.0, (double)vw, 0.0, (double)vh, -1.0, 1.0);
    glMatrixMode(GL_MODELVIEW);  glPushMatrix(); glLoadIdentity();

    glDisable(GL_DEPTH_TEST);
    glDisable(GL_TEXTURE_2D);
    glDisable(GL_BLEND);
    glDisable(GL_LIGHTING);
    glDisable(GL_SCISSOR_TEST);
    glDisable(GL_STENCIL_TEST);
    glDisable(GL_CULL_FACE);
    glDisable(GL_ALPHA_TEST);
    glPixelStorei(GL_UNPACK_ALIGNMENT, 1);
    glPixelZoom((GLfloat)zoom, (GLfloat)zoom);
    glRasterPos2i(x, y);
    glDrawPixels(s_w, s_h, GL_RGB, GL_UNSIGNED_BYTE, px);

    const GLenum err = glGetError();

    glPixelZoom(1.0f, 1.0f);
    glMatrixMode(GL_PROJECTION); glPopMatrix();
    glMatrixMode(GL_MODELVIEW);  glPopMatrix();
    glPopAttrib();

    // ONCE per Show(), because this runs sixty times a second. If the renderer
    // turns out to be a core profile the fixed-function path is a no-op and
    // this line is the only thing that will say so.
    if (!s_drawLogged) {
        s_drawLogged = true;
        Log::Field("FieldNavigation: [OVERLAY] first blit: %dx%d at (%d,%d) zoom %d "
                   "in a %dx%d viewport, glGetError=0x%04X%s",
                   s_w, s_h, x, y, zoom, vw, vh, (unsigned)err,
                   err == GL_NO_ERROR ? "" : "  *** the GL call was rejected ***");
    }
}

} // namespace FieldOverlay
