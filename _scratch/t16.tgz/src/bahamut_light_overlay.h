// bahamut_light_overlay.h -- the Deep Sea Research Center blue-light puzzle
// (#bahamut-light).
//
// v0.98.0: New module, modeled on train_mode_ask_overlay. `sdcore1` (field 846)
// is the corridor that guards Bahamut: a blue light pulses, and the party may
// only walk while it is dark. Walking while it glows throws a random encounter.
//
// The whole puzzle is one byte -- `var[1024]` at 0x01CFEDB8 -- which the field's
// own `Director::default` raises and lowers, and which two watcher entities
// (`battlekun1`, `battlekun4`) read to decide whether a held direction becomes
// a battle. See bahamut_light_model.inl for the transcript that establishes it.
//
// On arrival the player is asked how they want to cross:
//
//   1. Guide  -- the mod calls "Go" the instant the light clears and "Stop" the
//                instant it arms (BL_MODE_GUIDE). The default.
//   2. Skip   -- the mod holds the game's OWN disarm pair, the one the corridor's
//                `Hojo` safe-pocket lines write (var[1028] = 1, var[1024] = 0),
//                so the light never arms and the player can walk straight to
//                Bahamut (BL_MODE_SKIP).
//
// The ASK is opened via DialogInject on slot 2 -- the same slot the chase and
// train prompts use, and none of the three can coexist with another. It re-arms on
// re-entry to sdcore1.

#pragma once

namespace BahamutLightOverlay {

void Initialize();
void Shutdown();

// Per-tick driver, called from dinput8's frame loop. Reads the two puzzle bytes
// while the party is in sdcore1, opens the ASK once the puzzle is proven live,
// speaks the Go / Stop edges in Guide mode and holds the disarm pair in Skip
// mode. Near-no-op everywhere else.
void Update();

// True while the puzzle ASK is open.
bool IsAskActive();

}  // namespace BahamutLightOverlay
