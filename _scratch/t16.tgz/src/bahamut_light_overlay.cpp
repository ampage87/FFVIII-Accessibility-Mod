// bahamut_light_overlay.cpp -- the Deep Sea Research Center blue-light puzzle
// (#bahamut-light). See bahamut_light_overlay.h for the design notes and
// bahamut_light_model.inl for the script transcript everything here rests on.
//
// <windows.h> MUST come before field_dialog.h / ff8_addresses.h: those headers
// declare accessors returning Windows types without pulling windows.h in
// themselves, so they rely on the includer having defined it first.
#include <windows.h>
#include <cstdint>
#include <cstdio>
#include <cstring>

#include "bahamut_light_overlay.h"
#include "dialog_inject.h"
#include "ff8_accessibility.h"
#include "ff8_addresses.h"
#include "mod_forward_decls.h"

#include "bahamut_light_model.inl"

namespace BahamutLightOverlay {

using namespace BahamutLightModel;

// ============================================================================
// Constants
// ============================================================================

// Slot 2: the slot the chase and train prompts use. None of the three scenes
// can coexist -- the chase is disc 1 Dollet, the train is disc 1 Timber, and
// this is a disc-3 optional dungeon.
static const int ASK_SLOT = 2;

// If OpenAsk fails (the slot is momentarily busy at the trigger instant), retry
// this often while the party is still in sdcore1 and the ASK has not opened.
static const DWORD RETRY_MS = 250;

// The fallback arming delay, for a player who reaches a Hojo safe pocket before
// the first pulse and so never gives us a var[1024] edge to trigger on.
static const DWORD SETTLE_MS = 6000;

// Choice labels. DialogInject copies these into a 64-byte-per-choice static
// array (PHASE2_NAME_CAP), and the FF8 text encoder drops characters outside
// its table, so both are plain ASCII, apostrophe-free, and under 64 bytes. The
// label itself is what DialogInject speaks on cursor change, which is why each
// one says what the mode DOES rather than naming it.
static const char* kChoices[] = {
    "Guide me: I will say Go and Stop as the light pulses",
    "Skip it: the light stops mattering, walk straight in"
};
static const int kChoicesCount  = 2;
static const int kDefaultCursor = 1;   // Guide

static const char* const ASK_PROMPT =
    "The blue light pulses. How do you want to cross?";

// ============================================================================
// State
// ============================================================================
static bool   s_initialized  = false;
static bool   s_inField      = false;
static DWORD  s_enteredMs    = 0;
static bool   s_pulseSeen    = false;   // var[1024] observed at 1 this visit
static bool   s_askFired     = false;
static bool   s_askOpen      = false;
static bool   s_triggerPend  = false;
static DWORD  s_triggerAt    = 0;
static int    s_mode         = (int)BL_MODE_NONE;
static int    s_prevCue      = (int)BL_CUE_NONE;
static DWORD  s_cueSinceMs   = 0;       // when the current cue began
static bool   s_spokeLast    = false;   // the last speech on the wire was ours
static DWORD  s_spokeAtMs    = 0;
static bool   s_idLogged     = false;   // one-shot id/name cross-check
static bool   s_skipAnnounced = false;

// ============================================================================
// Guarded memory access. No C++ objects in any function that uses __try
// (MSVC C2712); see tests/lint_seh.py.
// ============================================================================
static bool ReadVarB(int index, int* out)
{
    __try {
        *out = (int)(*(volatile const unsigned char*)
                     (uintptr_t)(BL_VAR_BASE + (unsigned)index));
        return true;
    } __except (EXCEPTION_EXECUTE_HANDLER) {
        return false;
    }
}

static bool WriteVarB(int index, unsigned char v)
{
    __try {
        *(volatile unsigned char*)(uintptr_t)(BL_VAR_BASE + (unsigned)index) = v;
        return true;
    } __except (EXCEPTION_EXECUTE_HANDLER) {
        return false;
    }
}

// ============================================================================
// Field identity
// ============================================================================
//
// THE ID IS THE AUTHORITY AND THE NAME IS THE CROSS-CHECK, and that order
// matters here more than it does for a read-only feature: `pCurrentFieldName`
// lags the id by seconds (chase_detector.cpp finding 3), so a skip that trusted
// the name would go on writing var[1028] for several seconds INTO THE NEXT
// FIELD, where 0x01CFEDBC means something else entirely.
//
// 846 is not a derived id. sdcore2's own `Director::default` opens with
// `PSHM_W var[84] ; PSHN_L 846 ; == ` -- the game asking "did the party arrive
// from sdcore1?" -- so the number is the script's, not a table's.
static bool FieldIsPuzzle()
{
    if (FF8Addresses::pCurrentFieldId) {
        return (unsigned)(*FF8Addresses::pCurrentFieldId) == BL_FIELD_ID;
    }
    const char* fn = FF8Addresses::pCurrentFieldName;
    return fn && _stricmp(fn, BL_FIELD) == 0;
}

static void LogIdCrossCheckOnce()
{
    if (s_idLogged) return;
    const char* fn = FF8Addresses::pCurrentFieldName;
    const unsigned fid = FF8Addresses::pCurrentFieldId
                       ? (unsigned)(*FF8Addresses::pCurrentFieldId) : 0xFFFFu;
    s_idLogged = true;
    Log::Field("BahamutLight: entered the puzzle field -- id=%u name='%s' "
               "(expected id %u, name '%s')",
               fid, fn ? fn : "(null)", BL_FIELD_ID, BL_FIELD);
}

// ============================================================================
// Speech
// ============================================================================
static void SayCue(const char* text)
{
    const DWORD now = GetTickCount();
    const bool busy = ScreenReader::IsSpeaking();
    const BlSpeakAct act = BlSpeakDecision(busy, s_spokeLast,
                                           (unsigned)(now - s_spokeAtMs),
                                           BL_OWN_MS);
    if (act == BL_SPEAK_DROP) {
        // Deliberately silent: a queued cue arrives after the window it was
        // describing has closed, and the next edge is at most a few seconds away.
        Log::Field("BahamutLight: cue '%s' DROPPED -- something else is speaking", text);
        s_spokeLast = false;
        return;
    }
    ScreenReader::Speak(text, act == BL_SPEAK_INTERRUPT);
    s_spokeLast = true;
    s_spokeAtMs = now;
}

// ============================================================================
// The ASK
// ============================================================================
static bool OpenAsk()
{
    if (s_askOpen) return true;
    DialogInject::ResetLastAnswer();
    const bool ok = DialogInject::OpenAsk(ASK_PROMPT, kChoices, kChoicesCount,
                                          kDefaultCursor, ASK_SLOT,
                                          /*announceCommit=*/false);
    if (!ok) {
        Log::Field("BahamutLight: DialogInject::OpenAsk returned false "
                   "(slot busy?); will retry while in %s", BL_FIELD);
        return false;
    }
    s_askOpen  = true;
    s_askFired = true;
    Log::Field("BahamutLight: puzzle ASK opened (slot=%d, %d choices, default=%d)",
               ASK_SLOT, kChoicesCount, kDefaultCursor);
    return true;
}

static void CommitChoice(int answer)
{
    const BlMode mode = BlModeForAnswer(answer);
    s_mode   = (int)mode;
    s_askOpen = false;
    s_skipAnnounced = false;
    // Force the next reading to look like an edge so the player gets told where
    // they stand immediately rather than waiting out the current phase.
    s_prevCue = (int)BL_CUE_NONE;

    if (mode == BL_MODE_SKIP) {
        ScreenReader::Speak("Skipping the light puzzle. Walk to the light.", false);
        Log::Field("BahamutLight: committed answer %d -- SKIP "
                   "(holding var[%d]=1, var[%d]=0)",
                   answer, BL_VAR_SAFE, BL_VAR_LIGHT);
    } else {
        ScreenReader::Speak("Guiding you. Move on Go, stand still on Stop.", false);
        Log::Field("BahamutLight: committed answer %d -- GUIDE", answer);
    }
    s_spokeLast = true;
    s_spokeAtMs = GetTickCount();
}

// ============================================================================
// Per-visit state
// ============================================================================
static void EnterField()
{
    s_inField       = true;
    s_enteredMs     = GetTickCount();
    s_pulseSeen     = false;
    s_askFired      = false;
    s_askOpen       = false;
    s_triggerPend   = false;
    s_mode          = (int)BL_MODE_NONE;
    s_prevCue       = (int)BL_CUE_NONE;
    s_cueSinceMs    = s_enteredMs;
    s_spokeLast     = false;
    s_skipAnnounced = false;
    s_idLogged      = false;
    LogIdCrossCheckOnce();
}

static void LeaveField()
{
    if (!s_inField) return;
    s_inField     = false;
    s_askOpen     = false;
    s_triggerPend = false;
    s_mode        = (int)BL_MODE_NONE;
    s_prevCue     = (int)BL_CUE_NONE;
    Log::Field("BahamutLight: left the puzzle field; state reset");
}

// ============================================================================
// Public API
// ============================================================================
void Initialize()
{
    if (s_initialized) return;
    s_initialized = true;
    s_inField     = false;
    s_mode        = (int)BL_MODE_NONE;
    s_prevCue     = (int)BL_CUE_NONE;
    Log::Mod("BahamutLightOverlay: Initialized.");
}

void Shutdown()
{
    if (!s_initialized) return;
    LeaveField();
    s_initialized = false;
}

bool IsAskActive()
{
    return s_initialized && s_askOpen;
}

void Update()
{
    if (!s_initialized) return;

    const bool here = FieldIsPuzzle();
    if (here != s_inField) {
        if (here) EnterField(); else LeaveField();
    }
    if (!here) return;

    const DWORD now = GetTickCount();

    // ---- the two bytes -----------------------------------------------------
    int light = 0, safe = 0, story = 0;
    const bool okL = ReadVarB(BL_VAR_LIGHT, &light);
    const bool okS = ReadVarB(BL_VAR_SAFE,  &safe);
    const bool okC = ReadVarB(BL_VAR_STORY, &story);
    const bool readOk = okL && okS;

    if (readOk && light == 1) s_pulseSeen = true;

    // ---- the prompt --------------------------------------------------------
    if (!s_askFired && !s_triggerPend &&
        BlAskReady(true, s_askFired, s_pulseSeen,
                   okC && story != 1,
                   (unsigned)(now - s_enteredMs), (unsigned)SETTLE_MS)) {
        s_triggerPend = true;
        s_triggerAt   = now;
        Log::Field("BahamutLight: arming the puzzle ASK (pulseSeen=%d story=%d)",
                   (int)s_pulseSeen, story);
    }
    if (s_triggerPend && now >= s_triggerAt) {
        if (OpenAsk()) s_triggerPend = false;
        else           s_triggerAt = now + RETRY_MS;
    }
    if (s_askOpen) {
        const int answer = DialogInject::GetLastAnswer();
        if (answer != -1) CommitChoice(answer);
        return;   // no cues and no writes while the prompt is up
    }

    // ---- skip: hold the game's own disarm pair -----------------------------
    if (s_mode == (int)BL_MODE_SKIP) {
        if (readOk && BlSkipWriteNeeded(light, safe)) {
            const bool a = WriteVarB(BL_VAR_SAFE,  1);
            const bool b = WriteVarB(BL_VAR_LIGHT, 0);
            if (!a || !b) {
                Log::Field("BahamutLight: SKIP hold write FAILED -- disengaging");
                s_mode = (int)BL_MODE_GUIDE;
            } else if (!s_skipAnnounced) {
                s_skipAnnounced = true;
                Log::Field("BahamutLight: SKIP engaged -- var[%d] 1, var[%d] 0",
                           BL_VAR_SAFE, BL_VAR_LIGHT);
            }
        }
        return;
    }

    if (s_mode != (int)BL_MODE_GUIDE) return;

    // ---- guide: speak the edges -------------------------------------------
    const BlCue cue = BlCueFor(readOk, light, safe);
    if (!BlCueChanged((BlCue)s_prevCue, cue)) return;

    // Both phases measured, so a later build can decide whether a predictive
    // "ready" is worth having on real numbers rather than a guessed frame rate.
    const unsigned heldMs = (unsigned)(now - s_cueSinceMs);
    Log::Field("BahamutLight: %s  (previous phase %s held %u ms; "
               "script says armed %d frames, safe %d/%d/%d)",
               BlCueText(cue),
               BlCueText((BlCue)s_prevCue),
               heldMs,
               BlArmedFrames(),
               BlSafeFrames(BL_F_TAIL_LO),
               BlSafeFrames(BL_F_TAIL_MID),
               BlSafeFrames(BL_F_TAIL_HI));

    s_prevCue    = (int)cue;
    s_cueSinceMs = now;
    SayCue(BlCueText(cue));
}

}  // namespace BahamutLightOverlay
