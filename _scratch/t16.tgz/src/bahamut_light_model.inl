// bahamut_light_model.inl -- the PURE model of the Deep Sea Research Center's
// blue-light puzzle, the one that guards Bahamut.
//
// Included from bahamut_light_overlay.cpp, and compiled standalone by
// tests/bahamut_light_test.cpp. Nothing here touches game memory, Windows or
// the screen reader.
//
// ============================================================================
// AARON'S DESCRIPTION, AND WHAT THE SCRIPT SAYS
// ============================================================================
//
// Aaron: *"There is a mini-game / puzzle where you must walk toward the glowing
// blue light in order to trigger the dialogue with Bahamut... The trick is that
// the light pulsates, and you are supposed to walk only when the light has
// pulsated off. You have to do a stop-go thing where you go when the light is
// off and stop when it is on."*
//
// The field is **`sdcore1`, id 846** ("Deep Sea Research Center - Lobby 1"),
// and it holds Bahamut's whole scene: `Bahamu::bahamu0..bahamu4`, the
// `BossBattle` trigger line, and messages 17-27 -- "The blue light leads all to
// death.  Turn back...", "You have perceived the resonance...", "Damned
// imbeciles.  Why do you wish to fight?".
//
// Two other DSRC fields were checked and ruled out. `sdcore2` (847) has a
// `light` entity with `tukeru`/`kesu` (turn on / put out) methods, but its
// `Director` gates on `var[84] == 846` -- it is the room you arrive in AFTER
// Bahamut, and its light is scenery. None of `ddruins1-6`, `ddsteam1` or
// `ddtower1-6` names a light entity at all.
//
// ============================================================================
// THE PUZZLE IS TWO BYTES, AND THE SCRIPT WRITES BOTH
// ============================================================================
//
// `Director::default` in sdcore1 is a `while (true)` from dword 623 to 722.
// One iteration, transcribed (offline/jsmdis.py; opcode encoding per
// field_archive_jsm_decode.inl):
//
//     625  RANDOM -> local0                 ; three equally likely pulse tails
//     626  if local0 <= 86:                 ; (172 and else are the other two)
//     630     SOUND(40, 128, 64)            ; the wind-up, pitch 40/80/120
//     634     REQ core::speed               ; the light begins to brighten
//     637     WAIT 18
//     639     if var[1028] == 0:
//     643         var[1024] = 1             ; <-- ARMED
//     645     WAIT 110
//     647     REQ core::down                ; the light begins to fade
//     650     WAIT 48
//     652     var[1024] = 0                 ; <-- SAFE
//     654     WAIT 12
//     656     WAIT 30                       ; 30 / 20 / 5, by the random pick
//     658  goto 623
//
// **`var[1024]` (0x01CFEDB8) IS THE PUZZLE.** Two entities do nothing but watch
// it -- `battlekun1::default` and `battlekun4::default`, identical but for one
// mask:
//
//     while (true)
//         if var[1024] == 1 and BTNTEST(0x1000):       ; 0x2000 in battlekun4
//             r = RANDOM
//             BATTLE(318 | 319 | 320, 128)             ; by the same thirds
//             WAIT 45
//
// So the penalty is a random encounter, and it fires only while the byte is 1
// and a direction is held. Nothing else in the field reads it. That is why the
// mod does not need to see the screen, count frames or find the light's model:
// **the game keeps the answer in a byte, and the byte is exact.**
//
// `var[1028]` (0x01CFEDBC) is the game's OWN disarm, and it is not ours to
// invent. Three trigger lines -- `Hojo::touch`, `HojoHojo1::touch`,
// `HojoHojo2::touch` -- are seven dwords each and all three are the same:
//
//     var[1028] = 1 ; var[1024] = 0 ; op 0x3B
//
// They are the safe pockets along the corridor. While var[1028] is non-zero the
// Director's `if var[1028] == 0` fails and the light NEVER arms, so the walk is
// free. `Director::default` clears it on entry to the field, and `Koe::touch`
// -- the mid-corridor Bahamut voice line -- clears it again and re-arms
// var[1024] behind itself.
//
// THE SKIP IS THEREFORE THE GAME'S OWN SAFE POCKET, HELD OPEN. Nothing is
// forged: the mod writes exactly the pair of bytes the Hojo lines write, and
// holds them, because Koe::touch will otherwise take them back mid-corridor.
// Every other consequence of the scene -- Bahamut's dialogue, the AASK, the
// battle, the GF -- is downstream of `BossBattle::touch`, which does not read
// either byte and which opens with `var[1024] = 0` of its own accord.
//
// ============================================================================
// THE WINDOWS, AND WHY THE CUE IS AN EDGE
// ============================================================================
//
// From the transcript above, in script frames:
//
//     armed   110 + 48                        = 158   always
//     safe    18 (brightening) + 12 + tail     = 60 / 50 / 35
//
// The light is DANGEROUS for two and a half to three times as long as it is
// safe, and the safe window is the short one -- which is the whole difficulty
// of the puzzle and the reason a sighted player watches it so intently.
//
// The mod cannot lengthen that window, so it must not waste any of it. The cue
// fires on the EDGE of var[1024], not on a timer and not on a prediction: the
// instant the byte clears, the safe window has begun and the words are "Go".
// There is no lead time to give -- var[1024] goes to 1 eighteen frames after
// the wind-up sound the script plays, and the mod has no way to see that sound.
//
// What this module DOES do is measure both phases in milliseconds and log them,
// because a predictive cue (a "ready" a beat before the light clears) is worth
// building on measured numbers and worth nothing built on a guessed frame rate.
// One BAT hands those back.
// ============================================================================

namespace BahamutLightModel {

// ---- the field -------------------------------------------------------------
static const char* const BL_FIELD    = "sdcore1";
static const unsigned    BL_FIELD_ID = 846u;

// ---- the variables ---------------------------------------------------------
static const unsigned BL_VAR_BASE  = 0x01CFE9B8u;
static const int      BL_VAR_LIGHT = 1024;   // 1 = the light is lethal
static const int      BL_VAR_SAFE  = 1028;   // non-zero = the pulse is disarmed
// `Director::default` runs its arrival cutscene only while this is 1, and
// writes 2 at the end of it. So "not 1" means the scene is not playing.
static const int      BL_VAR_STORY = 614;

// ---- the windows, in script frames -----------------------------------------
static const int BL_F_BRIGHTEN = 18;    // light rising, byte still 0
static const int BL_F_HOLD     = 110;   // armed, light full
static const int BL_F_FADE     = 48;    // armed, light falling
static const int BL_F_DARK     = 12;    // safe, fixed part of the tail
static const int BL_F_TAIL_LO  = 5;     // the three random tails
static const int BL_F_TAIL_MID = 20;
static const int BL_F_TAIL_HI  = 30;

static int BlArmedFrames() { return BL_F_HOLD + BL_F_FADE; }
static int BlSafeFrames(int tail) { return BL_F_BRIGHTEN + BL_F_DARK + tail; }

// ---- what the player should be doing ---------------------------------------
enum BlCue {
    BL_CUE_NONE  = 0,   // say nothing (no reading yet)
    BL_CUE_GO    = 1,   // the light is off -- walk
    BL_CUE_STOP  = 2,   // the light is on -- stand still
    BL_CUE_CLEAR = 3    // a Hojo line disarmed the pulse -- walk freely
};

// The safe byte WINS over the light byte, and that is not a preference: while
// var[1028] is set the Director cannot write var[1024] at all, so a stale 1
// left there by Koe::touch would otherwise have the mod calling "Stop" down a
// corridor where nothing can hurt the player.
static BlCue BlCueFor(bool readOk, int lightVar, int safeVar)
{
    if (!readOk) return BL_CUE_NONE;
    if (safeVar != 0) return BL_CUE_CLEAR;
    return (lightVar == 1) ? BL_CUE_STOP : BL_CUE_GO;
}

static const char* BlCueText(BlCue c)
{
    switch (c) {
        case BL_CUE_GO:    return "Go";
        case BL_CUE_STOP:  return "Stop";
        case BL_CUE_CLEAR: return "Clear. The light cannot reach you here.";
        default:           return "";
    }
}

// Announce on the EDGE only. A cue that has not changed is a cue the player is
// already acting on, and repeating it into a 35-frame window is worse than
// silence.
static bool BlCueChanged(BlCue prev, BlCue now)
{
    return now != BL_CUE_NONE && now != prev;
}

// ---- getting the word out in time ------------------------------------------
//
// A queued "Go" is a lie: by the time it reaches the player the window it was
// describing has closed. So a cue that cannot be spoken PROMPTLY is dropped
// rather than queued, and the next edge will carry the truth.
//
// The one thing worth interrupting is our own previous cue, which is why the
// decision needs to know whether the last thing this module spoke is recent
// enough to still be what is on the wire. Anything else that is speaking is a
// story line -- Bahamut's own voice comes down this corridor via `Koe::touch`
// -- and cutting one of those off is not a trade worth making for a word the
// next edge will repeat.
enum BlSpeakAct {
    BL_SPEAK_DROP      = 0,
    BL_SPEAK_QUEUE     = 1,
    BL_SPEAK_INTERRUPT = 2
};

// Longer than either cue can take to say, and shorter than the armed window.
static const unsigned BL_OWN_MS = 1500u;

static BlSpeakAct BlSpeakDecision(bool busy, bool spokeLast, unsigned sinceMs,
                                  unsigned ownMs)
{
    if (!busy) return BL_SPEAK_QUEUE;
    if (spokeLast && sinceMs < ownMs) return BL_SPEAK_INTERRUPT;
    return BL_SPEAK_DROP;
}

// ---- the skip --------------------------------------------------------------
//
// The pair the Hojo lines write. Held every tick, because Koe::touch takes both
// back partway down the corridor and a skip that stops working halfway is worse
// than one that was never offered.
static bool BlSkipWriteNeeded(int lightVar, int safeVar)
{
    return lightVar != 0 || safeVar != 1;
}

// ---- when to ask -----------------------------------------------------------
//
// The prompt must not land in the middle of the arrival cutscene, and it must
// still arrive for a player who walks straight into a Hojo pocket and never
// sees a pulse. Two ways in:
//
//   * the pulse loop proves itself -- var[1024] observed at 1. This is the
//     normal path and it is self-verifying: if the byte moved, the Director is
//     past its cutscene and the puzzle is live;
//   * or the cutscene is demonstrably not running (var[614] != 1) and the party
//     has been in the field long enough to have settled.
static bool BlAskReady(bool inField, bool alreadyFired, bool pulseSeen,
                       bool cutsceneIdle, unsigned inFieldMs, unsigned settleMs)
{
    if (!inField || alreadyFired) return false;
    if (pulseSeen) return true;
    return cutsceneIdle && inFieldMs >= settleMs;
}

// ---- the modes -------------------------------------------------------------
enum BlMode {
    BL_MODE_NONE  = 0,   // not asked yet / left the field
    BL_MODE_GUIDE = 1,   // the mod calls Go and Stop
    BL_MODE_SKIP  = 2    // the pulse is held disarmed
};

static const int BL_ANSWER_GUIDE = 1;
static const int BL_ANSWER_SKIP  = 2;

static BlMode BlModeForAnswer(int answer)
{
    return (answer == BL_ANSWER_SKIP) ? BL_MODE_SKIP : BL_MODE_GUIDE;
}

}  // namespace BahamutLightModel
