// bahamut_light_test.cpp -- the Deep Sea Research Center light puzzle's pure
// model (#bahamut-light, v0.98.0).
//
// Compiles src/bahamut_light_model.inl standalone -- the same text the mod's
// own translation unit includes -- and asserts the properties the corridor
// depends on. Every assertion below was written against a mutant: the note on
// each one says which change it kills.
#include <cstdio>
#include <cstring>
#include <cstdint>

#include "bahamut_light_model.inl"

using namespace BahamutLightModel;

static int g_fail = 0;
static void CHECK(bool cond, const char* what)
{
    if (!cond) { printf("FAIL: %s\n", what); g_fail++; }
}

// ---------------------------------------------------------------------------
// The cue
// ---------------------------------------------------------------------------
static void TestCue()
{
    // The plain reading of the puzzle byte.
    CHECK(BlCueFor(true, 1, 0) == BL_CUE_STOP, "light armed -> Stop");
    CHECK(BlCueFor(true, 0, 0) == BL_CUE_GO,   "light clear -> Go");

    // A byte we could not read is not a byte. Kills the mutant that treats a
    // failed read as zero and cheerfully calls "Go" into an armed corridor.
    CHECK(BlCueFor(false, 0, 0) == BL_CUE_NONE, "unreadable -> no cue (from 0)");
    CHECK(BlCueFor(false, 1, 0) == BL_CUE_NONE, "unreadable -> no cue (from 1)");

    // THE SAFE BYTE WINS, AND THE CASE THAT MATTERS IS THE CONTRADICTORY ONE.
    // Koe::touch leaves var[1024] at 1 behind it, and a Hojo pocket can then set
    // var[1028] without anything clearing var[1024] -- so (1, 1) is reachable in
    // the real corridor and it is SAFE. Kills the mutant that checks the light
    // byte first, which would pass every non-contradictory case.
    CHECK(BlCueFor(true, 1, 1) == BL_CUE_CLEAR, "safe pocket beats a stale armed byte");
    CHECK(BlCueFor(true, 0, 1) == BL_CUE_CLEAR, "safe pocket with the light clear");
    // Any non-zero disarms: the script tests `== 0`, not `!= 1`.
    CHECK(BlCueFor(true, 1, 2) == BL_CUE_CLEAR, "safe byte is a zero test, not a one test");

    // The words themselves are the deliverable; a swap is silent otherwise.
    CHECK(strcmp(BlCueText(BL_CUE_GO),   "Go")   == 0, "Go says Go");
    CHECK(strcmp(BlCueText(BL_CUE_STOP), "Stop") == 0, "Stop says Stop");
    CHECK(BlCueText(BL_CUE_NONE)[0] == '\0', "no cue says nothing");
}

// ---------------------------------------------------------------------------
// The edge
// ---------------------------------------------------------------------------
static void TestEdge()
{
    CHECK(BlCueChanged(BL_CUE_STOP, BL_CUE_GO),  "arm -> clear is announced");
    CHECK(BlCueChanged(BL_CUE_GO, BL_CUE_STOP),  "clear -> arm is announced");
    CHECK(BlCueChanged(BL_CUE_NONE, BL_CUE_GO),  "the first reading is announced");

    // Repeating a cue into a 35-frame window is worse than silence.
    CHECK(!BlCueChanged(BL_CUE_GO, BL_CUE_GO),     "an unchanged Go is not repeated");
    CHECK(!BlCueChanged(BL_CUE_STOP, BL_CUE_STOP), "an unchanged Stop is not repeated");

    // Losing the read must not produce speech. Kills the mutant that drops the
    // `now != BL_CUE_NONE` term, which every other case above still passes.
    CHECK(!BlCueChanged(BL_CUE_GO, BL_CUE_NONE),   "a lost reading is not announced");
    CHECK(!BlCueChanged(BL_CUE_NONE, BL_CUE_NONE), "no reading at all is not announced");
}

// ---------------------------------------------------------------------------
// Getting the word out
// ---------------------------------------------------------------------------
static void TestSpeak()
{
    // Nothing on the wire: just say it.
    CHECK(BlSpeakDecision(false, false, 0,    BL_OWN_MS) == BL_SPEAK_QUEUE,
          "idle channel -> speak");
    CHECK(BlSpeakDecision(false, true, 99999, BL_OWN_MS) == BL_SPEAK_QUEUE,
          "idle channel -> speak even if our last cue is ancient");

    // Our own previous cue is the one thing worth cutting off.
    CHECK(BlSpeakDecision(true, true, 100, BL_OWN_MS) == BL_SPEAK_INTERRUPT,
          "our own recent cue is interrupted");

    // A story line is not. Bahamut's own voice comes down this corridor via
    // Koe::touch, and the next edge repeats the cue within seconds.
    CHECK(BlSpeakDecision(true, false, 0, BL_OWN_MS) == BL_SPEAK_DROP,
          "someone else speaking -> drop the cue");
    CHECK(BlSpeakDecision(true, true, BL_OWN_MS, BL_OWN_MS) == BL_SPEAK_DROP,
          "our claim on the channel expires at the boundary");
    CHECK(BlSpeakDecision(true, true, BL_OWN_MS + 1, BL_OWN_MS) == BL_SPEAK_DROP,
          "and stays expired past it");

    // The window has to be shorter than the phase it lives inside, or a cue
    // would still be claiming the channel when the next one arrives.
    CHECK(BL_OWN_MS < 3000u, "the ownership window is shorter than an armed phase");
}

// ---------------------------------------------------------------------------
// The skip
// ---------------------------------------------------------------------------
static void TestSkip()
{
    // The pair the Hojo lines write. Nothing to do once it is in place.
    CHECK(!BlSkipWriteNeeded(0, 1), "the disarmed pair needs no write");

    // Koe::touch takes both back: it sets var[1028] = 0 and var[1024] = 1.
    // Either half alone must re-trigger the hold. Kills a mutant that only
    // watches the light byte, and one that only watches the safe byte.
    CHECK(BlSkipWriteNeeded(1, 1), "a re-armed light byte is rewritten");
    CHECK(BlSkipWriteNeeded(0, 0), "a cleared safe byte is rewritten");
    CHECK(BlSkipWriteNeeded(1, 0), "Koe::touch taking both back is rewritten");

    // The skip is exactly the game's own disarm, so the value written to the
    // safe byte is 1 -- the literal the three Hojo::touch lines push.
    CHECK(!BlSkipWriteNeeded(0, 1) && BlSkipWriteNeeded(0, 2),
          "the hold targets 1 specifically, not just non-zero");
}

// ---------------------------------------------------------------------------
// When to ask
// ---------------------------------------------------------------------------
static void TestAsk()
{
    const unsigned SETTLE = 6000u;

    // Off the field, never.
    CHECK(!BlAskReady(false, false, true, true, 99999u, SETTLE), "not in the field, no prompt");
    // Once per visit.
    CHECK(!BlAskReady(true, true, true, true, 99999u, SETTLE), "already asked, no second prompt");

    // The normal path: the pulse proved itself, so the Director is past its
    // arrival cutscene whatever the story byte says.
    CHECK(BlAskReady(true, false, true, false, 0u, SETTLE),
          "a seen pulse arms the prompt immediately");

    // The fallback, for a player who walks into a Hojo pocket before the first
    // pulse and so never gives us an edge.
    CHECK(BlAskReady(true, false, false, true, SETTLE, SETTLE),
          "settled with the cutscene idle arms the prompt");
    CHECK(!BlAskReady(true, false, false, true, SETTLE - 1u, SETTLE),
          "the settle delay is honoured");

    // AND THE CUTSCENE IS NOT INTERRUPTED. var[614] == 1 is the Director's own
    // gate on the arrival scene; the prompt must wait it out no matter how long
    // the party has been standing there. Kills the mutant that drops the
    // cutscene term, which every other fallback case above still passes.
    CHECK(!BlAskReady(true, false, false, false, 99999u, SETTLE),
          "the arrival cutscene is never interrupted");
}

// ---------------------------------------------------------------------------
// The windows, as the script defines them
// ---------------------------------------------------------------------------
static void TestWindows()
{
    // Straight from Director::default: 110 + 48 armed, and three safe tails.
    CHECK(BlArmedFrames() == 158, "the armed phase is 110 + 48 frames");
    CHECK(BlSafeFrames(BL_F_TAIL_LO)  == 35, "the shortest safe window is 35 frames");
    CHECK(BlSafeFrames(BL_F_TAIL_MID) == 50, "the middle safe window is 50 frames");
    CHECK(BlSafeFrames(BL_F_TAIL_HI)  == 60, "the longest safe window is 60 frames");

    // THE ASYMMETRY IS THE PUZZLE. The light is dangerous for well over twice
    // as long as it is safe, which is why the cue fires on the edge and is
    // never queued behind anything.
    CHECK(BlArmedFrames() > 2 * BlSafeFrames(BL_F_TAIL_HI),
          "armed is more than twice the longest safe window");

    // The brightening lead-in is safe: the script waits 18 frames after the
    // light starts to glow before it arms the byte. A model that folded those
    // frames into the armed phase would have the mod calling Stop early.
    CHECK(BL_F_BRIGHTEN == 18, "the brightening lead-in is 18 safe frames");
    CHECK(BlSafeFrames(0) == BL_F_BRIGHTEN + BL_F_DARK,
          "a zero tail still leaves the lead-in and the dark");
}

// ---------------------------------------------------------------------------
// The modes
// ---------------------------------------------------------------------------
static void TestModes()
{
    CHECK(BlModeForAnswer(BL_ANSWER_GUIDE) == BL_MODE_GUIDE, "answer 1 is Guide");
    CHECK(BlModeForAnswer(BL_ANSWER_SKIP)  == BL_MODE_SKIP,  "answer 2 is Skip");
    // DialogInject returns -1 for "no answer yet" and the engine can commit a
    // cursor outside the list. Anything unrecognised must land on the mode that
    // changes nothing about the game.
    CHECK(BlModeForAnswer(-1) == BL_MODE_GUIDE, "no answer falls back to Guide");
    CHECK(BlModeForAnswer(7)  == BL_MODE_GUIDE, "an out-of-range answer falls back to Guide");
}

// ---------------------------------------------------------------------------
// The addresses
// ---------------------------------------------------------------------------
static void TestAddresses()
{
    // The two bytes battlekun1/battlekun4 and the Hojo lines actually use.
    CHECK(BL_VAR_BASE + (unsigned)BL_VAR_LIGHT == 0x01CFEDB8u, "var[1024] is 0x01CFEDB8");
    CHECK(BL_VAR_BASE + (unsigned)BL_VAR_SAFE  == 0x01CFEDBCu, "var[1028] is 0x01CFEDBC");
    CHECK(BL_VAR_BASE + (unsigned)BL_VAR_STORY == 0x01CFEC1Eu, "var[614] is 0x01CFEC1E");
    // The field id is the game's own: sdcore2 asks `var[84] == 846` to find out
    // whether the party arrived from this room.
    CHECK(BL_FIELD_ID == 846u, "the puzzle field is 846");
    CHECK(strcmp(BL_FIELD, "sdcore1") == 0, "the puzzle field is sdcore1");
}

int main()
{
    TestCue();
    TestEdge();
    TestSpeak();
    TestSkip();
    TestAsk();
    TestWindows();
    TestModes();
    TestAddresses();
    if (g_fail == 0) printf("bahamut_light_test: all checks passed\n");
    return g_fail ? 1 : 0;
}
