// field_overlay.cpp -- see field_overlay.h for why this exists.

#include "field_overlay.h"
#include "mod_forward_decls.h"

#include <windows.h>
#include <gl/GL.h>
#include <cstdint>
#include <cstring>
#include <cstdio>
#include <cstdlib>

#ifndef GL_BGR_EXT
#define GL_BGR_EXT 0x80E0
#endif

// The arithmetic lives in its own file so the probe can compile the same
// definitions this build uses.
#include "field_overlay_pure.inl"

namespace FieldOverlay {

// ---------------------------------------------------------------------------
// The rasteriser. Mod thread only.
// ---------------------------------------------------------------------------

static const int FP_CELL_H = 22;
static const int FP_PAD    = 10;

static uint8_t* s_pixels   = nullptr;   // RGB, bottom-up, published complete
static int      s_w        = 0;
static int      s_h        = 0;
static volatile bool s_show = false;
static int      s_cellW    = 0;
static int      s_cellH    = 0;   // published for the read-back's row maths
static int      s_padPx    = 0;
static bool     s_drawLogged = false;

bool IsShown() { return s_show; }

void Hide()
{
    if (!s_show) return;
    s_show = false;
    Log::Field("FieldNavigation: [OVERLAY] hidden");
}

void Shutdown()
{
    s_show = false;
    if (s_pixels) { free(s_pixels); s_pixels = nullptr; }
    s_w = s_h = 0;
}

bool Show(const char* text)
{
    if (!text || !text[0]) return false;

    HDC screen = GetDC(nullptr);
    HDC dc = CreateCompatibleDC(screen);
    ReleaseDC(nullptr, screen);
    if (!dc) return false;

    // A fixed-pitch face, so Measure()'s cell arithmetic is the truth rather
    // than an estimate. Consolas ships with every Windows this game runs on;
    // Courier New is the fallback, and FIXED_PITCH|FF_MODERN makes the mapper
    // pick another monospace face rather than a proportional one if neither is
    // present.
    HFONT font = CreateFontA(FP_CELL_H, 0, 0, 0, FW_SEMIBOLD, FALSE, FALSE, FALSE,
                             DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,
                             ANTIALIASED_QUALITY, FIXED_PITCH | FF_MODERN, "Consolas");
    if (!font)
        font = CreateFontA(FP_CELL_H, 0, 0, 0, FW_SEMIBOLD, FALSE, FALSE, FALSE,
                           DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,
                           ANTIALIASED_QUALITY, FIXED_PITCH | FF_MODERN, "Courier New");
    if (!font) { DeleteDC(dc); return false; }
    HGDIOBJ oldFont = SelectObject(dc, font);

    TEXTMETRICA tm = {};
    GetTextMetricsA(dc, &tm);
    const int cellW = tm.tmAveCharWidth > 0 ? tm.tmAveCharWidth : (FP_CELL_H / 2);
    const int cellH = tm.tmHeight > 0 ? tm.tmHeight : FP_CELL_H;

    const Layout L = Measure(text, cellW, cellH, FP_PAD, FP_MAX_W, FP_MAX_H);
    if (L.w <= 0 || L.h <= 0) {
        SelectObject(dc, oldFont); DeleteObject(font); DeleteDC(dc); return false;
    }

    // A bottom-up 32-bit DIB, because that is the row order glDrawPixels wants
    // and converting it twice would be work for nothing.
    BITMAPINFO bi = {};
    bi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
    bi.bmiHeader.biWidth = L.w;
    bi.bmiHeader.biHeight = L.h;          // positive = bottom-up
    bi.bmiHeader.biPlanes = 1;
    bi.bmiHeader.biBitCount = 32;
    bi.bmiHeader.biCompression = BI_RGB;
    void* bits = nullptr;
    HBITMAP dib = CreateDIBSection(dc, &bi, DIB_RGB_COLORS, &bits, nullptr, 0);
    if (!dib || !bits) {
        if (dib) DeleteObject(dib);
        SelectObject(dc, oldFont); DeleteObject(font); DeleteDC(dc); return false;
    }
    HGDIOBJ oldBmp = SelectObject(dc, dib);

    // Background, then a one-pixel border, then the text. Dark box, light text:
    // the same contrast the game's own window uses, and the one a sighted person
    // reading over his shoulder will expect.
    RECT all = { 0, 0, L.w, L.h };
    HBRUSH bg = CreateSolidBrush(RGB(12, 16, 32));
    FillRect(dc, &all, bg);
    DeleteObject(bg);
    HBRUSH border = CreateSolidBrush(RGB(200, 210, 235));
    FrameRect(dc, &all, border);
    DeleteObject(border);

    SetBkMode(dc, TRANSPARENT);
    SetTextColor(dc, RGB(240, 244, 255));

    int y = FP_PAD;
    const char* p = text;
    for (int line = 0; line < L.lines; line++) {
        const char* e = strchr(p, '\n');
        int len = e ? (int)(e - p) : (int)strlen(p);
        if (len > L.cols) len = L.cols;
        TextOutA(dc, FP_PAD, y, p, len);
        y += cellH;
        if (!e) break;
        p = e + 1;
    }

    // FLUSH BEFORE READING THE BITS. GDI batches: the calls above are queued,
    // not necessarily executed, and reading a DIB section's memory directly
    // does not force them out. Aaron's 2026-08-23 22:05 screenshot is what that
    // looks like -- the border and the FIRST line of ten had landed, the other
    // nine had not, and the background was still whatever the allocation
    // happened to contain. GdiFlush is the one line that makes a DIB section
    // safe to read by pointer.
    // ------------------------------------------------------------------
    // LET GO OF THE BITMAP BEFORE READING ITS MEMORY.
    // ------------------------------------------------------------------
    // v0.65.1 added GdiFlush() here and it was not enough: Aaron's 22:45
    // screenshot still showed one line of ten on a background that was never
    // painted. The rule GDI actually enforces is stronger than "flush" -- while
    // a DIB section is SELECTED INTO A DC, reading its bits by pointer is not
    // defined, and the documented way to make it defined is to deselect it
    // first. So the DC is now fully torn down before a single byte is read.
    // The DIB section's memory stays valid until DeleteObject(dib), which is
    // why that one call is left until after the copy.
    GdiFlush();
    SelectObject(dc, oldBmp);
    SelectObject(dc, oldFont);
    DeleteObject(font);
    DeleteDC(dc);

    // FOUR BYTES A PIXEL, NOT THREE.
    //
    // v0.65.2 packed to 24-bit and declared GL_RGB, and the 2026-08-23 23:39
    // BAT showed what this renderer does with that. The bitmap was PERFECT --
    // "[OVERLAY] ink per line: 1202,1823,1762,1690,1706,841,1564,1330,1420,1584",
    // all ten lines present -- and the screen still showed one line on a wash of
    // grey. The give-away is the geometry: a box declared 372 wide came out
    // about 279 on screen, and 279 is 372 * 3/4. The layer under this
    // glDrawPixels consumed our 372x3 bytes as 279 FOUR-BYTE pixels: it ignores
    // GL_RGB and the UNPACK_ALIGNMENT and reads RGBA regardless. Row 0 is
    // therefore nearly right, and every row after it drifts by a quarter of a
    // row, which is exactly the diagonal-ish banding in his screenshot and
    // exactly why only the top line survived.
    //
    // So give it what it is going to read anyway. 32-bit rows are 4-aligned by
    // construction, GL_RGBA is core GL 1.1 and needs no extension, and the DIB
    // is already 32-bit -- this copy now only swaps R and B rather than
    // repacking. There is no longer a stride for anything to disagree about.
    const size_t need = (size_t)L.w * (size_t)L.h * 4;
    uint8_t* buf = (uint8_t*)malloc(need);
    if (buf) {
        const uint8_t* src = (const uint8_t*)bits;
        for (int row = 0; row < L.h; row++) {
            const uint8_t* s = src + (size_t)row * (size_t)L.w * 4;
            uint8_t* d = buf + (size_t)row * (size_t)L.w * 4;
            for (int col2 = 0; col2 < L.w; col2++) {
                d[col2 * 4 + 0] = s[col2 * 4 + 2];   // R
                d[col2 * 4 + 1] = s[col2 * 4 + 1];   // G
                d[col2 * 4 + 2] = s[col2 * 4 + 0];   // B
                d[col2 * 4 + 3] = 255;               // A -- opaque, always
            }
        }
    }
    DeleteObject(dib);

    if (!buf) return false;

    // ------------------------------------------------------------------
    // AND SAY WHAT IS ACTUALLY IN IT.
    // ------------------------------------------------------------------
    // Two BATs have now gone by on a guess about where the text is being lost,
    // and a guess costs Aaron a build and an eight-minute scene each time. This
    // counts the light pixels in each text row of the bitmap it just built and
    // prints one number per line. Ten non-zero numbers mean the rasteriser is
    // right and the fault is in the GL blit; one non-zero number means the
    // rasteriser is still dropping nine lines and GL is innocent. Either way
    // the next log settles it without another guess.
    {
        char ink[160]; int n = 0;
        ink[0] = '\0';
        for (int line = 0; line < L.lines && n < (int)sizeof(ink) - 8; line++) {
            // Text rows run downward from the top in GDI terms, and the buffer
            // is bottom-up, so line 0 lives at the HIGH end of the rows.
            const int top = L.h - FP_PAD - (line + 1) * cellH;
            long lit = 0;
            for (int row = top; row < top + cellH; row++) {
                if (row < 0 || row >= L.h) continue;
                const uint8_t* d = buf + (size_t)row * (size_t)L.w * 4;
                for (int c2 = 0; c2 < L.w; c2++)
                    if (d[c2 * 4] > 120) lit++;      // brighter than the box
            }
            n += snprintf(ink + n, sizeof(ink) - n, "%s%ld",
                          line ? "," : "", lit);
        }
        Log::Field("FieldNavigation: [OVERLAY] ink per line: %s "
                   "(0 means that line never made it into the bitmap)", ink);
    }

    // PUBLISH. The show flag goes down first so the render thread cannot be
    // reading the old buffer as it is freed, then the new one goes up complete.
    s_show = false;
    uint8_t* old = s_pixels;
    s_pixels = buf;
    s_w = L.w; s_h = L.h; s_cellW = cellW; s_cellH = cellH; s_padPx = FP_PAD;
    s_drawLogged = false;
    s_show = true;
    if (old) free(old);

    Log::Field("FieldNavigation: [OVERLAY] shown: %d lines x %d cols -> %dx%d px "
               "(cell %dx%d)%s", L.lines, L.cols, L.w, L.h, cellW, cellH,
               L.clamped ? "  *** CLAMPED -- text did not fit ***" : "");
    return true;
}

// ---------------------------------------------------------------------------
// The blit. Render thread only. No allocation, no GDI, no logging except once.
// ---------------------------------------------------------------------------
void Draw()
{
    if (!s_show) return;
    uint8_t* px = s_pixels;
    if (!px || s_w <= 0 || s_h <= 0) return;

    GLint vp[4] = { 0, 0, 0, 0 };
    glGetIntegerv(GL_VIEWPORT, vp);
    const int vw = vp[2], vh = vp[3];
    if (vw <= 0 || vh <= 0) return;

    const int zoom = ZoomFor(vh, s_h);
    int x = 0, y = 0;
    PlaceFor(vw, vh, s_w, s_h, zoom, &x, &y);

    glPushAttrib(GL_ALL_ATTRIB_BITS);
    glMatrixMode(GL_PROJECTION); glPushMatrix(); glLoadIdentity();
    glOrtho(0.0, (double)vw, 0.0, (double)vh, -1.0, 1.0);
    glMatrixMode(GL_MODELVIEW);  glPushMatrix(); glLoadIdentity();

    glDisable(GL_DEPTH_TEST);
    glDisable(GL_TEXTURE_2D);
    glDisable(GL_BLEND);
    glDisable(GL_LIGHTING);
    glDisable(GL_SCISSOR_TEST);
    glDisable(GL_STENCIL_TEST);
    glDisable(GL_CULL_FACE);
    glDisable(GL_ALPHA_TEST);
    glPixelStorei(GL_UNPACK_ALIGNMENT, 4);
    glPixelZoom((GLfloat)zoom, (GLfloat)zoom);
    glRasterPos2i(x, y);
    glDrawPixels(s_w, s_h, GL_RGBA, GL_UNSIGNED_BYTE, px);

    const GLenum err = glGetError();

    // ------------------------------------------------------------------
    // AND READ BACK WHAT ACTUALLY LANDED.
    // ------------------------------------------------------------------
    // Three builds have now gone on inference about this blit, and each one
    // costs Aaron a rebuild and an eight-minute scene. The rasteriser already
    // reports its ink per line; this reports the SAME measure taken off the
    // frame buffer, one row per text line, straight after the draw. Two lists
    // of ten numbers that agree mean the box is on screen and any remaining
    // problem is the screenshot; two that disagree say exactly where the
    // transfer went wrong and by how much.
    //
    // glReadPixels here is the same call battle_tts_screenshot.inl makes from
    // this same hook, so it is known to work. Once per Show(), never allocating:
    // one static row buffer, ten reads of one row each.
    if (!s_drawLogged && zoom == 1 && s_w > 0 && s_w <= 2048 && s_cellH > 0) {
        static uint8_t row[2048 * 4];
        char back[160]; int n = 0; back[0] = '\0';
        const int lines = (s_h - s_padPx * 2) / s_cellH;
        for (int line = 0; line < lines && n < (int)sizeof(back) - 8; line++) {
            // The same row the ink scan calls the middle of this text line,
            // expressed in frame-buffer coordinates (GL counts up from the
            // bottom, and so does our bitmap, so this is a straight offset).
            const int by = y + (s_h - s_padPx - (line + 1) * s_cellH) + s_cellH / 2;
            glReadPixels(x, by, s_w, 1, GL_RGBA, GL_UNSIGNED_BYTE, row);
            long lit = 0;
            for (int c2 = 0; c2 < s_w; c2++) if (row[c2 * 4] > 120) lit++;
            n += snprintf(back + n, sizeof(back) - n, "%s%ld", line ? "," : "", lit);
        }
        Log::Field("FieldNavigation: [OVERLAY] read back from the frame buffer: %s "
                   "(compare with 'ink per line' -- if they disagree, the blit is "
                   "the problem, not the bitmap)", back);
    }

    glPixelZoom(1.0f, 1.0f);
    glMatrixMode(GL_PROJECTION); glPopMatrix();
    glMatrixMode(GL_MODELVIEW);  glPopMatrix();
    glPopAttrib();

    // ONCE per Show(), because this runs sixty times a second. If the renderer
    // turns out to be a core profile the fixed-function path is a no-op and
    // this line is the only thing that will say so.
    if (!s_drawLogged) {
        s_drawLogged = true;
        Log::Field("FieldNavigation: [OVERLAY] first blit: %dx%d at (%d,%d) zoom %d "
                   "in a %dx%d viewport, glGetError=0x%04X%s",
                   s_w, s_h, x, y, zoom, vw, vh, (unsigned)err,
                   err == GL_NO_ERROR ? "" : "  *** the GL call was rejected ***");
    }
}

} // namespace FieldOverlay
