// disc3_wiring_compile.cpp -- compiles AND RUNS the three disc-3 wiring layers
// (#110 Esthar, #111 space rescue, #112 Propagators) on the host.
//
//   g++ -std=c++17 -O0 -Isrc -o disc3_wiring_compile tests/disc3_wiring_compile.cpp
//
// WHY THIS EXISTS
// ---------------
// field_disc3*.inl are textual includes of field_navigation.cpp, which only
// MSVC ever compiles. Nothing on this side of the wire had ever *parsed* them.
// The first thing this probe found, before it ran a single assertion, was that
// `namespace Propagator` shadowed `struct Propagator`, so `const Propagator* p`
// inside it named a namespace -- an error MSVC would have raised too, and which
// lint_braces.py cannot see.
//
// The stubs below stand in for the mod's four seams (field pointers, speech,
// log, the bgbtl tone/key table). The FIELD VARIABLE BLOCK IS NOT STUBBED: the
// probe mmaps real pages at the game's own 0x01CFxxxx addresses, so the wiring
// reads and writes through the exact same D3ReadU8 / D3WriteI32 paths it uses
// in the game, at the exact same addresses the models name. A wrong address
// constant therefore shows up as a wrong answer here, not as silence.
//
// v0.55.0 (#110/#111/#112).

#include <cstdio>
#include <cmath>
#include <cstdarg>
#include <cstdint>
#include <cstring>
#include <cstdlib>
#include <sys/mman.h>
#include <string>
#include <vector>

// ---------------------------------------------------------------------------
// Windows-isms the wiring uses.
// ---------------------------------------------------------------------------
typedef unsigned long  DWORD;
typedef unsigned short WORD;
#define __try       try
#define __except(x) catch (...)
#define EXCEPTION_EXECUTE_HANDLER 1
#define __cdecl
// v0.63.3.1: the same segmented-memory ghosts tests/winshim/windows.h now
// carries. This probe hand-rolls its Win32 surface rather than using the shim,
// so it needs them too -- v0.63.3 defined a local called `far` here, compiled
// green, and failed on MSVC with "error C2513: no variable declared before '='".
// Placed after every standard header, because the point is to poison the mod's
// identifiers and not libstdc++'s.
#define far
#define near
#define pascal
#define huge
#define VK_OEM_2 0xBF
#define VK_F9    0x78
#define VK_RETURN 0x0D

// v0.63.0 gave the space rescue a radar and this stub measured its pitch.
// v0.63.1 took the radar out -- Aaron, after flying the scene to the end on the
// words alone: "Let's get rid of the beep sound effect. It is extremely
// distracting and the TTS announcement I think is sufficient." The stub stays,
// with its counter, and the counter is now asserted to be ZERO across the whole
// scene. A removal that nothing checks grows back.
typedef const char* LPCSTR;
#define SND_MEMORY    0x0004
#define SND_ASYNC     0x0001
#define SND_NODEFAULT 0x0002
static int g_beeps = 0;
static bool PlaySoundA(LPCSTR, void*, unsigned) { g_beeps++; return true; }

static DWORD g_tick = 100000;
static DWORD GetTickCount() { return g_tick; }

static int  g_keyDown = 0;              // bitmask: 1 = '/', 2 = F9, 4 = Enter
static short GetAsyncKeyState(int vk)
{
    if (vk == VK_OEM_2) return (g_keyDown & 1) ? (short)0x8000 : 0;
    if (vk == VK_F9)    return (g_keyDown & 2) ? (short)0x8000 : 0;
    if (vk == VK_RETURN) return (g_keyDown & 4) ? (short)0x8000 : 0;
    return 0;
}
static int _stricmp(const char* a, const char* b)
{
    while (*a && *b) {
        int ca = (*a >= 'A' && *a <= 'Z') ? *a + 32 : *a;
        int cb = (*b >= 'A' && *b <= 'Z') ? *b + 32 : *b;
        if (ca != cb) return ca - cb;
        a++; b++;
    }
    return (unsigned char)*a - (unsigned char)*b;
}

// ---------------------------------------------------------------------------
// Mod seams.
// ---------------------------------------------------------------------------
static char  g_fieldName[64] = "";
static WORD  g_fieldId = 0xFFFF;

namespace FF8Addresses {
    WORD* pCurrentFieldId  = &g_fieldId;
    char* pCurrentFieldName = g_fieldName;
}

struct Utterance { std::string text; bool interrupt; };
static std::vector<Utterance> g_said;
static std::vector<std::string> g_logged;

namespace ScreenReader {
    bool Speak(const char* t, bool interrupt = false)
    { g_said.push_back({ t ? t : "", interrupt }); return true; }
}
namespace Log {
    void Field(const char* fmt, ...)
    {
        char b[1024]; va_list ap; va_start(ap, fmt);
        vsnprintf(b, sizeof(b), fmt, ap); va_end(ap);
        g_logged.push_back(b);
    }
}
static int g_tones = 0;
// v0.63.0: the space brief waits for the scene's own dialogue to finish.
static bool g_dialogOpen = false;
namespace FieldDialog { static bool IsDialogOpen() { return g_dialogOpen; } }

// v0.63.1: the mission clock. The real module is exercised for its own sake by
// tests/countdown_hold_test.cpp, which runs src/countdown_timer.cpp on the host
// against mmap'd engine globals; what THIS probe needs is the seam, and the one
// property of it the space module reasons about -- that a hold placed before
// the engine has written a countdown is a REQUEST and not yet a freeze. g_clock
// stands in for "the engine has started a countdown", so the probe can put the
// module on either side of that line deliberately.
static bool g_clockRunning = false;      // the engine has a detected countdown
static bool g_clockHeld    = false;      // ...and somebody asked us to stop it
static int  g_holdCalls    = 0;
namespace CountdownTimer {
    void SetHold(bool on, const char* reason) { (void)reason; g_clockHeld = on; g_holdCalls++; }
    bool IsHeldFrozen() { return g_clockHeld && g_clockRunning; }
}

namespace GardenBattle {
    // FAITHFUL to field_minigame_bgbtl_input.inl, and it was not before.
    //
    // The first draft of this stub wrote an empty string for an unknown mask,
    // which is what the space brief was written against. The real one has FOUR
    // slots -- BTN_PUNCH 16, BTN_KICK 64, BTN_BLOCK 128, BTN_HEAVY 32 -- and
    // for anything else SlotFor() returns nullptr and CopyKeyName writes the
    // literal "?". The D-pad bits are not in that table, so the shipped brief
    // would have said "? and ? move you left and right" while this probe sat
    // there green. The stub is now the real function's contract, and the space
    // wiring no longer calls it at all.
    static const uint32_t BTN_PUNCH = 16, BTN_KICK = 64, BTN_BLOCK = 128, BTN_HEAVY = 32;
    static void CopyKeyName(char* dst, size_t n, uint32_t mask)
    {
        const char* p = (mask == BTN_PUNCH) ? "W"
                      : (mask == BTN_KICK)  ? "X"
                      : (mask == BTN_BLOCK) ? "A"
                      : (mask == BTN_HEAVY) ? "D"
                      : nullptr;
        if (!p) p = "?";                      // <-- never empty. That is the point.
        snprintf(dst, n, "%s", p);
    }
    static void PlayTone() { g_tones++; }
    // v0.63.2: the space brief names the boost key through the same learner.
    // The real LearnButtons() reads the field button word and refines the map;
    // here it only has to exist and be callable every tick, because what the
    // probe is checking is that the NAME reaches the screen.
    static int g_learnCalls = 0;
    static uint32_t LearnButtons() { g_learnCalls++; return 0; }

    // v0.63.0: the REAL Game Controls window code, not a stub of it.
    //
    // field_minigame_bgbtl_dialog.inl only ever calls the engine through
    // absolute-address function pointers, so it compiles here unchanged -- and
    // compiling it is the point. The space brief is the second caller of
    // OpenBriefDialog, and a stub would have been a statement that the function
    // exists rather than evidence of it, which is precisely the mistake the
    // CopyKeyName note above records. MapEngineWindowStubs() puts a `ret` at
    // each of those addresses so the calls really happen.
    static const int BRIEF_COLS = 34;   // field_minigame_bgbtl.inl:277
    #include "field_minigame_bgbtl_dialog.inl"
}

// ---------------------------------------------------------------------------
// The real field-variable block, at the real addresses.
// ---------------------------------------------------------------------------
// The engine's window entry points, as bare `ret`s. cdecl leaves the caller to
// clean the stack, so 0xC3 is a complete implementation of "do nothing".
static void MapEngineWindowStubs()
{
    const uintptr_t base = 0x0049F000u;
    const size_t    len  = 0x00003000u;      // covers 0x0049FBF0 .. 0x004A0EC0
    void* p = mmap((void*)base, len, PROT_READ | PROT_WRITE | PROT_EXEC,
                   MAP_PRIVATE | MAP_ANONYMOUS | MAP_FIXED, -1, 0);
    if (p != (void*)base) {
        std::printf("FATAL: could not map the engine window stubs at 0x%lX\n",
                    (unsigned long)base);
        std::exit(2);
    }
    memset(p, 0xC3, len);
    // The field context pointer the open/close bits are written through.
    const uintptr_t ctxp = 0x00B8E000u;
    void* c = mmap((void*)ctxp, 0x2000, PROT_READ | PROT_WRITE,
                   MAP_PRIVATE | MAP_ANONYMOUS | MAP_FIXED, -1, 0);
    if (c != (void*)ctxp) {
        std::printf("FATAL: could not map the field context at 0x%lX\n",
                    (unsigned long)ctxp);
        std::exit(2);
    }
    memset(c, 0, 0x2000);
    *(uintptr_t*)(ctxp + 0xE90) = ctxp + 0x1000;   // 0x00B8EE90 -> a real page
}

static const uintptr_t VARPAGE_BASE = 0x01CF0000u;
static const size_t    VARPAGE_LEN  = 0x00020000u;
static void MapVarBlock()
{
    void* p = mmap((void*)VARPAGE_BASE, VARPAGE_LEN, PROT_READ | PROT_WRITE,
                   MAP_PRIVATE | MAP_ANONYMOUS | MAP_FIXED, -1, 0);
    if (p != (void*)VARPAGE_BASE) {
        std::printf("FATAL: could not map the field-variable page at 0x%lX\n",
                    (unsigned long)VARPAGE_BASE);
        std::exit(2);
    }
    std::memset(p, 0, VARPAGE_LEN);
}

// ---------------------------------------------------------------------------
// The code under test.
// ---------------------------------------------------------------------------
// The real display-name table, exactly as field_navigation.cpp includes it at
// line 48 -- field_disc3_esthar.inl formats exit names out of it, so stubbing
// it would be testing a stub.
#include "field_display_names.h"
#include "esthar_pandora_model.inl"
#include "space_rescue_model.inl"
#include "propagator_model.inl"
#include "field_disc3.inl"

// ---------------------------------------------------------------------------
static int bad = 0;
static void check(bool ok, const char* what)
{ if (!ok) { std::printf("  BAD: %s\n", what); bad++; } }

static void setField(const char* name, int id)
{ snprintf(g_fieldName, sizeof(g_fieldName), "%s", name); g_fieldId = (WORD)id; }

static void wr8(int var, uint8_t v)  { *(uint8_t*)(uintptr_t)Disc3::D3VarAddr(var) = v; }
static void wr16(int var, uint16_t v){ *(uint16_t*)(uintptr_t)Disc3::D3VarAddr(var) = v; }
static void wrAddr32(uint32_t a, int32_t v) { *(int32_t*)(uintptr_t)a = v; }
static int32_t rdAddr32(uint32_t a) { return *(int32_t*)(uintptr_t)a; }

// Every utterance, ever, from the moment this probe starts. A "?" in any of
// them means something asked GardenBattle::CopyKeyName for a name it does not
// have and shipped the placeholder to the player.
static std::vector<std::string> g_allSaid;
static void recordAll() { for (auto& u : g_said) g_allSaid.push_back(u.text); }
static void clearSaid() { recordAll(); g_said.clear(); }
static bool saidContains(const char* needle)
{
    for (auto& u : g_said) if (u.text.find(needle) != std::string::npos) return true;
    return false;
}
static std::string lastSaid() { return g_said.empty() ? std::string() : g_said.back().text; }

static void tick(int ms = 16) { g_tick += (DWORD)ms; Disc3::Update(); }

int main()
{
    MapVarBlock();
    MapEngineWindowStubs();
    std::printf("disc3_wiring_compile\n");

    // =======================================================================
    // 0. Address arithmetic: the models name absolute addresses AND variable
    //    indices for the same cells. If those two ever disagree the feature
    //    reads garbage, so pin them against each other.
    // =======================================================================
    // v0.57.0: var[1024] is NOT the Esthar clock -- it is the HUD mirror the
    // field re-establishes every frame, and reading it is what produced the
    // 2026-08-22 flood. Its address is pinned here only so the test below can
    // deliberately fill it with rubbish at the place the module used to look.
    check(Disc3::D3VarAddr(1024) == 0x01CFEDB8u, "var[1024] is at 0x01CFEDB8");
    check(EP_TIMER_ADDR == 0x01CFE92Cu,
          "**the clock is GETTIMER's own address**, not a field variable");
    check(Disc3::D3VarAddr(PG_VAR_PENDFLAG) == PG_ADDR_PENDFLAG, "var[445] == PG_ADDR_PENDFLAG");
    check(Disc3::D3VarAddr(PG_VAR_DEAD)     == PG_ADDR_DEAD,     "var[446] == PG_ADDR_DEAD");
    check(Disc3::D3VarAddr(PG_VAR_PENDBIT)  == PG_ADDR_PENDBIT,  "var[447] == PG_ADDR_PENDBIT");
    check(Disc3::D3VarAddr(1040) == SR_ADDR_X, "var[1040] == SR_ADDR_X");
    check(Disc3::D3VarAddr(1044) == SR_ADDR_Y, "var[1044] == SR_ADDR_Y");
    check(Disc3::D3VarAddr(1052) == SR_ADDR_FUEL,
          "**var[1052] == SR_ADDR_FUEL** -- rinoa::default 16-17 sets it to 8000 "
          "and director1 drains it");
    check(Disc3::D3VarAddr(1034) == SR_ADDR_STEP,
          "**var[1034] == SR_ADDR_STEP** -- the live step, 8 boosted and 4 not");
    check(Disc3::D3VarAddr(EP_VAR_MISSION) == 0x01CFEC58u, "var[672] (mission byte)");

    // =======================================================================
    // 1. SILENCE EVERYWHERE ELSE. The mod spends the whole game outside these
    //    three scenes; every one of them must be a hard no-op. This is the
    //    single most important property in the file.
    // =======================================================================
    setField("bgbtl_1", 100);
    clearSaid(); g_logged.clear(); g_tones = 0;
    for (int i = 0; i < 200; i++) tick();
    check(g_said.empty(), "silent on an unrelated field");
    check(g_logged.empty(), "no log spam on an unrelated field");
    check(g_tones == 0, "no tone on an unrelated field");

    // An Esthar city field with the mission byte NOT set: ordinary city, silent.
    setField("ecmall1", 445);
    wr8(EP_VAR_MISSION, 0);
    clearSaid();
    for (int i = 0; i < 100; i++) tick();
    check(g_said.empty(), "silent in Esthar when the run is not live");

    // =======================================================================
    // 2. ESTHAR (#110) -- REWRITTEN for v0.57.0.
    //
    // The 2026-08-22 BAT: the mod said "you are here, wait" at eccway21 and
    // nothing happened, because eccway21 is a walk-through `touch` line and
    // waiting on one does nothing. And it said it six times a second, because
    // the clock it read alternated with zero.
    //
    // THE CLOCK IS WRITTEN TO THE ENGINE ADDRESS ONLY. var[1024] is deliberately
    // left holding rubbish in every case below: if the module ever reads it
    // again these tests go wrong immediately.
    // =======================================================================
    check(EP_MISSION_LIVE == 19, "the run-live value is 19");
    check(EpTablesConsistent(), "**the generated route and site tables close**");

    setField("ecmall1", 431);
    wr16(EP_VAR_MISSION, 18);                 // one off: must stay silent
    wrAddr32(EP_TIMER_ADDR, 1150);
    wr16(1024, 0);
    clearSaid();
    for (int i = 0; i < 40; i++) tick();
    check(g_said.empty(), "mission byte 18 is not the run and says nothing");

    // --- the flood, reproduced and refuted --------------------------------
    // var[1024] alternating 0 / 1150 is exactly what the BAT log shows. Under
    // v0.55.0 that flipped the target contact point every tick and fired the
    // "point has passed" and "window open" announcements over and over.
    wr16(EP_VAR_MISSION, 19);                 // literal 19, not the constant
    wrAddr32(EP_TIMER_ADDR, 1150);
    setField("ecmview1", 434);
    clearSaid();
    tick();
    check(saidContains("Lunatic Pandora run"), "Esthar greets once the run is live");
    {
        const size_t after = g_said.size();
        for (int i = 0; i < 600; i++) {       // ten seconds
            wr16(1024, (i & 1) ? 0 : 1150);   // the HUD mirror, flapping
            tick();
        }
        check(g_said.size() == after,
              "**ten seconds of var[1024] flapping produces NOT ONE utterance** -- "
              "the module no longer reads it");
    }

    // --- and a floor under interrupting speech, independently of the clock --
    //
    // Fixing the clock removes the cause of the 2026-08-22 flood, but "the
    // cause is gone" is not the same as "it cannot happen". Something else that
    // flaps -- a field id oscillating across a boundary, a future state -- must
    // not be able to produce six interrupting utterances a second again. So the
    // floor is tested by making the input flap on purpose.
    // (Mutation-tested: deleting the floor passes without this.)
    {
        Disc3::Esthar::Reset();
        wrAddr32(EP_TIMER_ADDR, 1150);
        setField("ecmview1", 434);
        clearSaid();
        tick();                                   // the greeting
        const size_t base = g_said.size();
        for (int i = 0; i < 600; i++) {           // ten seconds, field flapping
            setField((i & 1) ? "ecmway1" : "ecmview1", (i & 1) ? 437 : 434);
            tick();
        }
        const size_t spoke = g_said.size() - base;
        // Ten seconds at a 1500 ms floor allows at most seven interrupting
        // utterances. The BAT produced roughly sixty in that time.
        check(spoke <= 7,
              "**a flapping field cannot produce more than one interrupting "
              "utterance per 1.5 seconds** -- the BAT managed six in one second");
        check(spoke > 0, "and it is not silent either -- the floor throttles, it does not gag");
    }

    // --- the route names an exit, and it is the CATALOG's name for it ------
    clearSaid();
    g_keyDown = 1; tick(); g_keyDown = 0; tick();
    check(saidContains("Contact point 1"), "slash names the live contact point");
    check(saidContains("Take the exit to"), "and tells him which exit to take");
    check(saidContains("Esthar - City"),
          "**named the way the catalog names it**, not by internal field name");
    check(!saidContains("ecmway1") && !saidContains("ecopen"),
          "no internal field name is ever spoken to the player");

    // --- eccway21: the exact place the BAT failed -------------------------
    //
    // v0.57.0 said "walk through the exit to Esthar - City 21", and the catalog
    // had no such entry -- the zone filter had dropped the line. Aaron bounced
    // between four fields for eight minutes and missed contact point 1.
    //
    // v0.57.1: the line is forced into the catalog as "Contact point 1", and
    // because crossing it early lands on eciway11 -- which boards you by itself
    // -- the instruction is GO, not "cross at the right moment".
    setField("eccway21", 408);
    wrAddr32(EP_TIMER_ADDR, 800);             // CP1 window OPEN
    clearSaid();
    tick();
    g_keyDown = 1; tick(); g_keyDown = 0; tick();
    {
        std::string s;
        for (auto& u : g_said) s += u.text + " | ";
        check(s.find("Contact point 1 in the catalog") != std::string::npos,
              "**names the catalog entry the player can select and walk to**");
        check(s.find("cross it") != std::string::npos, "and says to cross it");
        check(s.find("wait") == std::string::npos && s.find("Wait") == std::string::npos,
              "never says wait at a crossing");
    }

    // Early: still GO, and it says why that is safe.
    wrAddr32(EP_TIMER_ADDR, 1100);
    Disc3::Esthar::Reset();
    clearSaid();
    tick();
    g_keyDown = 1; tick(); g_keyDown = 0; tick();
    {
        std::string s;
        for (auto& u : g_said) s += u.text + " | ";
        check(s.find("you can go now") != std::string::npos,
              "**early at a CP1 line: GO NOW** -- Aaron's own finding, and the "
              "scripts agree: crossing early lands on the site that boards by itself");
        check(s.find("do not have to watch the clock") != std::string::npos,
              "and says the clock does not matter here");
    }

    // --- CP2 is the one that genuinely needs timing -----------------------
    // Its two lines miss to each other, and neither polls, so crossing early
    // just walks you back and forth. This is the ONLY point where the mod
    // should ask the player to wait for a window.
    check(EpMissIsAuto(EpSiteAt("eccway21", EP_CP1)), "the CP1 line misses to a polling site");
    check(EpMissIsAuto(EpSiteAt("ecmall1",  EP_CP3)), "the CP3 line misses to a polling site");
    check(!EpMissIsAuto(EpSiteAt("eccway12", EP_CP2)), "**the CP2 lines do not**");
    check(!EpMissIsAuto(EpSiteAt("eccway41", EP_CP2)), "either of them");

    setField("eccway12", 404);
    wrAddr32(EP_TIMER_ADDR, 700);             // CP2 shut, opens at 600
    Disc3::Esthar::Reset();
    clearSaid();
    tick();
    g_keyDown = 1; tick(); g_keyDown = 0; tick();
    {
        std::string s;
        for (auto& u : g_said) s += u.text + " | ";
        check(s.find("Wait for it to open") != std::string::npos,
              "**CP2 early: wait for the window** -- the one point where timing is real");
        check(s.find("cross straight back") != std::string::npos,
              "and says an early crossing is recoverable, not fatal");
    }
    wrAddr32(EP_TIMER_ADDR, 500);             // CP2 open
    Disc3::Esthar::Reset();
    clearSaid();
    tick();
    g_keyDown = 1; tick(); g_keyDown = 0; tick();
    check(saidContains("cross it now"), "CP2 open: cross it now");

    // --- the catalog name the mod forces in --------------------------------
    // field_catalog.inl exempts these lines from the zone filter and renames
    // them; EpContactLineAt is what it asks. The midpoints below are the ones
    // the BAT's own [LINE-PAIR] capture reported, which is an independent
    // measurement of the values extracted offline from the LINE opcodes.
    {
        const EstharSite* a = EpContactLineAt("eccway21", 3679, 1248);
        const EstharSite* b = EpContactLineAt("eccway41", -5032, -4205);
        const EstharSite* c = EpContactLineAt("eccway41", -1713, -6966);
        check(a && a->cp == EP_CP1, "**the BAT's captured eccway21 line is contact point 1**");
        check(b && b->cp == EP_CP2, "and eccway41's line0 is contact point 2");
        check(c && c->cp == EP_CP3, "and eccway41's line1 is contact point 3");
        check(!EpContactLineAt("eccway21", 3679, 9999), "a line 8 km away does not match");
        check(!EpContactLineAt("bgbtl_1", 3679, 1248), "and neither does the right point in the wrong field");
        // The offline midpoints and the runtime capture agree to within a unit,
        // so the 64-unit tolerance is slack rather than fudge.
        check(EpSiteAt("eccway21", EP_CP1)->lineX == 3679 &&
              EpSiteAt("eccway21", EP_CP1)->lineY == 1248,
              "the model's midpoint IS the captured one");
    }

    // --- a stopped clock is not an expired one -----------------------------
    // The BAT opened with t=0 in ecmview1, before SETTIMER had run, and v0.57.0
    // announced contact point 3 -- the LAST one -- as the target.
    setField("ecmview1", 434);
    Disc3::Esthar::Reset();
    wrAddr32(EP_TIMER_ADDR, 0);
    clearSaid();
    for (int i = 0; i < 60; i++) tick();
    check(g_said.empty(), "**t=0 before the timer starts says nothing at all**");
    wrAddr32(EP_TIMER_ADDR, 1188);            // SETTIMER fires
    clearSaid();
    tick();
    check(saidContains("Lunatic Pandora run"), "and the run greets once the clock starts");
    g_keyDown = 1; tick(); g_keyDown = 0; tick();
    {
        std::string s;
        for (auto& u : g_said) s += u.text + " | ";
        check(s.find("Contact point 1") != std::string::npos,
              "aiming at point 1, not point 3");
    }
    // ...and once it HAS started, a genuine zero is a genuine zero.
    wrAddr32(EP_TIMER_ADDR, 0);
    clearSaid();
    g_keyDown = 1; tick(); g_keyDown = 0; tick();
    check(!g_said.empty(), "a real zero at the end of the run still reports");

    // --- eciway11: the automatic one. Here 'wait' is the correct answer. ---
    setField("eciway11", 425);
    wrAddr32(EP_TIMER_ADDR, 800);
    wr8(EP_VAR_USED, 0);
    Disc3::Esthar::Reset();
    clearSaid();
    tick();
    g_keyDown = 1; tick(); g_keyDown = 0; tick();
    {
        std::string s;
        for (auto& u : g_said) s += u.text + " | ";
        check(s.find("Stay exactly where you are") != std::string::npos,
              "**eciway11 with the window open: stay put**");
        check(s.find("on its own") != std::string::npos, "and says it is automatic");
    }
    wrAddr32(EP_TIMER_ADDR, 1100);
    Disc3::Esthar::Reset();
    clearSaid();
    tick();
    g_keyDown = 1; tick(); g_keyDown = 0; tick();
    check(saidContains("Wait right here"), "eciway11 early: wait right here");
    check(saidContains("do not have to do anything"), "and nothing is required of him");

    // --- the used-bit: a point already spent must say so ------------------
    wr8(EP_VAR_USED, 0x01);
    Disc3::Esthar::Reset();
    clearSaid();
    tick();
    g_keyDown = 1; tick(); g_keyDown = 0; tick();
    check(saidContains("already been used"),
          "a spent contact point says so instead of promising a boarding");
    wr8(EP_VAR_USED, 0);

    // --- the ladder, through the live feature -----------------------------
    // t counts DOWN, so CP1 (900..720) comes first. These are the boundaries
    // the game's own gates use.
    check(EpTargetPoint(1200) == EP_CP1, "before the run starts, CP1 is next");
    check(EpTargetPoint(901)  == EP_CP1 && !EpWindowOpen(EP_CP1, 901), "at 15:01 CP1 is shut");
    check(EpTargetPoint(900)  == EP_CP1 &&  EpWindowOpen(EP_CP1, 900), "at 15:00 CP1 opens");
    check(EpTargetPoint(721)  == EP_CP1 &&  EpWindowOpen(EP_CP1, 721), "at 12:01 CP1 still open");
    check(EpTargetPoint(720)  == EP_CP2, "at 12:00 CP1 has gone and CP2 is next");
    check(EpTargetPoint(601)  == EP_CP2 && !EpWindowOpen(EP_CP2, 601), "at 10:01 CP2 is shut");
    check(EpTargetPoint(600)  == EP_CP2 &&  EpWindowOpen(EP_CP2, 600), "at 10:00 CP2 opens");
    check(EpTargetPoint(300)  == EP_CP3, "at 5:00 CP2 has gone");
    check(EpTargetPoint(180)  == EP_CP3 &&  EpWindowOpen(EP_CP3, 180), "at 3:00 CP3 opens");
    check(EpTargetPoint(1)    == EP_CP3 &&  EpWindowOpen(EP_CP3, 1),   "at 0:01 CP3 still open");
    check(!EpWindowOpen(EP_CP3, 0), "at zero nothing is open");

    // ecmall1 is the one site with a strictly-less-than bound, so t == 179 is
    // open there and t == 180 is not, while every other CP3 site takes 180.
    {
        const EstharSite* mall = EpSiteAt("ecmall1", EP_CP3);
        const EstharSite* ow3  = EpSiteAt("ecoway3", EP_CP3);
        check(mall && ow3, "both CP3 sites are in the table");
        if (mall && ow3) {
            check(!EpSiteOpen(mall, 180) && EpSiteOpen(mall, 179),
                  "**ecmall1 uses LT: 180 is shut there, 179 is open**");
            check(EpSiteOpen(ow3, 180), "and ecoway3 takes 180");
        }
    }

    // --- leaving the city, and the run ending ------------------------------
    setField("bgbtl_1", 100);
    clearSaid(); tick();
    setField("ecmview1", 434);
    wrAddr32(EP_TIMER_ADDR, 1150);
    clearSaid(); tick();
    check(saidContains("Lunatic Pandora run"), "Esthar re-greets after leaving and returning");

    wr16(EP_VAR_MISSION, 0);
    clearSaid();
    for (int i = 0; i < 50; i++) tick();
    check(g_said.empty(), "Esthar goes silent the moment the mission word clears");
    wr16(EP_VAR_MISSION, 19);

    // An unreadable clock must produce silence, not a guess.
    wrAddr32(EP_TIMER_ADDR, 999999);
    Disc3::Esthar::Reset();
    clearSaid();
    for (int i = 0; i < 40; i++) tick();
    check(g_said.empty(), "an out-of-range clock says nothing at all");
    wr16(EP_VAR_MISSION, 0);

    // =======================================================================
    // 3. SPACE (#111)
    // =======================================================================
    //
    // v0.63.1. Aaron flew this scene to the end on v0.63.0 -- "Successfully
    // completed the mini-game using manual navigation" -- and asked for two
    // things on the way out: the beep gone, and the Game Controls screen turned
    // into a real pause. Both are asserted below, and the second is asserted
    // against the exact shape of the failure his log recorded rather than
    // against the idea of it.
    auto pressEnter = [&]() {
        g_keyDown |= 4; tick(); g_keyDown &= ~4;
    };

    // -----------------------------------------------------------------------
    // THE WAIT. v0.63.0 asked "is a dialogue open?" on the frame the field
    // loaded -- before Squall had said anything -- decided the scene was quiet,
    // and briefed straight into his first line three seconds later. So the
    // probe reproduces THAT: no dialogue at arrival, dialogue afterwards.
    // -----------------------------------------------------------------------
    setField("ssspace3", SR_FIELD_ID);
    wrAddr32(SR_ADDR_X, 2500); wrAddr32(SR_ADDR_Y, -800);
    wrAddr32(SR_ADDR_FUEL, SR_FUEL_FULL);      // rinoa::default 16-17
    wr8(1034, 4);                              // director1: not boosting
    Disc3::Space::Reset();
    g_clockRunning = false; g_clockHeld = false;
    clearSaid(); g_tones = 0; g_beeps = 0;
    g_dialogOpen = false;
    tick();
    check(g_clockHeld,
          "**the clock is asked to stop on the first frame of the scene** -- the "
          "engine does not detect its own countdown for another two seconds, so "
          "asking later is asking too late");
    check(g_said.empty() && !GardenBattle::BriefDialogOpen(),
          "**an empty first frame is not 'the scene has finished talking'** -- "
          "this is the v0.63.0 bug: it briefed at 16:10:54 and Squall started "
          "at 16:10:57");
    g_clockRunning = true;                       // the engine's countdown appears
    for (int i = 0; i < 3000 / 16; i++) tick();
    check(g_said.empty(), "still waiting three seconds in");
    g_dialogOpen = true;                         // "(Rinoa...... Where are you?)"
    for (int i = 0; i < 12000 / 16; i++) tick();
    check(g_said.empty(),
          "**and it waits out all of Squall's lines** -- twelve seconds of them, "
          "which only costs nothing because the clock is stopped");
    check(GardenBattle::BriefDialogOpen() == false, "the window waits with it");
    g_dialogOpen = false;
    for (int i = 0; i < 2000 / 16; i++) tick();
    check(saidContains("Game controls"), "then it briefs");
    check(saidContains("mission clock is held"),
          "and says the clock is held");
    check(saidContains("but the scene itself is not"),
          "**and does NOT claim the scene stops with it**. Aaron's 2026-08-23 "
          "attempt 1: the clock was held sixty-three seconds and the scene still "
          "ended with forty-seven showing on it -- KILLTIMER at 18:34:33 against "
          "a 60-second boundary announced at 18:34:20. The box has to be DRAWN "
          "and window rendering hangs off field_main, which is exactly why the "
          "Garden battle's RET-over-field_main pause is retired");

    // A scene that never talks at all must not be waited on forever.
    Disc3::Space::Reset();
    g_clockRunning = true; g_clockHeld = false;
    clearSaid();
    g_dialogOpen = false;
    for (int i = 0; i < 3000 / 16; i++) tick();
    check(g_said.empty(), "a silent scene is still given time to open its mouth");
    for (int i = 0; i < 5000 / 16; i++) tick();
    check(saidContains("Game controls"),
          "**but a scene with no dialogue at all briefs after the settle** -- the "
          "wait is for a dialogue that ends, not for one that never starts");

    // ...and a scene that never STOPS talking is capped. Which cap depends on
    // whether the clock actually stopped: waiting is free only if it did.
    Disc3::Space::Reset();
    g_clockRunning = false; g_clockHeld = false;      // the hold did not take
    clearSaid();
    g_dialogOpen = true;
    for (int i = 0; i < 21000 / 16; i++) tick();
    check(g_said.empty(), "an unstopped clock still waits its 22 seconds");
    for (int i = 0; i < 2000 / 16; i++) tick();
    check(saidContains("Game controls"),
          "**and briefs anyway** -- with the clock running, the approach is on a "
          "ninety-second budget and the wait cannot spend all of it");

    Disc3::Space::Reset();
    g_clockRunning = true; g_clockHeld = false;       // the hold took
    clearSaid();
    g_dialogOpen = true;
    for (int i = 0; i < 30000 / 16; i++) tick();
    check(g_said.empty(),
          "**a stopped clock waits longer** -- thirty seconds in and still "
          "listening, because thirty seconds of a stopped clock cost nothing");
    for (int i = 0; i < 16000 / 16; i++) tick();
    check(saidContains("Game controls"), "and it caps at forty-five all the same");
    g_dialogOpen = false;

    // -----------------------------------------------------------------------
    // THE SCREEN.
    // -----------------------------------------------------------------------
    Disc3::Space::Reset();
    g_clockRunning = true; g_clockHeld = false;
    wrAddr32(SR_ADDR_X, 0); wrAddr32(SR_ADDR_Y, 0);
    clearSaid(); g_tones = 0; g_beeps = 0;
    for (int i = 0; i < 7000 / 16; i++) tick();
    check(saidContains("Game controls"), "space opens the Game Controls screen");
    check(saidContains("Reaching Rinoa"), "and names the scene");
    check(saidContains("arrow keys"), "the screen names the arrow keys");
    check(saidContains("diagonal"),  "and tells him diagonals count -- director1 dispatches eight");
    check(saidContains("Enter"),     "and how to start");
    check(!saidContains("beep"),
          "**and nothing in it mentions a beep** -- there is no longer one to "
          "mention, and a brief that describes a cue the player cannot hear is "
          "worse than a brief that leaves it out");

    // v0.63.2, all three of Aaron's corrections, on the screen he actually gets.
    {
        std::string brief;
        for (auto& u : g_said) brief += u.text + " ";
        const std::string screen = Disc3::Space::s_screenText;

        // 1. THIRD PERSON, to match the Garden battle and the dragon fight.
        check(brief.find(" I ") == std::string::npos &&
              brief.find("I call") == std::string::npos &&
              brief.find("I say") == std::string::npos,
              "**the brief never says 'I'** -- Aaron: \"instead let's use "
              "third-person like 'when the mod' so it matches the other game "
              "controls screens\"");
        check(brief.find("the mod calls") != std::string::npos,
              "it says 'the mod calls' instead");

        // 2. THE BOOST, NAMED. Mask 0x0010, resolved through the learner -- the
        //    same one that measured W for it on Aaron's keyboard.
        check(SR_MASK_BOOST == GardenBattle::BTN_PUNCH,
              "**the boost mask is the learner's own slot 0x0010** -- so the key "
              "name comes from measurement rather than from a guess");
        check(screen.find("Boost: hold W") != std::string::npos,
              "**the screen names the boost key** -- W, not the X Aaron expected: "
              "X measured as 0x0040 in his own 2026-08-15 logs");
        check(brief.find("Hold W to boost") != std::string::npos,
              "and the spoken brief names it too");
        check(brief.find("four times the speed") != std::string::npos,
              "**and says four times, not twice** -- var[1034] goes to 8 AND the "
              "key handler multiplies by 2 again");
        check(GardenBattle::g_learnCalls > 0,
              "the learner is running during the scene, so a remap is caught");

        // 3. HOLD, DON'T TAP. BTN_HELD is a level test and the handler loops
        //    while it stays down; a tap moves her once.
        check(screen.find("HOLD an arrow down, don't tap.") != std::string::npos,
              "**the screen says HOLD the arrow, not tap it**");
        check(brief.find("hold the direction the mod calls DOWN") != std::string::npos,
              "and the spoken brief spells out why");
    }
    check(GardenBattle::BriefDialogOpen(),
          "**the game's own window is open** -- not just spoken");
    check(g_clockHeld, "the clock is still held while he reads");
    {
        // A box that runs off the bottom of a 320x224 screen is what v0.20.125
        // had to go back and fix. The Garden battle's six lines measured 108 px,
        // so about 18 px a line and eleven lines is the ceiling; and any line
        // wider than BRIEF_COLS silently becomes two.
        int lines = 1, widest = 0, col = 0;
        for (const char* p2 = Disc3::Space::s_screenText; *p2; ++p2) {
            if (*p2 == '\n') { if (col > widest) widest = col; col = 0; lines++; }
            else col++;
        }
        if (col > widest) widest = col;
        check(lines <= 11, "**the Game Controls screen fits on the screen** (<= 11 lines)");
        check(widest <= GardenBattle::BRIEF_COLS,
              "and no line wraps behind our back (<= BRIEF_COLS)");
    }

    // NOTHING MOVES WHILE HE READS. v0.63.0 pinned nothing: an arrow pressed
    // while the box was up flew the ship, and the box went away by itself after
    // fifteen seconds whether or not anyone had read a word of it.
    wrAddr32(SR_ADDR_X, 4000); wrAddr32(SR_ADDR_Y, 3000);
    clearSaid();
    for (int i = 0; i < 20; i++) tick();
    check(g_said.empty(), "no steering call while the Game Controls screen is up");
    check(rdAddr32(SR_ADDR_X) == 0 && rdAddr32(SR_ADDR_Y) == 0,
          "**and her position is pinned** -- reading the controls is not flying");

    // THE SCREEN DOES NOT TIME OUT. This is the assertion v0.63.0 failed in
    // Aaron's log: "[SPACE] game controls closed (timed out)" at 16:11:09,
    // fifteen seconds after it opened, with Enter never pressed.
    g_tick += 16000; tick();
    check(GardenBattle::BriefDialogOpen(),
          "**still up after sixteen seconds** -- v0.63.0 gave up here");
    clearSaid();
    g_tick += 120000; tick();
    check(GardenBattle::BriefDialogOpen(),
          "**and after two minutes** -- Aaron: \"pauses everything until the "
          "player hits Enter\"");
    check(!g_said.empty(), "and it reminds him what ends it while he waits");
    {
        bool nudged = false;
        for (auto& u : g_said) if (u.text.find("Press Enter") != std::string::npos) nudged = true;
        check(nudged, "the reminder names the key");
        for (auto& u : g_said)
            check(!u.interrupt, "**and never interrupts** -- it must not cut the brief in half");
    }

    // Slash reads the whole thing again, for a player who missed it.
    clearSaid();
    g_keyDown |= 1; tick(); g_keyDown &= ~1;
    check(saidContains("arrow keys"), "slash repeats the controls while the box is up");
    check(GardenBattle::BriefDialogOpen(), "and does not dismiss it");

    // Enter closes it, gives the clock back, and the game starts. Her position
    // is set AFTER the press, because until it lands she is pinned -- the probe
    // wrote 4000 into X a few lines above and the module put it straight back.
    clearSaid();
    pressEnter();
    wrAddr32(SR_ADDR_X, 4000); wrAddr32(SR_ADDR_Y, 0);
    check(!GardenBattle::BriefDialogOpen(), "Enter closes the window");
    check(saidContains("The scene ran on for those"),
          "**and Enter says what the pause actually cost**. It is the only "
          "honest thing left to say: the clock stopped and the approach did not, "
          "so the countdown's own \"one minute remaining\" is now over-reporting "
          "the scene by however long the box was up");
    {
        bool queued = true;
        for (auto& u : g_said)
            if (u.text.find("The scene ran on") != std::string::npos && u.interrupt)
                queued = false;
        check(queued, "and it is queued, not interrupted");
    }
    check(!g_clockHeld,
          "**and gives the clock back** -- a pause that outlives the box would "
          "hand him an approach with no deadline and a scene that never ends");
    check(SpaceRescueActive(),
          "**the catalog is suppressed while he is flying** -- Aaron's 14:54:22 log "
          "has auto-drive setting off toward \"Exit to Outer Space 5\", which is "
          "Rinoa catalogued as a door, in the middle of the attempt");

    // Steering: she is far right, so the call must say RIGHT.
    clearSaid();
    g_tick += 4000; Disc3::Update();
    check(saidContains("right"), "far-right error steers right");
    // ...and the FIRST wide bearing of an attempt points at the boost. Aaron
    // lost 2026-08-23 attempt 1 at 280 units out and still closing, from a
    // start of x=2500 -- 52 seconds of unboosted travel at the measured 48 a
    // second, against a scene the Game Controls screen had already eaten into.
    check(saidContains("Hold W to boost"),
          "**a wide error names the boost, once, when it decides the scene**");
    {
        clearSaid();
        for (int i = 0; i < 20 * 1000 / 16; i++) tick();
        bool again = false;
        for (auto& u : g_said) if (u.text.find("to boost") != std::string::npos) again = true;
        check(!again, "and only once -- it is a nudge, not a nag");
    }
    wrAddr32(SR_ADDR_X, 4000); wrAddr32(SR_ADDR_Y, 0);
    check(!saidContains("left"), "far-right error does not also say left");
    check(!saidContains("up") && !saidContains("down"),
          "and does not call an axis that is already inside the box");

    // THE CADENCE. Aaron: "The TTS should speak frequently throughout the game,
    // with maybe a 3-5 second pause in between." Held still on a wrong key, the
    // v0.62.x module said the same phrase once and then nothing for 53 seconds.
    {
        clearSaid();
        int spoke = 0;
        for (int i = 0; i < 20 * 1000 / 16; i++) { tick(); }   // twenty seconds at 16 ms
        spoke = (int)g_said.size();
        check(spoke >= 5, "**it keeps talking while he holds the wrong key** -- "
                          "at least one call every four seconds across twenty");
        bool sawStill = false;
        for (auto& u : g_said) if (u.text.find("still") != std::string::npos) sawStill = true;
        check(sawStill, "**and says 'still right' when the error has not closed** -- "
                        "the sentence that would have saved Aaron's first attempt");
    }

    // -----------------------------------------------------------------------
    // THE FUEL GAUGE (v0.63.2).
    // -----------------------------------------------------------------------
    // Aaron: "We need to inform the player when their boost is exhausted. I
    // believe a sighted player can tell by the movement but a blind player will
    // need to be explicitly informed."
    {
        wrAddr32(SR_ADDR_X, 3000); wrAddr32(SR_ADDR_Y, 0);
        wrAddr32(SR_ADDR_FUEL, SR_FUEL_FULL);
        clearSaid();
        for (int i = 0; i < 20; i++) tick();
        {
            bool spoke = false;
            for (auto& u : g_said) if (u.text.find("fuel") != std::string::npos ||
                                       u.text.find("Fuel") != std::string::npos) spoke = true;
            check(!spoke, "a full gauge says nothing about fuel");
        }

        wrAddr32(SR_ADDR_FUEL, SR_FUEL_FULL / 2);        // 50%
        clearSaid();
        for (int i = 0; i < 5; i++) tick();
        check(saidContains("Boost fuel half"), "**half is announced**");
        for (auto& u : g_said)
            if (u.text.find("Boost fuel") != std::string::npos)
                check(!u.interrupt,
                      "**and it is queued, not interrupted** -- a bearing is what "
                      "he acts on and must never be cut in half by a fuel report");

        // Once only: the band has to DROP to be news.
        clearSaid();
        for (int i = 0; i < 60; i++) tick();
        check(!saidContains("Boost fuel half"), "and not again at the same band");

        wrAddr32(SR_ADDR_FUEL, SR_FUEL_FULL / 5);        // 20%
        clearSaid();
        for (int i = 0; i < 5; i++) tick();
        check(saidContains("Boost fuel low"), "**low is announced**");

        wrAddr32(SR_ADDR_FUEL, 0);
        clearSaid();
        for (int i = 0; i < 5; i++) tick();
        check(saidContains("Boost fuel gauge empty"),
              "**empty is announced -- and it names the GAUGE**. Nothing in "
              "ssspace1/2/3 reads var[1052] and FF8_EN.exe holds no reference to "
              "its address, so the boost goes on working after the bar bottoms "
              "out. Saying \"boost gone\" would be inventing a rule");

        // THE RETRY. "Rinoa was lost in space...forever" -> Try again ->
        // MAPJUMPO 878, which is ssspace3 again, so Here() never goes false and
        // nothing resets. Aaron's 18:34:47 log caught both halves of that: the
        // gauge reads 0 for a moment while the scene tears down, which v0.63.2
        // announced as "Boost fuel gauge empty" over the Try again prompt --
        // and then latched there, so the refilled 8000 of attempt 2 could never
        // announce anything again. Neither is allowed now.
        wrAddr32(SR_ADDR_FUEL, SR_FUEL_FULL / 2);
        clearSaid();
        for (int i = 0; i < 5; i++) tick();          // resync to half quietly or not
        wrAddr32(SR_ADDR_FUEL, 0);                   // <- the teardown frame
        clearSaid();
        for (int i = 0; i < 5; i++) tick();
        check(!saidContains("empty"),
              "**a gauge that falls three bands between two ticks is a scene "
              "resetting, not a tank draining** -- the bands are 25 points apart "
              "and the gauge falls at most 8 of 8000 per script frame");
        wrAddr32(SR_ADDR_FUEL, SR_FUEL_FULL);        // <- attempt 2 begins
        clearSaid();
        for (int i = 0; i < 5; i++) tick();
        check(g_said.empty() || !saidContains("fuel"), "the refill is silent");
        wrAddr32(SR_ADDR_FUEL, SR_FUEL_FULL / 2);
        clearSaid();
        for (int i = 0; i < 5; i++) tick();
        check(saidContains("Boost fuel half"),
              "**but the tracker followed it back up, so attempt 2 can still be "
              "told about its own fuel** -- v0.63.2 latched at empty and went "
              "silent for the rest of the scene");
        wrAddr32(SR_ADDR_FUEL, SR_FUEL_FULL);
        for (int i = 0; i < 5; i++) tick();

        // A refill (a retry) must not announce its way back up. The band word
        // for a full gauge is the empty string, so "nothing about fuel" is not
        // enough on its own -- speaking an empty utterance IS a bug, and the
        // check has to be able to see it.
        wrAddr32(SR_ADDR_FUEL, SR_FUEL_FULL);
        clearSaid();
        for (int i = 0; i < 60; i++) tick();
        {
            bool spoke = false;
            for (auto& u : g_said) if (u.text.find("fuel") != std::string::npos ||
                                       u.text.find("Fuel") != std::string::npos) spoke = true;
            check(!spoke, "and a gauge that goes back up says nothing at all");
            for (auto& u : g_said)
                check(!u.text.empty(),
                      "**and does not 'announce' the empty string** -- the band "
                      "word for a full tank is \"\", so a rise that reached the "
                      "speaker would be silent to a listener and invisible to a "
                      "test that only greps for the word fuel");
        }

        // Slash reads the boost state and the number, behind the bearing.
        wrAddr32(SR_ADDR_FUEL, (SR_FUEL_FULL * 62) / 100);
        wr8(1034, 8);                                    // the boost is engaged
        clearSaid();
        g_tick += 4000;
        g_keyDown |= 1; tick(); g_keyDown &= ~1;
        check(saidContains("right"), "slash still gives the bearing first");
        check(saidContains("Boost on. Fuel 62 percent."),
              "**and then the boost state and the gauge** -- read off var[1034] "
              "and var[1052], not off the keyboard");
        g_keyDown &= ~1; tick();        // the module edge-detects slash: release it
        wr8(1034, 4);
        clearSaid();
        g_tick += 4000;
        g_keyDown |= 1; tick(); g_keyDown &= ~1;
        check(saidContains("Boost off."), "and says so when it is not engaged");

        // An unreadable gauge is silence, not a report of zero. The state is
        // reset first so the band tracker starts at full -- otherwise a bogus
        // "empty" would be swallowed by the once-only rule and the check would
        // pass for the wrong reason.
        Disc3::Space::Reset();
        g_clockRunning = true;
        wrAddr32(SR_ADDR_X, 3000); wrAddr32(SR_ADDR_Y, 0);
        wrAddr32(SR_ADDR_FUEL, -999999);            // the scene has not started
        clearSaid();
        for (int i = 0; i < 9000 / 16; i++) tick();  // past the settle, through the brief
        clearSaid();                 // BEFORE the press: the first fuel read is on
        pressEnter();                // the very tick that closes the screen
        for (int i = 0; i < 30; i++) tick();
        {
            bool spoke = false;
            for (auto& u : g_said) if (u.text.find("uel") != std::string::npos) spoke = true;
            check(!spoke, "**a gauge outside its own range says nothing** -- the "
                          "same rule the position reading follows, and without it "
                          "the frame before the scene writes 8000 reads as empty");
        }
        wrAddr32(SR_ADDR_FUEL, SR_FUEL_FULL);
    }

    // Far up-left, with the larger error first.
    wrAddr32(SR_ADDR_X, -6000); wrAddr32(SR_ADDR_Y, 1000);
    clearSaid();
    g_tick += 4000; Disc3::Update();
    {
        std::string s2 = lastSaid();
        size_t a = s2.find("left"), w = s2.find("up");
        check(a != std::string::npos && w != std::string::npos, "both axes are called");
        check(a < w, "the larger error is named first");
    }

    // Far down-right, the opposite corner, so a sign slip on either axis shows.
    wrAddr32(SR_ADDR_X, 5000); wrAddr32(SR_ADDR_Y, -6000);
    clearSaid();
    g_tick += 4000; Disc3::Update();
    {
        std::string s2 = lastSaid();
        check(s2.find("down") != std::string::npos, "negative Y calls DOWN");
        check(s2.find("right") != std::string::npos, "positive X calls RIGHT");
        check(s2.find("down") < s2.find("right"), "and the larger error leads");
    }

    // Entering the AIM box SAYS centred and RINGS NOTHING. v0.63.0 rang the
    // Garden battle's two-note cue on this exact transition; it duplicated a
    // sentence the module was already speaking and covered the next one.
    g_tones = 0;
    wrAddr32(SR_ADDR_X, 10); wrAddr32(SR_ADDR_Y, -20);
    clearSaid();
    g_tick += 4000; Disc3::Update();
    check(saidContains("centred"), "the box says centred");
    check(g_tones == 0,
          "**and rings nothing** -- Aaron: \"the TTS announcement I think is "
          "sufficient\"");

    // PARKED ON THE TARGET. Aaron's attempt 2 sat at one position for the last
    // sixty-three seconds of the scene and heard "centred" about fifty times.
    // It must still talk -- silence in a scene with no other feedback reads as
    // a mod that died -- but at a rhythm a person can sit inside.
    {
        wrAddr32(SR_ADDR_X, 10); wrAddr32(SR_ADDR_Y, -20);
        clearSaid();
        for (int i = 0; i < 30 * 1000 / 16; i++) tick();     // thirty seconds, still
        const int spoke = (int)g_said.size();
        check(spoke >= 6,
              "**it still speaks while he holds the target** -- going quiet in a "
              "scene with no other feedback reads as a mod that stopped working");
        check(spoke <= 14,
              "**but not once a second for a minute** -- thirty seconds at the "
              "near cadence would be twenty-five");
        bool sawStill = false;
        for (auto& u : g_said) if (u.text == "still centred") sawStill = true;
        check(sawStill, "and it says 'still centred' after the first, which is the "
                        "idiom the steering calls already use");
        // Keep her moving inside the box and the fast cadence comes straight
        // back: the slow rhythm is for a gap that is not moving, not for the box.
        clearSaid();
        for (int i = 0; i < 6000 / 16; i++) {
            wrAddr32(SR_ADDR_X, 10 + (i & 7));      // never still
            tick();
        }
        check((int)g_said.size() >= 4,
              "**and movement inside the box puts the near cadence back**");
        wrAddr32(SR_ADDR_X, 10);
        for (int i = 0; i < 5; i++) tick();
    }

    // 120 is inside the GAME's box but outside the aim box: it must still steer.
    wrAddr32(SR_ADDR_X, 120);
    clearSaid();
    g_tick += 4000; Disc3::Update();
    check(saidContains("right"), "leaving the aim box steers again");
    check(SrCentred(120, 0) && !SrHeld(120, 0),
          "**120 wins the game but is not 'centred'** -- the steering deadband is "
          "SR_AIM_BOX, the verdict is still the game's SR_WIN_BOX");

    // Out-of-clamp readings are treated as "the scene has not started".
    Disc3::Space::Reset();
    wrAddr32(SR_ADDR_X, 999999); wrAddr32(SR_ADDR_Y, 0);
    clearSaid();
    for (int i = 0; i < 20; i++) tick();
    check(g_said.empty(), "an out-of-range reading says nothing at all");
    check(!g_clockHeld,
          "**and does not stop the clock either** -- a reading the module will "
          "not act on is a scene it has not entered");

    // F9 skip pins BOTH error terms at zero, every tick, against a scene that
    // keeps writing them.
    // ...and it works while the scene is still talking, before the brief has
    // even opened: that is exactly when a player who does not want to fly this
    // reaches for it.
    Disc3::Space::Reset();
    wrAddr32(SR_ADDR_X, 3000); wrAddr32(SR_ADDR_Y, -2500);
    clearSaid();
    g_dialogOpen = true;
    tick();
    check(g_said.empty() && !GardenBattle::BriefDialogOpen(), "still waiting to brief");
    check(g_clockHeld, "with the clock stopped");
    g_keyDown = 2; tick(); g_keyDown = 0;
    g_dialogOpen = false;
    check(saidContains("Skip on"), "F9 announces the skip");
    check(!GardenBattle::BriefDialogOpen(), "and takes the screen down with it");
    check(!g_clockHeld,
          "**and gives the clock back** -- the skip flies the scene, it does not "
          "suspend it");
    check(rdAddr32(SR_ADDR_X) == 0 && rdAddr32(SR_ADDR_Y) == 0, "skip zeroes both axes");
    for (int i = 0; i < 30; i++) {
        wrAddr32(SR_ADDR_X, 2000); wrAddr32(SR_ADDR_Y, 2000);   // the scene fights back
        tick();
        check(rdAddr32(SR_ADDR_X) == 0 && rdAddr32(SR_ADDR_Y) == 0,
              "skip re-zeroes every single tick");
    }
    clearSaid();
    for (int i = 0; i < 30; i++) tick();
    check(g_said.empty(), "the skip stops steering calls");
    check(!SpaceRescueActive(),
          "and the catalog comes back once the skip is on -- there is nothing to "
          "fly any more");

    // Walking out of the field while the clock is held must release it: a hold
    // that outlives its scene freezes the next one.
    Disc3::Space::Reset();
    wrAddr32(SR_ADDR_X, 2000); wrAddr32(SR_ADDR_Y, 0);
    g_dialogOpen = true;
    tick();
    check(g_clockHeld, "held on the way in");
    g_dialogOpen = false;

    // NOT ONE BEEP, ANYWHERE IN THE SCENE. Counted from the top of section 3.
    check(g_beeps == 0,
          "**nothing beeped at any point in the whole approach** -- Aaron: \"Let's "
          "get rid of the beep sound effect. It is extremely distracting\"");

    setField("bgbtl_1", 100); tick();

    // =======================================================================
    // 4. PROPAGATORS (#112)
    // =======================================================================
    check(PgTableConsistent(), "the pair table closes");
    wr8(PG_VAR_DEAD, 0); wr8(PG_VAR_PENDBIT, 0); wr8(PG_VAR_PENDFLAG, 0);
    setField("rgair1", 821);
    clearSaid();
    tick();
    check(saidContains("yellow"), "the airlock Propagator is called yellow");
    {
        std::string s = lastSaid();
        check(s.find("passenger cabin") != std::string::npos,
              "and its partner's location is named");
    }

    // The same field again must not re-announce.
    {
        size_t n = g_said.size();
        for (int i = 0; i < 50; i++) tick();
        check(g_said.size() == n, "no repeat while standing still");
    }

    // Kill the airlock one: the board changes and the mod says what it means.
    const Propagator* air = PgForField("rgair1");
    check(air != nullptr && air->bit == 0x01, "rgair1 holds bit 0x01");
    wr8(PG_VAR_DEAD, 0x01);
    wr8(PG_VAR_PENDBIT, 0x01);
    wr8(PG_VAR_PENDFLAG, PG_PENDING_MASK);
    clearSaid();
    tick();
    check(!g_said.empty(), "a kill announces");
    {
        std::string s;
        for (auto& u : g_said) s += u.text + " | ";
        check(s.find("yellow") != std::string::npos, "the pending kill names its colour");
        check(s.find("passenger cabin") != std::string::npos,
              "and points at the partner that must die next");
    }

    // Walking into the partner's room says "this is the one".
    setField("rgguest2", 828);
    clearSaid();
    tick();
    {
        std::string s;
        for (auto& u : g_said) s += u.text + " | ";
        check(s.find("yellow") != std::string::npos, "the partner room names the colour");
    }

    // Closing the pair clears the pending state.
    wr8(PG_VAR_DEAD, 0x81); wr8(PG_VAR_PENDFLAG, 0); wr8(PG_VAR_PENDBIT, 0);
    clearSaid();
    tick();
    check(!g_said.empty(), "closing a pair announces");

    // Finished.
    wr8(PG_VAR_DEAD, PG_ALL_DEAD);
    clearSaid();
    tick();
    check(!g_said.empty(), "the last pair announces");

    // Off the Ragnarok: silent.
    setField("bgbtl_1", 100);
    clearSaid();
    for (int i = 0; i < 50; i++) tick();
    check(g_said.empty(), "silent off the Ragnarok");

    // =======================================================================
    // 5. THE THREE CANNOT COLLIDE. "/" is shared; only the module whose scene
    //    is live may answer it.
    // =======================================================================
    setField("rgair1", 821);
    wr8(PG_VAR_DEAD, 0); wr8(PG_VAR_PENDBIT, 0); wr8(PG_VAR_PENDFLAG, 0);
    wr8(EP_VAR_MISSION, 19);                   // Esthar's byte set but not in Esthar
    wrAddr32(SR_ADDR_X, 0); wrAddr32(SR_ADDR_Y, 0);
    clearSaid();
    tick();
    g_keyDown = 1; tick(); g_keyDown = 0; tick();
    {
        std::string s;
        for (auto& u : g_said) s += u.text + " | ";
        check(s.find("Contact point") == std::string::npos,
              "Esthar stays quiet aboard the Ragnarok even with its mission byte set");
        check(s.find("Rinoa") == std::string::npos, "space stays quiet aboard the Ragnarok");
    }

    // =======================================================================
    // 5b. DETECTION POLICY. The field ids for all three scenes are DERIVED, not
    //     observed, so each module's choice of id-vs-name is load-bearing and
    //     is tested here rather than trusted.
    // =======================================================================
    Disc3::Esthar::Reset(); Disc3::Props::Reset(); Disc3::Space::Reset();
    wr16(EP_VAR_MISSION, 19);
    wr8(PG_VAR_DEAD, 0); wr8(PG_VAR_PENDBIT, 0); wr8(PG_VAR_PENDFLAG, 0);
    wrAddr32(EP_TIMER_ADDR, 800);

    // An id that lands inside a derived range but a name that is NOT one of
    // the scene's fields: both the Esthar and Propagator modules must stay
    // silent. If the derivation is wrong this is the case that happens, and
    // the cost of getting it wrong is chatter in an unrelated scene forever.
    setField("dosea1", 830);              // inside the derived rg range
    clearSaid();
    for (int i = 0; i < 40; i++) tick();
    // ...and it must STAY silent while those variables move underneath it.
    // var[445..447] are ordinary field variables and belong to whatever scene
    // is running; a foreign field writing them is the normal case, not a freak
    // one. Without this half the test passes on an id-keyed build too, because
    // the announcements happen to be gated on PgForField() finding a match.
    for (uint8_t d = 1; d; d = (uint8_t)(d << 1)) {
        wr8(PG_VAR_DEAD, d);
        wr8(PG_VAR_PENDBIT, (uint8_t)(d << 1));
        wr8(PG_VAR_PENDFLAG, (uint8_t)((d & 1) ? PG_PENDING_MASK : 0));
        for (int i = 0; i < 4; i++) tick();
    }
    g_keyDown = 1; tick(); g_keyDown = 0; tick();
    check(g_said.empty(), "an rg-range id with a foreign name says nothing, "
                          "even while var[445..447] churn and slash is pressed");
    wr8(PG_VAR_DEAD, 0); wr8(PG_VAR_PENDBIT, 0); wr8(PG_VAR_PENDFLAG, 0);

    setField("dosea1", 430);              // an id in the old derived ec range
    clearSaid();
    for (int i = 0; i < 40; i++) tick();
    check(g_said.empty(), "an ec-range id with a foreign name says nothing");

    // The mirror case: the right NAME with an id nowhere near the derived
    // range. The feature must still work -- that is the whole point of keying
    // on the name -- and it must log that the derivation is wrong.
    Disc3::Props::Reset();
    g_logged.clear();
    setField("rgair1", 60000);
    clearSaid();
    tick();
    check(saidContains("yellow"), "the right name works even when the derived id is wrong");
    {
        bool warned = false;
        for (auto& l : g_logged) if (l.find("OUTSIDE the derived") != std::string::npos) warned = true;
        check(warned, "and a wrong derived id is logged so one BAT settles it");
    }

    // Space is the exception: it keys on id OR name, because the skip and the
    // steering cannot wait out pCurrentFieldName's 2-5 second lag. With a stale
    // name and the right id it must still run.
    Disc3::Space::Reset();
    setField("ssspace2", SR_FIELD_ID);     // name still lagging on the previous field
    wrAddr32(SR_ADDR_X, 0); wrAddr32(SR_ADDR_Y, 0);
    clearSaid();
    g_dialogOpen = false;
    for (int i = 0; i < 8000 / 16; i++) tick();   // past the settle: the brief opens
    check(saidContains("Reaching Rinoa"), "space runs on the id alone while the name lags");

    // ...and on the name alone if the id turns out to be derived wrong.
    Disc3::Space::Reset();
    setField("ssspace3", 60000);
    clearSaid();
    for (int i = 0; i < 8000 / 16; i++) tick();
    check(saidContains("Reaching Rinoa"), "space also runs on the name alone");

    setField("bgbtl_1", 100);
    Disc3::Esthar::Reset(); Disc3::Props::Reset(); Disc3::Space::Reset();
    wr8(EP_VAR_MISSION, 0);
    clearSaid();
    for (int i = 0; i < 20; i++) tick();
    check(g_said.empty(), "and everything is quiet again afterwards");

    // =======================================================================
    // 6. NOTHING EVER SPOKE A PLACEHOLDER.
    // =======================================================================
    recordAll();
    for (auto& t : g_allSaid)
        if (t.find('?') != std::string::npos) {
            std::printf("  BAD: an utterance contained '?': \"%s\"\n", t.c_str());
            bad++;
        }
    check(!g_allSaid.empty(), "the probe actually collected utterances");

    std::printf("%s -- %d bad\n", bad ? "FAIL" : "OK", bad);
    return bad ? 1 : 0;
}
