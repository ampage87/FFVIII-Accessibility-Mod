// bahamut_light_overlay.cpp -- the Deep Sea Research Center blue-light puzzle
// (#bahamut-light). See bahamut_light_overlay.h for the design notes and
// bahamut_light_model.inl for the script transcript everything here rests on.
//
// v0.100.0: the prompt no longer goes through DialogInject. It borrowed window
// slot 2, which is the slot Bahamut's entire scene speaks through, and left it
// stuck open. The model file carries the log lines that prove it.
//
// <windows.h> MUST come before ff8_addresses.h: that header declares accessors
// returning Windows types without pulling windows.h in itself, so it relies on
// the includer having defined it first.
#include <windows.h>
#include <cstdint>
#include <cstdio>
#include <cstring>

#include "bahamut_light_overlay.h"
#include "ff8_accessibility.h"
#include "ff8_addresses.h"
#include "mod_forward_decls.h"

#include "bahamut_light_model.inl"

namespace BahamutLightOverlay {

using namespace BahamutLightModel;

// ============================================================================
// Constants
// ============================================================================

// The fallback arming delay, for a player who reaches a Hojo safe pocket before
// the first pulse and so never gives us a var[1024] edge to trigger on.
static const DWORD SETTLE_MS = 6000;

// The two answer keys. Deliberately NOT directional: `battlekun1`/`battlekun4`
// throw a random encounter for a held direction while the light is armed, and
// the v0.98.0 ASK -- whose cursor IS the arrow keys -- walked Aaron straight
// into one at 00:19:29. G and S are free in field mode; the keys the mod and
// the game already claim there are the arrows, `-`, `+`, `\`, Backspace, Space
// and the function keys (field_nav_handlekeys.inl).
static const int KEY_GUIDE = 'G';
static const int KEY_SKIP  = 'S';

static const char* const PROMPT_TEXT =
    "Blue light puzzle. Press G to be guided, or S to skip the puzzle.";

// ============================================================================
// State
// ============================================================================
static bool   s_initialized   = false;
static bool   s_inField       = false;
static DWORD  s_enteredMs     = 0;
static bool   s_pulseSeen     = false;   // var[1024] observed at 1 this visit
static int    s_mode          = (int)BL_MODE_NONE;
static int    s_promptCount   = 0;
static bool   s_promptSpoken  = false;
static DWORD  s_promptAtMs    = 0;
static int    s_prevCue       = (int)BL_CUE_NONE;
static DWORD  s_cueSinceMs    = 0;       // when the current cue began
static bool   s_spokeLast     = false;   // the last speech on the wire was ours
static DWORD  s_spokeAtMs     = 0;
static bool   s_skipAnnounced = false;
static bool   s_keyLatched    = false;   // an answer key is still held

// ============================================================================
// Guarded memory access. No C++ objects in any function that uses __try
// (MSVC C2712); see tests/lint_seh.py.
// ============================================================================
static bool ReadVarB(int index, int* out)
{
    __try {
        *out = (int)(*(volatile const unsigned char*)
                     (uintptr_t)(BL_VAR_BASE + (unsigned)index));
        return true;
    } __except (EXCEPTION_EXECUTE_HANDLER) {
        return false;
    }
}

static bool WriteVarB(int index, unsigned char v)
{
    __try {
        *(volatile unsigned char*)(uintptr_t)(BL_VAR_BASE + (unsigned)index) = v;
        return true;
    } __except (EXCEPTION_EXECUTE_HANDLER) {
        return false;
    }
}

// ============================================================================
// Field identity
// ============================================================================
//
// THE ID IS THE AUTHORITY AND THE NAME IS ONLY EVER A LOG LINE.
// `pCurrentFieldName` lags the id by seconds -- the v0.99.0 BAT caught it
// mid-lag, logging `id=846 name='sdisle1'` on entry and `pCurrentFieldName =
// 'sdcore1'` thirty seconds later -- so a module that writes memory must key on
// the id or it will go on writing several seconds into the NEXT field, where
// 0x01CFEDBC means something else entirely.
//
// 846 is not a derived id. sdcore2's own `Director::default` opens with
// `PSHM_W var[84] ; PSHN_L 846 ; ==` -- the game asking "did the party arrive
// from sdcore1?" -- so the number is the script's, not a table's. The 2026-08-26
// log confirmed it live: `pCurrentFieldId = 0x01CD2FC0 (val=846)` alongside
// `pCurrentFieldName = 'sdcore1'`.
static bool FieldIsPuzzle()
{
    if (FF8Addresses::pCurrentFieldId) {
        return (unsigned)(*FF8Addresses::pCurrentFieldId) == BL_FIELD_ID;
    }
    const char* fn = FF8Addresses::pCurrentFieldName;
    return fn && _stricmp(fn, BL_FIELD) == 0;
}

// ============================================================================
// Speech
// ============================================================================
static void SayCue(const char* text)
{
    const DWORD now = GetTickCount();
    const bool busy = ScreenReader::IsSpeaking();
    const BlSpeakAct act = BlSpeakDecision(busy, s_spokeLast,
                                           (unsigned)(now - s_spokeAtMs),
                                           BL_OWN_MS);
    if (act == BL_SPEAK_DROP) {
        // Deliberately silent: a queued cue arrives after the window it was
        // describing has closed, and the next edge is at most a few seconds away.
        Log::Field("BahamutLight: cue '%s' DROPPED -- something else is speaking", text);
        s_spokeLast = false;
        return;
    }
    ScreenReader::Speak(text, act == BL_SPEAK_INTERRUPT);
    s_spokeLast = true;
    s_spokeAtMs = now;
}

static void CommitMode(BlMode mode)
{
    s_mode          = (int)mode;
    s_skipAnnounced = false;
    // Force the next reading to look like an edge so the player is told where
    // they stand immediately rather than waiting out the current phase.
    s_prevCue = (int)BL_CUE_NONE;

    if (mode == BL_MODE_SKIP) {
        ScreenReader::Speak("Light puzzle off. Walk to the light.", true);
        Log::Field("BahamutLight: SKIP chosen (holding var[%d]=1, var[%d]=0)",
                   BL_VAR_SAFE, BL_VAR_LIGHT);
    } else {
        ScreenReader::Speak("Guiding you. Move on Go, stand still on Stop.", true);
        Log::Field("BahamutLight: GUIDE chosen");
    }
    s_spokeLast = true;
    s_spokeAtMs = GetTickCount();
}

// ============================================================================
// Per-visit state
// ============================================================================
static void EnterField()
{
    s_inField       = true;
    s_enteredMs     = GetTickCount();
    s_pulseSeen     = false;
    s_mode          = (int)BL_MODE_NONE;
    s_promptCount   = 0;
    s_promptSpoken  = false;
    s_promptAtMs    = s_enteredMs;
    s_prevCue       = (int)BL_CUE_NONE;
    s_cueSinceMs    = s_enteredMs;
    s_spokeLast     = false;
    s_skipAnnounced = false;
    s_keyLatched    = false;
    Log::Field("BahamutLight: entered the puzzle field (id %u)", BL_FIELD_ID);
}

static void LeaveField()
{
    if (!s_inField) return;
    s_inField = false;
    s_mode    = (int)BL_MODE_NONE;
    s_prevCue = (int)BL_CUE_NONE;
    Log::Field("BahamutLight: left the puzzle field; state reset");
}

// ============================================================================
// Public API
// ============================================================================
void Initialize()
{
    if (s_initialized) return;
    s_initialized = true;
    s_inField     = false;
    s_mode        = (int)BL_MODE_NONE;
    s_prevCue     = (int)BL_CUE_NONE;
    Log::Mod("BahamutLightOverlay: Initialized.");
}

void Shutdown()
{
    if (!s_initialized) return;
    LeaveField();
    s_initialized = false;
}

bool IsPromptPending()
{
    return s_initialized && s_inField && s_mode == (int)BL_MODE_NONE;
}

void Update()
{
    if (!s_initialized) return;

    const bool here = FieldIsPuzzle();
    if (here != s_inField) {
        if (here) EnterField(); else LeaveField();
    }
    if (!here) return;

    const DWORD now = GetTickCount();

    // ---- the two bytes -----------------------------------------------------
    int light = 0, safe = 0, story = 0;
    const bool okL = ReadVarB(BL_VAR_LIGHT, &light);
    const bool okS = ReadVarB(BL_VAR_SAFE,  &safe);
    const bool okC = ReadVarB(BL_VAR_STORY, &story);
    const bool readOk = okL && okS;

    if (readOk && light == 1) s_pulseSeen = true;

    const bool answered = (s_mode != (int)BL_MODE_NONE);

    // ---- the prompt --------------------------------------------------------
    if (!answered) {
        // Hold the light disarmed while the player is listening to a question
        // the mod asked. The v0.98.0 ASK let a pulse arm underneath it and the
        // player was pulled into a random encounter mid-prompt.
        if (BlHoldSafeWhilePrompting(true, false) && readOk &&
            BlSkipWriteNeeded(light, safe)) {
            WriteVarB(BL_VAR_SAFE,  1);
            WriteVarB(BL_VAR_LIGHT, 0);
        }

        const bool armed = BlPromptArmed(true, false, s_pulseSeen,
                                         okC && story != 1,
                                         (unsigned)(now - s_enteredMs),
                                         (unsigned)SETTLE_MS);
        if (BlPromptDue(armed, s_promptCount, BL_PROMPT_MAX, s_promptSpoken,
                        (unsigned)(now - s_promptAtMs), BL_PROMPT_REPEAT_MS)) {
            s_promptSpoken = true;
            s_promptAtMs   = now;
            s_promptCount++;
            ScreenReader::Speak(PROMPT_TEXT, true);
            s_spokeLast = true;
            s_spokeAtMs = now;
            Log::Field("BahamutLight: prompt %d of %d (pulseSeen=%d story=%d)",
                       s_promptCount, BL_PROMPT_MAX, (int)s_pulseSeen, story);
        }

        const bool gk = (GetAsyncKeyState(KEY_GUIDE) & 0x8000) != 0;
        const bool sk = (GetAsyncKeyState(KEY_SKIP)  & 0x8000) != 0;
        const BlMode pick = BlKeyChoice(gk, sk);
        if (pick != BL_MODE_NONE && !s_keyLatched) {
            s_keyLatched = true;
            CommitMode(pick);
            return;
        }
        if (!gk && !sk) s_keyLatched = false;

        // Out of repeats and still no answer: guide, which changes nothing.
        if (s_promptSpoken && s_promptCount >= BL_PROMPT_MAX &&
            (unsigned)(now - s_promptAtMs) >= BL_PROMPT_REPEAT_MS) {
            Log::Field("BahamutLight: no answer after %d prompts -- defaulting to guide",
                       s_promptCount);
            CommitMode(BlModeOnTimeout());
        }
        return;
    }

    // ---- skip: hold the game's own disarm pair -----------------------------
    if (s_mode == (int)BL_MODE_SKIP) {
        if (readOk && BlSkipWriteNeeded(light, safe)) {
            const bool a = WriteVarB(BL_VAR_SAFE,  1);
            const bool b = WriteVarB(BL_VAR_LIGHT, 0);
            if (!a || !b) {
                Log::Field("BahamutLight: SKIP hold write FAILED -- disengaging");
                s_mode = (int)BL_MODE_GUIDE;
            } else if (!s_skipAnnounced) {
                s_skipAnnounced = true;
                Log::Field("BahamutLight: SKIP engaged -- var[%d] 1, var[%d] 0",
                           BL_VAR_SAFE, BL_VAR_LIGHT);
            }
        }
        return;
    }

    // ---- guide: speak the edges -------------------------------------------
    const BlCue cue = BlCueFor(readOk, light, safe);
    if (!BlCueChanged((BlCue)s_prevCue, cue)) return;

    // Both phases measured. The v0.99.0 BAT confirmed the frame rate the script
    // runs at: armed held 5,297 ms against 158 script frames, and safe 1,703 and
    // 1,734 ms against 35-60 -- so the field script ticks at 30 Hz and the safe
    // window really is between 1.2 and 2.0 seconds.
    const unsigned heldMs = (unsigned)(now - s_cueSinceMs);
    Log::Field("BahamutLight: %s  (previous phase %s held %u ms; "
               "script says armed %d frames, safe %d/%d/%d)",
               BlCueText(cue),
               BlCueText((BlCue)s_prevCue),
               heldMs,
               BlArmedFrames(),
               BlSafeFrames(BL_F_TAIL_LO),
               BlSafeFrames(BL_F_TAIL_MID),
               BlSafeFrames(BL_F_TAIL_HI));

    s_prevCue    = (int)cue;
    s_cueSinceMs = now;
    SayCue(BlCueText(cue));
}

}  // namespace BahamutLightOverlay
