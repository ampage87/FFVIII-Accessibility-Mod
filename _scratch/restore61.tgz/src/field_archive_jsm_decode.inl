// field_archive_jsm_decode.inl -- the field script VM's instruction encoding.
// Included from field_archive_jsm.inl before the scanner. Do not compile alone.
//
// All of this is read out of FF8_EN.exe rather than assumed:
//
//   DECODER  0x00530760
//       w = code[ip]
//       if ((w & 0xFF000000) == 0)  opcode = w          ; NO parameter
//       else                        opcode = w >> 24    ; param = sign_extend24(w)
//   DISPATCH 0x0052A647   call opcodeTable[opcode]   ; table at 0x00B8DE94
//
//   So a word whose high byte is zero is an OPCODE, and that is how every opcode
//   above 0xFF is encoded: MENUSAVE 0x12E, ADDITEM 0x125, DRAWPOINT 0x137,
//   CARDGAME 0x13A, SETDRAWPOINT 0x155. Reading those words as literal pushes is
//   what forced the old "0x1C is a prefix that pops the real opcode off the
//   stack" theory; opcode 0x1C is in fact `mov eax,1; ret` (0x0051D710).
//
//   PUSH OPCODES, from walking every handler in the table and counting writes to
//   the VM stack pointer at [ctx+0x184]:
//       0x07 PSHN_L 0x0051C990   pushes the INLINE PARAM        -- a literal
//       0x13        0x0051CD30   pushes the INLINE PARAM        -- a literal
//       0x08 PSHL   0x0051CAB0   pushes local [ctx + n*4 + 0x140]
//       0x0A PSHM_B 0x0051CAF0 | 0x0C PSHM_W | 0x0E PSHM_L   field var bank
//                                             (0x01CFE9B8 + param)
//       0x10 0x11 0x12           push; value not statically knowable
//       0x04 CALL   0x0051C530   pushes the return IP     -- never an argument
//       0x05        0x0051C570   pushes all EIGHT locals  -- never an argument
//
//   POP-TO-VARIABLE-BANK: 0x0B POPM_B (0x0051CCA0), 0x0D POPM_W (0x0051CCD0),
//   0x0F POPM_L (0x0051CD00) -- each stores at [param + 0x01CFE9B8].
//
// Arguments are the contiguous run of push opcodes immediately preceding the
// consumer, deepest first. That is the shape the compiler emits and it cannot
// drift, unlike a stack simulated across a whole method.

struct JsmInsn {
    uint16_t opcode;   // 0x0000-0x01FF, or 0xFFFF for a word outside the table
    int32_t  param;    // sign-extended 24-bit; 0 for a bare word
    bool     bare;     // true when the high byte was zero (opcode, no parameter)
};

static inline JsmInsn JsmDecodeWord(uint32_t w)
{
    JsmInsn ins;
    if ((w & 0xFF000000u) == 0) {
        ins.opcode = (w < 0x200u) ? (uint16_t)w : (uint16_t)0xFFFF;
        ins.param  = 0;
        ins.bare   = true;
    } else {
        ins.opcode = (uint16_t)(w >> 24);
        int32_t p  = (int32_t)(w & 0x00FFFFFFu);
        if (w & 0x00800000u) p |= (int32_t)0xFF000000;
        ins.param  = p;
        ins.bare   = false;
    }
    return ins;
}

// A push whose value is an ARGUMENT to the next consuming opcode.
static inline bool JsmIsArgPush(const JsmInsn& i)
{
    if (i.bare) return false;
    switch (i.opcode) {
        case 0x07: case 0x13:                            // literal
        case 0x08:                                       // local
        case 0x0A: case 0x0C: case 0x0E:                 // field variable bank
        case 0x10: case 0x11: case 0x12:                 // computed
            return true;
        default: return false;
    }
}

// Of the argument pushes, the two that carry a value we can read statically.
static inline bool JsmIsLiteralPush(const JsmInsn& i)
{
    return !i.bare && (i.opcode == 0x07 || i.opcode == 0x13);
}

// Pushes that are not arguments: CALL's return address and the prologue's
// eight saved locals. They end the current argument run.
static inline bool JsmIsNonArgPush(const JsmInsn& i)
{
    return !i.bare && (i.opcode == 0x04 || i.opcode == 0x05);
}

// Writes the popped value into the field variable bank at 0x01CFE9B8 + param.
static inline bool JsmIsVarBankPop(const JsmInsn& i)
{
    return !i.bare && (i.opcode == 0x0B || i.opcode == 0x0D || i.opcode == 0x0F);
}

// The marker a non-literal argument carries, so "only known at runtime" reads
// the same everywhere it is tested. Literal pushes never set bit 31: a literal
// is at most a sign-extended 24-bit value and a negative one has bits 16-30 set,
// which is why the test is the full 0xFFFF0000 mask and not just bit 31.
static inline int32_t JsmRuntimeMarker(int32_t addr)
{
    return (int32_t)(0x80000000u | (uint32_t)(addr & 0xFFFF));
}
static inline bool JsmIsRuntimeMarker(int32_t v)
{
    return ((uint32_t)v & 0xFFFF0000u) == 0x80000000u;
}
