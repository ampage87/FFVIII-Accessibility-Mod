// tests/winshim/windows.h -- just enough of the Win32 surface for a HOST SYNTAX
// CHECK of the Win32-only translation units. Never linked, never run: the point
// is that a change to field_archive.cpp (which cannot be compiled on the build
// host otherwise) is still parsed and type-checked by the gate.
#pragma once
#include <cstdint>
#include <cstddef>
#include <cstdio>
#include <cstring>
typedef unsigned long  DWORD;
typedef int            BOOL;
typedef unsigned char  BYTE;
typedef unsigned short WORD;
typedef void*          HANDLE;
typedef void*          HMODULE;
typedef void*          HWND;
typedef const char*    LPCSTR;
typedef char*          LPSTR;
typedef long           LONG;
typedef unsigned int   UINT;
typedef intptr_t       LPARAM;
typedef uintptr_t      WPARAM;
#define WINAPI
#define __cdecl
#define TRUE  1
#define FALSE 0
#define MAX_PATH 260
#define INVALID_HANDLE_VALUE ((HANDLE)(intptr_t)-1)
#define EXCEPTION_EXECUTE_HANDLER 1
// libstdc++ already defines __try (bits/exception_defines.h) but NOT __except,
// so these have to be guarded separately -- a single #ifndef __try around both
// silently leaves __except undefined the moment <string> or <vector> is included.
#ifndef __try
#define __try    try
#endif
#ifndef __except
#define __except(x) catch (...)
#endif
inline DWORD  GetTickCount() { return 0; }
inline DWORD  GetLastError() { return 0; }
inline void   Sleep(DWORD) {}
inline HMODULE GetModuleHandleA(LPCSTR) { return nullptr; }
inline int    _stricmp(const char* a, const char* b) { return strcasecmp(a, b); }
inline int    _strnicmp(const char* a, const char* b, size_t n) { return strncasecmp(a, b, n); }
#include <cmath>
inline DWORD GetModuleFileNameA(HMODULE, LPSTR buf, DWORD n) { if (n) buf[0] = '\0'; return 0; }
