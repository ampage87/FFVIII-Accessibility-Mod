// entity_classifications.h - Auto-generated entity classification tables
// Generated from field_entity_survey.json by generate_classifications.py
// DO NOT EDIT MANUALLY - regenerate from survey data instead.
//
// Coverage: 900 fields, 13590 total entities, 2985 unique SYM names

#pragma once

// ============================================================================
// Controller/effect entities to hide from the navigation catalog.
// These are invisible script controllers, lighting, camera, effects, etc.
// 213 entries.
// ============================================================================
static const char* ENTITY_SKIP_NAMES[] = {
    "a_light1",
    "a_light2",
    "alight",
    "arrowlight",
    "backlight",
    "battleyarou",
    "bedlight",
    "BGanimekun",
    "biglight",
    "black",
    "blacklight",
    "blindlight",
    "bluelaser",
    "bluelight",
    "bokeie",
    "buttonlight",
    "c_light",
    "camera",
    "camera1",
    "camera2",
    "candlelight",
    "clocklight",
    "contlight",
    "cork",
    "cornerlight",
    "counterlight",
    "curtain",
    "cut",
    "d_light",
    "desklight",
    "desklight1",
    "desklight2",
    "Director",
    "director0",
    "director1",
    "director2",
    "director3",
    "disp2light",
    "disp3light",
    "displight",
    "door01",
    "doorcont",
    "doorlight",
    "downlight",
    "e_light",
    "elefog",
    "elelight",
    "emergencylight",
    "enzetu",
    "eventline0",
    "eventline1",
    "floorlight",
    "floorlightcont",
    "fog",
    "fog1",
    "fog2",
    "footlight",
    "gardenlight",
    "gatelight",
    "glass",
    "greenlight",
    "h_light",
    "hamon1",
    "hamon2",
    "hamon3",
    "hansha",
    "hantei",
    "harplight1",
    "harplight2",
    "headlight",
    "heallight",
    "Henka",
    "hotellight",
    "infolight",
    "Jokantoku",
    "JumpTimer",
    "kabelight",
    "kage",
    // v0.20.15: Caraway's Mansion glass-puzzle CONTROLLER -- REQ-dispatches to a
    // dozen entities (like director1) and was surfacing as a phantom 'Object'
    // co-located with the 'cup' Glass. 'kakusi' = "hidden": never player-facing.
    "kakusi",
    "kanbanlight",
    "KANTOKU",
    "kantoku",
    "Kantoku",
    "kantoku_suketto",
    "Keyjokantoku",
    "Keykantoku",
    "l_doorlight",
    "laser",
    "leftred",
    "lens",
    "light",
    "light0",
    "light1",
    "light10",
    "light11",
    "light12",
    "light13",
    "light2",
    "light23",
    "light3",
    "light4",
    "light5",
    "light6",
    "light7",
    "light8",
    "light9",
    "light_d",
    "light_k",
    "light_r",
    "light_s",
    "lightfog",
    "lightning",
    "llight",
    "lowerlight",
    "map1scroll",
    "map2scroll",
    "map3scroll",
    "Mawaruu",
    "Mawaruu2",
    "movelight",
    "mugi",
    "Musickantoku",
    "Musickantoku2",
    "neonlight",
    "noise",
    "orangelight",
    "orangelight1",
    "orangelight2",
    "orangelight3",
    "Partikuru",
    "petlight",
    "pillarlight",
    "plane",
    "plane1",
    "platelight",
    "publight",
    "r_doorlight",
    "raillight",
    "rain",
    "redlaser",
    "redlight",
    "redlight1",
    "redlight2",
    "redlight3",
    "redlight4",
    "redlight5",
    "redspell1",
    "redspell2",
    "redspell3",
    "redspell4",
    "redspell5",
    "rightred",
    "rlight",
    "roomlight",
    "s_light",
    "saveline0",
    "screen",
    "Scroll",
    "scrollcont",
    "Scrollkun",
    "ScrollLine",
    "seiferout",
    "Seigyo",
    "seigyo",
    "Shake",
    "shoplight",
    "sidelight",
    "smalllight",
    "sounddir0",
    "spellcont",
    "stairlight",
    "stairslight",
    "standlight",
    "steam",
    "steplight",
    "steplight1",
    "steplight2",
    "stl0",
    "stl1",
    "stoplight",
    "stoplight1",
    "stoplight2",
    "stopperlight",
    "Timer",
    "timer0",
    "timerdir0",
    "TimerJump",
    "timerkun",
    "toplight",
    "Trainscroll",
    "trap",
    "tunnellight",
    "tvlens",
    "tvlight",
    "uplight",
    "upperlight",
    "upperlight1",
    "upperlight2",
    "upperlight3",
    "upperlight4",
    "Urakata",
    "view",
    "walllight",
    "water",
    "waterlight",
    "whitelight",
    "wind",
    "witchin",
    "witchout",
    "woodlight",
    "wpnlight",
    "yellowlaser",
    "yellowlight",
    "zo",
    nullptr
};

// ============================================================================
// SYM name -> friendly display name for TTS.
// 148 entries.
// ============================================================================
struct EntityDisplayName {
    const char* sym;
    const char* display;
};

static const EntityDisplayName ENTITY_DISPLAY_NAMES[] = {
    { "adplate", "Sign" },
    { "Agittrain", "Train" },
    { "Anaun", "Announcer" },
    { "betunikun", "Student" },
    { "BGMonorail", "Monorail" },
    { "book", "Book" },
    { "Boy1", "Boy" },
    { "Boy2", "Boy" },
    { "cameraman", "Cameraman" },
    { "cardgamemaster", "Card Player" },
    { "cardgamemaster2", "Card Player" },
    { "Cardtanto", "Card Player" },
    { "Cat1", "Cat" },
    { "Cat2", "Cat" },
    { "celone", "Ellone" },
    { "cid", "Headmaster Cid" },
    // v0.18.3.267: Caraway's Mansion wine-glass puzzle (glfurin1/glfurin3).
    // 'cup' is the wine glass Quistis takes from the shelf and places in the
    // statue's hands to open the secret passage.
    { "cup", "Glass" },
    { "Daitouryo", "President" },
    { "dic", "Directory" },
    { "igyous1", "Directory" },  // v0.12.16: paired dialog entity for dic
    { "door", "Door" },
    { "door1", "Door" },
    { "door2", "Door" },
    { "dp01", "Draw Point" },
    { "dragon", "Dragon" },
    { "DrawPoint", "Draw Point" },
    { "DrawPointSampleCode", "Draw Point" },
    { "drpoint", "Draw Point" },
    { "Edea", "Edea" },
    { "edea", "Edea" },
    { "edea0", "Edea" },
    { "edea1", "Edea" },
    { "edea2", "Edea" },
    { "edea3", "Edea" },
    { "edea4", "Edea" },
    { "elone", "Ellone" },
    // v0.62.3 (#123): Piet is the Lunar Base technician you speak to on sscont1,
    // sscont2, sspod2 and eapod1 -- four fields, one person, announced as "NPC"
    // in the escape pod where he is one of three people in the room. `handle` is
    // the pod's release lever (sspod2/sspod3) and the Missile Base valve wheel
    // (bgmd1_4/gfcar1): it carries a model, so the catalog types it NPC, and a
    // lever announced as a person is a person the player goes looking for.
    { "piet", "Piet" },
    { "handle", "Handle" },
    { "evl1", "Elevator" },
    { "Fish", "Fish" },
    { "Fish2", "Fish" },
    { "G_Army", "Galbadian Soldier" },
    { "G_Army01", "Galbadian Soldier" },
    { "G_Army02", "Galbadian Soldier" },
    { "GalbadiaArmy01", "Galbadian Soldier" },
    { "GalbadiaSS", "Galbadian Soldier" },
    { "GalHei3", "Galbadian Soldier" },
    { "GalHei4", "Galbadian Soldier" },
    { "GalQuistis", "Quistis" },
    { "GalRinoa", "Rinoa" },
    { "GalZell", "Zell" },
    { "gate0", "Gate" },
    { "gate1", "Gate" },
    { "Girl", "Girl" },
    { "Girl2", "Girl" },
    { "hasigomodel", "Ladder" },
    { "hoteldoor", "Door" },
    { "info", "Information" },
    { "Irvine", "Irvine" },
    { "irvine", "Irvine" },
    { "kadowaki", "Dr. Kadowaki" },
    { "Kani", "Crab" },
    { "kero", "Frog" },
    { "Kiros", "Kiros" },
    { "kiros", "Kiros" },
    { "knob", "Knob" },
    { "ladder", "Ladder" },
    // v0.18.3.290 (#85): the v0.18.3.288 'ladline0'-'ladline7' -> "Ladder"
    // mappings were REMOVED here. They were added purely because the SYM name
    // reads like "ladder", which directly violates this project's standing rule
    // that SYM names are unreliable identity hints (see DEVNOTES.md; 'kanban2'
    // was Xu). That guess was wrong and actively harmful: glwater3's 'ladline7'
    // is the gate the player must open to proceed -- it sits ~1 step from where
    // Aaron stood facing that gate (its tri-83 centroid (-287,815) vs his
    // (-238,706)), it is the ONLY catalog entry anywhere near it, Aaron
    // independently reported this entry's coords put him "right in front of the
    // gate to sewer 2", and its script dispatches REQs like the 'saku' gates
    // rather than doing anything ladder-like. Labeling it "Ladder" is what made
    // the real gate look absent from the catalog for three BAT cycles.
    // 'ladline5'/'ladline6' are likewise unconfirmed -- with no behavioral
    // evidence for what they are, they now fall through to the generic
    // "Object" type name rather than asserting a wrong specific identity.
    // Do NOT re-add SYM-derived names here without behavioral evidence.
    //
    // v0.18.3.291: 'ladline7' now HAS that evidence, so it gets a name -- but
    // note the evidence is empirical, not nominal. In the .290 BAT Aaron walked
    // the entire catalog while standing at the blocking gate and reported that
    // this was the ONLY entry that placed him at the right spot; the log agrees
    // (it is the sole entry reaching "In range." there, at ~1 step, while every
    // Gate is 500-1300 units away). Combined with its script REQ-dispatching
    // like the 'saku' gates, that is behavioral confirmation it IS a gate.
    // Deliberately unnumbered: "Gate 1"-"Gate 3" are saku1-saku3, and this is a
    // 4th distinct mechanism, not saku4 (that's the Director). An unnumbered
    // "Gate" avoids implying an ordering we haven't verified.
    { "ladline7", "Gate" },
    { "Laguna", "Laguna" },
    { "laguna", "Laguna" },
    { "laguna02", "Laguna" },
    { "laguna99", "Laguna" },
    { "Lift", "Elevator" },
    { "Lifter", "Elevator" },
    { "majo", "Sorceress" },
    { "Man", "Man" },
    { "manhole", "Manhole" },
    { "maniadoor", "Door" },
    // v0.18.3.267: Caraway's Mansion wine-glass puzzle. 'megami' = goddess —
    // the statue whose hands receive the glass. (Same Japanese-SYM convention
    // as 'majo' -> Sorceress above.) Its companion 'te' (= hand) is deliberately
    // NOT mapped: a two-letter SYM is too collision-prone to label globally.
    { "megami", "Statue" },
    { "memo", "Memo" },
    { "meskun", "Student" },
    { "mess", "Desk" },
    { "mindoor", "Door" },
    { "moni", "Study Panel" },
    { "monitor", "Study Panel" },
    { "Monorail", "Monorail" },
    { "monorail", "Monorail" },
    { "Munba2", "Moomba" },
    { "Munba3", "Moomba" },
    { "Munbamini", "Moomba" },
    { "naidarokun", "Student" },
    { "Newspaper", "Newspaper" },
    { "nida", "Nida" },
    { "Obaasan", "Old Woman" },
    { "petdoor", "Door" },
    { "Quistis", "Quistis" },
    { "quistis", "Quistis" },
    { "Quistis2", "Quistis" },
    { "raijin", "Raijin" },
    { "Rinoa", "Rinoa" },
    { "rinoa", "Rinoa" },
    { "Rinoa1", "Rinoa" },
    { "Rinoa2", "Rinoa" },
    { "Rinoau", "Rinoa" },
    { "rinoau", "Rinoa" },
    // v0.18.3.286 (#85): Deling City sewer gate maze (glwater2-5). 'sakuN'
    // entities are the movable gate/valve mechanisms the player toggles to
    // route water through the maze. Mapped to "Gate N" (Aaron's own term for
    // them) instead of the raw SYM-derived "SakuN" fallback -- plain "Saku"
    // isn't meaningful to a screen-reader user. Same sym numbering repeats
    // across the 4 fields (e.g. every field has its own 'saku1'), which is
    // fine: the catalog is per-field, so there's no cross-field collision.
    { "saku1", "Gate 1" },
    { "saku2", "Gate 2" },
    { "saku3", "Gate 3" },
    { "saku4", "Gate 4" },
    { "saku5", "Gate 5" },
    { "saku6", "Gate 6" },
    { "saku7", "Gate 7" },
    { "saku8", "Gate 8" },
    // v0.20.41 (#85 gate maze): the Deling sewer gate CONTROLLERS -- the entity the
    // player actually walks up to and presses action on to open a gate. Static
    // analysis of glwater3.jsm: each carries its own model + SET3 triangle and REQs a
    // 'sakuN' gate visual (ct_lf tri83->saku3 = the blocking gate to Sewer 2;
    // ct_rt tri138/ct_rt2 tri147->saku4; rt_up tri181->saku5). The visuals themselves
    // have no reliable runtime position, so the controller is the navigable anchor.
    // Needs a curated name to clear the junk-gate filter (same as saku = "Gate N").
    { "ct_lf", "Gate" },
    { "ct_rt", "Gate" },
    { "ct_rt2", "Gate" },
    { "rt_up", "Gate" },
    // v0.20.42 (#85 gate maze): the SAME control-mechanism family in the OTHER sewer
    // fields, enumerated from static analysis of every glwater*.sym (complete set, not a
    // pattern): glwater4 ct_lf_dw/lf_up/ct_rt_dw/ct_lt_up/ct_rt_dw2, glwater5 ct_rt_up/
    // ct_rt_dw, glwater1 seigyo. Each is an Other with a model that REQs a gate visual --
    // the point the player operates to open a gate. Per-field catalog, so no cross-field
    // collision (same rationale as the saku block above).
    { "ct_lf_dw", "Gate" },
    { "lf_up", "Gate" },
    { "ct_rt_dw", "Gate" },
    { "ct_lt_up", "Gate" },
    { "ct_rt_dw2", "Gate" },
    { "ct_rt_up", "Gate" },
    { "seigyo", "Gate" },
    { "savePoint", "Save Point" },
    { "scoaul", "Squall" },
    { "Seifer", "Seifer" },
    { "seifer", "Seifer" },
    { "seito1", "Student" },
    { "seito2", "Student" },
    { "seito3", "Student" },
    { "seito4", "Student" },
    { "seito5", "Student" },
    { "seito6", "Student" },
    { "sel_arms", "Selphie" },
    { "Selphie", "Selphie" },
    { "selphie", "Selphie" },
    { "Selphie_u", "Selphie" },
    { "SelphieDummy", "Selphie" },
    { "selphies", "Selphie" },
    { "Soldier1", "Soldier" },
    { "Soldier2", "Soldier" },
    { "SPObasan", "Old Woman" },
    { "Squall", "Squall" },
    { "squall", "Squall" },
    { "Squall2", "Squall" },
    { "squall2", "Squall" },
    { "Squall_O", "Squall" },
    { "Squall_u", "Squall" },
    { "squallo", "Squall" },
    { "squalls", "Squall" },
    { "squallsd", "Squall" },
    { "squallsp", "Squall" },
    { "student1", "Student" },
    { "student2", "Student" },
    { "Train", "Train" },
    { "Train1", "Train" },
    { "Train2", "Train" },
    { "Train3", "Train" },
    { "uketsuke", "Receptionist" },
    { "Ward", "Ward" },
    { "ward", "Ward" },
    { "Window1", "Window" },
    { "Woman", "Woman" },
    { "Women1", "Woman" },
    { "wpndoor", "Door" },
    { "Zell", "Zell" },
    { "zell", "Zell" },
    { "Zell1", "Zell" },
    { "Zell2", "Zell" },
    { "Zell_u", "Zell" },
    { "zells", "Zell" },
    { "ZonJichan", "Zone" },
    { nullptr, nullptr }
};

// ============================================================================
// SYM name -> entity type for special entities (draw/save/shop/card).
// ============================================================================
enum EntityClassificationType {
    EC_NONE = 0,
    EC_DRAW_POINT,
    EC_SAVE_POINT,
    EC_SHOP,
    EC_CARD_GAME,
    EC_NPC,
    EC_INTERACTIVE_OBJECT,
};

struct EntityTypeEntry {
    const char* sym;
    EntityClassificationType type;
};

static const EntityTypeEntry ENTITY_TYPE_TABLE[] = {
    { "cardgamemaster", EC_CARD_GAME },
    { "cardgamemaster2", EC_CARD_GAME },
    { "Cardtanto", EC_CARD_GAME },
    { "dp01", EC_DRAW_POINT },
    { "DrawPoint", EC_DRAW_POINT },
    { "DrawPointSampleCode", EC_DRAW_POINT },
    { "drpoint", EC_DRAW_POINT },
    { "savePoint", EC_SAVE_POINT },
    { nullptr, EC_NONE }
};

// Classification statistics:
//   Skip (controllers): 213 names
//   draw_point: 4 names
//   save_point: 1 names
//   shop: 0 names
//   card_game: 3 names
//   npc: 2395 names
//   Total classified: 2403 names
