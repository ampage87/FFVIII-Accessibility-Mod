// field_disc3_space.inl -- #111, the space rescue: closing on Rinoa.
// PART OF field_disc3.inl. Do NOT compile standalone.
//
// The whole game is "keep her centred", the verdict is taken once at the end of
// a 90-second approach, and the player cannot see any of it. v0.62.x gave a
// bearing whenever the phrase changed; Aaron's log shows what that is worth in
// practice -- "right and down" at 14:52:59 and then FIFTY-THREE SECONDS of
// silence, during which X moved by four units because he was holding only one
// of the two arrows and nothing ever told him. He asked for three things:
//
//   "We also need a Game Controls screen like we did for the punch and dragon
//    mini-games. The TTS should speak frequently throughout the game, with
//    maybe a 3-5 second pause in between."
//
// and that the steering be precise enough to land the shot. So:
//
//   * a Game Controls screen, in one of the game's own dialog windows, read
//     aloud and dismissed with Enter (or on its own after 15 seconds, so it can
//     never strand him);
//   * a bearing every 3.5 seconds -- 1.2 when she is close -- SPOKEN WHETHER OR
//     NOT IT CHANGED, because "still right" is the most useful thing he can
//     hear when he is holding the wrong key;
//   * a radar beep under all of it: pitch rises and the gap shortens as she
//     centres. Words cannot resolve 180 units out of 8100; a reversing sensor
//     can, and it costs nothing to listen to.
//
// The steering deadband is SR_AIM_BOX (60), a third of the game's own 180, so
// "centred" means there is margin rather than that the next reaction could
// throw it away. tests/space_sim_test.cpp flies the whole approach on nothing
// but these words, from Aaron's three real starting errors and from both far
// corners, and lands inside a few units of dead centre in every one.

namespace Space {

static const uint16_t SS_ID = SR_FIELD_ID;      // 878, derived; name is the backstop

static bool   s_on        = false;
static bool   s_briefed   = false;
static bool   s_skip      = false;
static bool   s_wasIn     = false;      // inside the aim box last tick
static DWORD  s_lastCall  = 0;
static char   s_lastWord[64] = "";
static int    s_lastWorst = -1;         // worse-axis error at the previous call
static DWORD  s_radarAt   = 0;

// The Game Controls screen.
static bool   s_screen    = false;      // the box is up
static DWORD  s_screenAt  = 0;
static bool   s_enterWas  = false;
static DWORD  s_arrivedAt = 0;
static DWORD  s_dlgLast   = 0;             // last tick a field dialogue was open
static const DWORD SP_SCREEN_MS = 15000;   // it closes itself if he never presses
// The scene opens with three lines of Squall's own thoughts -- "(Rinoa......
// Where are you?)" at +2 s, "(I'm gonna find you...)" at +8, "(I have to get in
// front of her...)" at +15 in Aaron's log. Briefing over them means the mod
// interrupts the game and then the game interrupts the mod, and he hears two
// halves of two things. So the screen waits for the dialogue to go quiet --
// capped, because a scene that never stops talking must not swallow the brief
// entirely, and the timer is running the whole time.
static const DWORD SP_DLG_QUIET_MS = 1200;
static const DWORD SP_BRIEF_CAP_MS = 22000;

// Cadence. Both are inside Aaron's "maybe a 3-5 second pause", and the near
// band tightens it where a call is worth more.
static const DWORD SP_CALL_MS  = 3500;
static const DWORD SP_NEAR_MS  = 1200;
static const int   SP_NEAR_BAND = 900;

static void Reset()
{
    s_on = false; s_briefed = false; s_skip = false; s_wasIn = false;
    s_lastCall = 0; s_lastWord[0] = '\0'; s_lastWorst = -1; s_radarAt = 0;
    s_screen = false; s_screenAt = 0; s_enterWas = false;
    s_arrivedAt = 0; s_dlgLast = 0;
}

// Active while the scene is running and the skip is not: the catalog goes quiet
// for the duration. Aaron's 14:54:22 log has auto-drive setting off toward
// "Exit to Outer Space 5" -- which is Rinoa, catalogued as a door -- in the
// middle of the attempt he was flying.
static bool Active() { return s_on && !s_skip; }

static bool Here()
{
    const char* why = "";
    return D3Here(SS_ID, "ssspace3", &why);
}

static bool ReadXY(int32_t* x, int32_t* y)
{
    return D3ReadI32(SR_ADDR_X, x) && D3ReadI32(SR_ADDR_Y, y);
}

// ---------------------------------------------------------------------------
// THE RADAR
// ---------------------------------------------------------------------------
// Its own buffer and its own builder, because the pitch changes on every beep
// and GardenBattle's tone is a single pre-built two-note cue shared with two
// other modules. 60 ms is long enough to have a pitch and short enough to sit
// under speech without muddying it.
static const int SP_TONE_RATE = 22050;
static const int SP_TONE_MS   = 60;
static const int SP_TONE_N    = (SP_TONE_RATE * SP_TONE_MS) / 1000;
#pragma pack(push, 1)
struct SpWav {
    char riff[4]; uint32_t riffSize; char wave[4];
    char fmt[4];  uint32_t fmtSize;  uint16_t format, channels;
    uint32_t rate, byteRate; uint16_t align, bits;
    char data[4]; uint32_t dataSize;
};
#pragma pack(pop)
static uint8_t s_spTone[sizeof(SpWav) + SP_TONE_N * 2];

static void SpPlayHz(int hz)
{
    SpWav* h = (SpWav*)s_spTone;
    memcpy(h->riff, "RIFF", 4); memcpy(h->wave, "WAVE", 4);
    memcpy(h->fmt,  "fmt ", 4); memcpy(h->data, "data", 4);
    h->fmtSize = 16; h->format = 1; h->channels = 1;
    h->rate = SP_TONE_RATE; h->bits = 16; h->align = 2;
    h->byteRate = SP_TONE_RATE * 2;
    h->dataSize = SP_TONE_N * 2;
    h->riffSize = sizeof(SpWav) - 8 + h->dataSize;
    int16_t* pcm = (int16_t*)(s_spTone + sizeof(SpWav));
    const int taper = SP_TONE_RATE * 4 / 1000;
    for (int i = 0; i < SP_TONE_N; i++) {
        const double ph = 2.0 * 3.14159265358979 * hz * i / SP_TONE_RATE;
        double v = 0.75 * sin(ph) + 0.25 * (sin(ph) >= 0.0 ? 0.6 : -0.6);
        if (i < taper)              v *= (double)i / taper;
        if (SP_TONE_N - i < taper)  v *= (double)(SP_TONE_N - i) / taper;
        int sv = (int)(v * 26000.0);
        if (sv >  32767) sv =  32767;
        if (sv < -32768) sv = -32768;
        pcm[i] = (int16_t)sv;
    }
    PlaySoundA((LPCSTR)s_spTone, nullptr, SND_MEMORY | SND_ASYNC | SND_NODEFAULT);
}

// ---------------------------------------------------------------------------
// THE GAME CONTROLS SCREEN
// ---------------------------------------------------------------------------
// The window is 320x224 and the measurer charges about 18 px a line -- the
// Garden battle's six-line box came back 108 px high -- so eleven lines is the
// ceiling and this is nine. Every line is inside BRIEF_COLS (34) so the wrap
// never turns one line into two behind our back. tests/disc3_wiring_compile.cpp
// asserts both, because a box that runs off the bottom of the screen is exactly
// what v0.20.125 had to go back and fix.
static const char* SP_SCREEN_TEXT =
    "REACHING RINOA\n"
    "Arrows steer. Hold what I call.\n"
    "Two arrows at once = a diagonal.\n"
    "The beep rises as she centres.\n"
    "A double beep means centred --\n"
    "then let go. Nothing moves her\n"
    "but you: hands off holds it.\n"
    "Only the very end counts.\n"
    "Enter start   / repeat   F9 skip";

static void OpenScreen(DWORD now)
{
    s_screen   = true;
    s_screenAt = now ? now : 1;
    GardenBattle::OpenBriefDialog(SP_SCREEN_TEXT);
    D3Say("SPACE",
          "Game controls. Reaching Rinoa. The arrow keys steer -- hold the direction "
          "I call, and two arrows together for a diagonal. A beep plays under "
          "everything: the higher and faster it gets, the closer she is to "
          "centre, and a double beep means she is centred -- then let go of the "
          "keys, because nothing moves her but you. Only where she is at the "
          "very end counts. Slash repeats the bearing. F9 skips the game. "
          "Press Enter to start.", true);
    Log::Field("FieldNavigation: [SPACE] game controls open");
}

static void CloseScreen(const char* why)
{
    if (!s_screen) return;
    s_screen = false;
    GardenBattle::CloseBriefDialog();
    Log::Field("FieldNavigation: [SPACE] game controls closed (%s)", why);
}

// ---------------------------------------------------------------------------
// THE STEERING CALL
// ---------------------------------------------------------------------------
// SrCall builds the phrase; this adds the one thing a phrase cannot carry --
// whether what he is doing is working. "still" on a repeat that has not closed
// any ground is the sentence Aaron's first attempt needed and never got.
static void CallIt(int32_t x, int32_t y, bool force)
{
    char word[64];
    SrCall((int)x, (int)y, word, sizeof word);

    const int worst = SrWorst((int)x, (int)y, SR_CLAMP_X, SR_CLAMP_Y);
    const int trend = (s_lastWorst < 0) ? 1 : SrTrend(s_lastWorst, worst);
    s_lastWorst = worst;

    char line[96];
    if (strcmp(word, "centred") == 0) {
        snprintf(line, sizeof line, "centred");
    } else if (!force && trend <= 0 && strcmp(word, s_lastWord) == 0) {
        // Same call as last time and no ground closed: say so.
        snprintf(line, sizeof line, "still %s", word);
    } else {
        snprintf(line, sizeof line, "%s", word);
    }
    strncpy(s_lastWord, word, sizeof(s_lastWord) - 1);
    s_lastWord[sizeof(s_lastWord) - 1] = '\0';
    ScreenReader::Speak(line, true);
    Log::Field("FieldNavigation: [SPACE] x=%ld y=%ld worst=%d trend=%d -> \"%s\"",
               (long)x, (long)y, worst, trend, line);
}

static void Update(bool slash, bool f9)
{
    if (!Here()) {
        if (s_on) {
            CloseScreen("left the field");
            Log::Field("FieldNavigation: [SPACE] left ssspace3");
            Reset();
        }
        return;
    }
    if (!s_on) {
        s_on = true;
        Log::Field("FieldNavigation: [SPACE] entered ssspace3 (id %u)", (unsigned)D3FieldId());
    }

    int32_t x = 0, y = 0;
    if (!ReadXY(&x, &y)) return;
    // Outside the clamp the scene has not started writing yet; saying anything
    // then is the "laguna=216" mistake from the dragon fight in another form.
    if (x > SR_CLAMP_X || x < -SR_CLAMP_X || y > SR_CLAMP_Y || y < -SR_CLAMP_Y) return;

    const DWORD now = GetTickCount();
    if (!s_arrivedAt) s_arrivedAt = now ? now : 1;
    if (FieldDialog::IsDialogOpen()) s_dlgLast = now;

    // F9 is read FIRST, before the brief wait and before the screen gate. It is
    // the escape hatch, and an escape hatch that only works once the mod has
    // finished talking is not one -- waiting out Squall's monologue is exactly
    // when a player who does not want to fly this scene reaches for it.
    if (f9 && !s_skip) {
        s_skip = true;
        s_briefed = true;
        CloseScreen("skip");
        D3Say("SPACE", "Skip on. Holding her centred -- the rescue will complete on its own.", true);
        Log::Field("FieldNavigation: [SPACE] skip armed at x=%ld y=%ld", (long)x, (long)y);
    }
    if (s_skip) {
        // THE SKIP. The verdict reads exactly these two variables, once, at the
        // end of the approach. Holding both at zero makes the game's own
        // bytecode take its own win branch -- var[1035]=1, var[256]=2564,
        // MAPJUMPO 877 are all the game's. Nothing is forged and no transition
        // is synthesised. It has to be held every tick because the key handlers
        // keep adding to the same two variables; a one-shot write would be
        // undone by the next frame the player leans on a direction.
        D3WriteI32(SR_ADDR_X, 0);
        D3WriteI32(SR_ADDR_Y, 0);
        return;
    }

    if (!s_briefed) {
        const bool quiet   = !FieldDialog::IsDialogOpen() &&
                             (s_dlgLast == 0 || now - s_dlgLast >= SP_DLG_QUIET_MS);
        const bool tooLong = (now - s_arrivedAt) >= SP_BRIEF_CAP_MS;
        if (quiet || tooLong) {
            s_briefed = true;
            OpenScreen(now);
            if (tooLong && !quiet)
                Log::Field("FieldNavigation: [SPACE] briefing over the scene's own "
                           "dialogue -- %u ms of waiting is all the timer can spare",
                           (unsigned)SP_BRIEF_CAP_MS);
        } else {
            return;   // still Squall's own lines. Say nothing over them.
        }
    }

    // The screen closes on Enter, or on its own. Nothing else runs while it is
    // up: a bearing under the briefing is two voices at once.
    if (s_screen) {
        const bool enter = (GetAsyncKeyState(VK_RETURN) & 0x8000) != 0;
        const bool hit   = enter && !s_enterWas;
        s_enterWas = enter;
        if (hit)                                   CloseScreen("Enter");
        else if (now - s_screenAt >= SP_SCREEN_MS) CloseScreen("timed out");
        else return;
        s_lastCall = 0; s_radarAt = 0; s_lastWorst = -1;
    }

    // ---- the radar ---------------------------------------------------------
    const int t1000 = SrRadarT((int)x, (int)y, SR_CLAMP_X, SR_CLAMP_Y);
    const bool in   = SrHeld((int)x, (int)y);
    if (now - s_radarAt >= (DWORD)SrRadarGapMs(t1000)) {
        s_radarAt = now;
        SpPlayHz(SrRadarHz(t1000));
    }

    // ---- entering or losing the aim box ------------------------------------
    if (in != s_wasIn) {
        s_wasIn = in;
        GardenBattle::PlayTone();          // the two-note cue, unmistakable
        Log::Field("FieldNavigation: [SPACE] %s the box at x=%ld y=%ld",
                   in ? "entered" : "lost", (long)x, (long)y);
        CallIt(x, y, true);
        s_lastCall = now;
        return;
    }

    if (slash) { CallIt(x, y, true); s_lastCall = now; return; }

    const int   worstAbs = (abs((int)x) > abs((int)y)) ? abs((int)x) : abs((int)y);
    const DWORD period   = (worstAbs < SP_NEAR_BAND) ? SP_NEAR_MS : SP_CALL_MS;
    if (now - s_lastCall >= period) { s_lastCall = now; CallIt(x, y, false); }
}

} // namespace Space
