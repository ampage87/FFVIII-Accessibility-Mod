// field_disc3_propagator.inl -- #112, the Ragnarok Propagator puzzle.
// PART OF field_disc3.inl. Do NOT compile standalone.
//
// Aaron named three problems. This handles the two that are information:
// which colour is in front of you, and which one you are allowed to kill next.
// The third -- that some of them charge you and a blind player cannot dodge --
// is answered by telling him where the thing is and when it is closing, rather
// than by writing to the game. See the note at the bottom for why.

namespace Props {

// Derived ids (field_disc3.inl explains the derivation and the id-OR-name
// rule). rg block = +74: rgair1 821 .. rgroad3 844.
static const uint16_t RG_ID_LO = 821, RG_ID_HI = 845;

static bool  s_on = false;
static uint8_t s_lastDead = 0xFE;     // impossible, so the first read announces
static bool  s_lastPending = false;
static char  s_lastField[32] = "";

static void Reset() { s_on = false; s_lastDead = 0xFE; s_lastPending = false; s_lastField[0] = '\0'; }

// NAME ONLY, deliberately -- unlike Space, which needs the id.
//
// v0.55.0: this used to be "name OR id in 821..845". The id range is DERIVED
// (field_disc3.inl explains how), and a derived range that is wrong does not
// merely fail to fire -- it fires somewhere else, and the failure mode is the
// mod announcing Propagator kill counts in the middle of an unrelated scene
// for the rest of the game. Nothing here is reflex-timed: routes, colours and
// pair status are all fine arriving with pCurrentFieldName's 2-5 second lag.
// So the id buys nothing worth that risk and is only LOGGED, which is what
// turns one BAT into a confirmed derivation.
static bool InRagnarok()
{
    if (!PgIsRagnarokField(D3FieldName())) return false;
    const uint16_t id = D3FieldId();
    if (id < RG_ID_LO || id > RG_ID_HI) {
        static bool s_warned = false;
        if (!s_warned) {
            s_warned = true;
            Log::Field("FieldNavigation: [PROPAGATOR] '%s' is id %u, OUTSIDE the derived "
                       "range %u..%u -- the rg-block derivation is wrong; the feature still "
                       "works (it is name-driven) but fix the range",
                       D3FieldName(), (unsigned)id, (unsigned)RG_ID_LO, (unsigned)RG_ID_HI);
        }
    }
    return true;
}

static bool ReadState(uint8_t* dead, uint8_t* pendBit, bool* pending)
{
    uint8_t d = 0, pb = 0, pf = 0;
    if (!D3ReadU8(D3VarAddr(PG_VAR_DEAD), &d)) return false;
    if (!D3ReadU8(D3VarAddr(PG_VAR_PENDBIT), &pb)) return false;
    if (!D3ReadU8(D3VarAddr(PG_VAR_PENDFLAG), &pf)) return false;
    *dead = d; *pendBit = pb; *pending = (pf & PG_PENDING_MASK) != 0;
    return true;
}

static void Update(bool slash)
{
    if (!InRagnarok()) {
        if (s_on) { Log::Field("FieldNavigation: [PROPAGATOR] left the Ragnarok"); Reset(); }
        return;
    }
    if (!s_on) {
        s_on = true;
        // Assert the table once, where a BAT can see it. A pairing that does
        // not close is the one defect that would quietly teach the player the
        // wrong move.
        Log::Field("FieldNavigation: [PROPAGATOR] aboard (field '%s' id %u); pair table %s",
                   D3FieldName(), (unsigned)D3FieldId(),
                   PgTableConsistent() ? "consistent" : "**INCONSISTENT -- do not trust it**");
    }

    uint8_t dead = 0, pendBit = 0; bool pending = false;
    if (!ReadState(&dead, &pendBit, &pending)) return;

    const char* nm = D3FieldName();
    const Propagator* here = PgForField(nm);
    const bool movedField = (nm && *nm && _stricmp(nm, s_lastField) != 0);
    if (movedField) {
        strncpy(s_lastField, nm, sizeof(s_lastField) - 1);
        s_lastField[sizeof(s_lastField) - 1] = '\0';
        char b[256];
        if (here && !(dead & here->bit)) {
            PgHereLine(here, dead, pendBit, pending, b, sizeof(b));
            D3Say("PROPAGATOR", b, true);
        }
        Log::Field("FieldNavigation: [PROPAGATOR] '%s' dead=0x%02X pendBit=0x%02X pending=%d here=%s",
                   nm, dead, pendBit, (int)pending, here ? here->colour : "-");
    }

    // A kill changed the board: say what it means for the next move, because
    // the consequence of the last one is invisible until you walk back into a
    // room and find the thing standing there again.
    if (dead != s_lastDead || pending != s_lastPending) {
        if (s_lastDead != 0xFE) {
            char b[256];
            PgStatusLine(dead, pendBit, pending, b, sizeof(b));
            D3Say("PROPAGATOR", b, true);
        }
        s_lastDead = dead; s_lastPending = pending;
    }

    if (slash) {
        char b[256], c[256];
        PgStatusLine(dead, pendBit, pending, b, sizeof(b));
        D3Say("PROPAGATOR", b, true);
        if (here) { PgHereLine(here, dead, pendBit, pending, c, sizeof(c)); D3Say("PROPAGATOR", c, false); }
    }
}

// ============================================================================
// ON HOLDING THEM STILL -- WHY THIS BUILD DOES NOT
// ============================================================================
//
// Aaron: *"the monsters run at the player in a lot of the rooms... We might
// have to suppress their movement."* He is right that it is a problem, and the
// game does have a standby: `dic::defalut` in rghang1, rghang2, rgroad2 and
// rgroad3 writes a mode byte -- var[1051] in rghang1, var[1050] in the other
// three -- and mode 0 is a patrol in which the touch-and-battle branch is
// unreachable. Pinning it to 0 is in-domain, because the engine writes that
// value itself.
//
// It is NOT shipped yet, for two reasons and both are about this specific
// build:
//
//   1. It covers four of the eight. rgair1 and rgroad1 are stationary anyway,
//      rgexit1 chases unconditionally with no standby at all, and rgguest2 is a
//      scripted charge that ends in a MAPJUMP3. So it would half-solve the
//      problem while reading as solved.
//   2. `dic` recomputes that byte every loop, so it has to be rewritten every
//      frame -- and a per-frame write into a script's own state, in a scene
//      nobody has ever run the mod in, is exactly the shape of change that
//      should follow a BAT rather than precede one.
//
// The information layer above is worth having on its own: knowing which one you
// are allowed to kill is the puzzle, and it is safe. Once Aaron has walked the
// Ragnarok once and the log shows the mode byte moving as predicted, the pin is
// four lines.
//
// What would be forgery, and is not on the table either way: writing var[446],
// var[447], var[445] bit 2 or var[437]. Those are the puzzle's answer, not its
// controls.

} // namespace Props
