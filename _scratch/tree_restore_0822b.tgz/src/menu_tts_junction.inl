// menu_tts_junction.inl — GCW decoder, junction TTS (char select, GF, ability)
// Included from menu_tts.cpp. Do not compile independently.
// v0.12.18: Extracted for readability.

static void DecodeGcwToBuffer(const uint8_t* gcwBuf, int gcwLen, char* outBuf, int outBufSize)
{
    outBuf[0] = '\0';
    if (gcwLen <= 0) return;
    std::string tmp = FF8TextDecode::DecodeMenuText(gcwBuf, gcwLen);
    strncpy(outBuf, tmp.c_str(), outBufSize - 1);
    outBuf[outBufSize - 1] = '\0';
}

// Default GF names (fallback if savemap read fails)
static const char* GF_DEFAULT_NAMES[] = {
    "Quezacotl", "Shiva", "Ifrit", "Siren", "Brothers", "Diablos",
    "Carbuncle", "Leviathan", "Pandemona", "Cerberus", "Alexander",
    "Doomtrain", "Bahamut", "Cactuar", "Tonberry", "Eden"
};
static const int GF_COUNT = 16;
static const int GF_STRUCT_SIZE = 68;  // 0x44 bytes per GF in savemap

// State tracking
static bool     s_juncActive = false;          // true while Junction subsystem is active (+0x1E8==17)
static uint8_t  s_juncPrevCharCursor = 0xFF;    // previous character select cursor
static uint8_t  s_juncPrevFocus = 0xFF;         // previous +0x22E focus state
static uint8_t  s_juncPrevActionCursor = 0xFF;  // previous action menu cursor (+0x26C)
static bool     s_juncCharSelectAnnounced = false; // true after first char select announce
static uint8_t  s_juncPrevSuboptCursor = 0xFF;  // previous sub-option cursor (+0x268)
static uint8_t  s_juncPrevGfListCursor = 0xFF;  // previous GF list cursor (+0x26D)
static uint8_t  s_juncPrevGfToggle = 0xFF;      // previous GF toggle state (+0x27F)

// v0.09.46: Ability screen state — CORRECTED via user testing
// Each panel has its own focus value and cursor offset:
//   LEFT (equipped slots):   focus=24, cursor at +0x27C
//   RIGHT (available list):  focus=28, cursor at +0x270 + kind  (v0.23.0)
// v0.09.45 had these swapped. User test proved: focus=28 cursor goes to 10+
// (many GF abilities = RIGHT), focus=24 cursor stays 0-3 (few slots = LEFT).
// Intermediate focus values (21, 22, 26, 27) are transitions — ignore them.
// v0.23.0: the right cursor is not a fixed +0x271 — that is only the COMMAND
// list's copy. See JUNC_ABIL_CUR_OFF below and the focus==28 block.
static const int ABIL_LEFT_CURSOR_OFF  = 0x27C;  // left panel cursor (focus=24)
static const int ABIL_LEFT_FOCUS  = 24;
static const int ABIL_RIGHT_FOCUS = 28;
static uint8_t  s_juncPrevAbilLeftCursor  = 0xFF;
static uint8_t  s_juncPrevAbilRightCursor = 0xFF;
static uint8_t  s_juncPrevAbilFocus = 0xFF;  // tracks focus for panel transition detection
// v0.23.0 (#82): the right panel's cursor is per-LIST, and the lists are the
// game's own. See the focus==28 block for the derivation; these are the four
// addresses 0x004DAE08 and 0x004E0110 use between them.
static const int JUNC_ABIL_CUR_OFF  = 0x270;   // + kind: 0x271 command, 0x272 character
static const int JUNC_ABIL_KIND_OFF = 0x274;   // 1 = command list, 2 = character list
static const uintptr_t JUNC_ABIL_CMD_LIST   = 0x01D8B258;  // {id, nameIdx} pairs, ids 20..38
static const uintptr_t JUNC_ABIL_CMD_COUNT  = 0x01D8B690;
static const uintptr_t JUNC_ABIL_CHAR_LIST  = 0x01D8B280;  // {id, nameIdx} pairs, ids 39..82
static const uintptr_t JUNC_ABIL_CHAR_COUNT = 0x01D8B691;
static uint8_t  s_abilLastLeftCursor = 0;  // tracks which left slot was last active (0-2=cmd, 3-6=ability)
static uint16_t s_juncCachedGfMasks[8] = {}; // v0.09.49: GF bitmasks for ALL chars, cached at Junction entry (game zeroes them during editing)
static uint8_t  s_juncSelectedCharIdx = 0xFF;  // v0.09.49: cached charIdx from char select (formation array gets rewritten during editing)
// v0.23.3: which character the char-select screen most recently SPOKE. The
// Junction hook's character watcher consumes this to tell "you confirmed the
// character you were just told about" (silent) from "L1/R1 switched to a
// different one" (speak the name). Keyed on the VALUE, not on time: the two
// cases are two seconds apart either way, so recency cannot separate them, but
// only the first lands on the character char-select just named.
static uint8_t  s_juncCharSelSpoke = 0xFF;

// v0.18.2.22: active/reserve party grouping legend for the Junction/Magic/Status
// character-select screens. Sighted players see the 3 active battle members'
// slots set apart from the reserve slots; we convey that with a fieldset/legend-
// style cue ("Active Party Start" / "Reserve Party Start") announced when the
// cursor first lands in a group or crosses into the other. Start cues only.
// 0=none/reset, 1=active, 2=reserve; reset on each (re)entry so every visit re-cues.
static int  s_charSelPrevGroup = 0;
static void ResetCharSelGroup() { s_charSelPrevGroup = 0; }

// v0.18.2.1: J-Auto submenu. From the action menu (Junction/Off/Auto) confirming
// "Auto" opens a 3-option submenu that auto-junctions the character's magic to
// optimize a stat. Confirmed by SUBMON (BAT 2026-06-02): focus (+0x22E) settles
// at 11 and stays there while navigating; the option cursor is +0x26A (0/1/2) and
// the GCW help line tracked it exactly ("Junction magic to up Str/Mag/HP").
static const int JUNC_AUTO_FOCUS      = 11;     // +0x22E value on the Auto submenu
static const int JUNC_AUTO_CURSOR_OFF = 0x26A;  // option cursor (0=Atk,1=Mag,2=Def)
static const int JUNC_AUTO_OPT_COUNT  = 3;
static const char* const JUNC_AUTO_OPT_NAMES[] = { "Attack", "Magic", "Defense" };
// Help (read on "/", like the GF/Ability menus): the game's help-bar text per option.
static const char* const JUNC_AUTO_OPT_HELP[] = {
    "Junctions magic to raise Strength.",
    "Junctions magic to raise Magic.",
    "Junctions magic to raise HP."
};
static uint8_t s_juncPrevAutoCursor = 0xFF;     // previous Auto submenu cursor
static bool    s_juncAutoConfirmPending = false; // Auto option confirmed; speak confirmation when the action menu settles
static uint8_t s_juncAutoConfirmOpt     = 0xFF;  // which Auto option (0/1/2) was confirmed
// v0.18.2.6: apply-detection via the auto-junction routine itself. Confirm and
// cancel of the Auto submenu are byte-identical in the focus path (11 -> 8 -> 3),
// so apply/cancel can't be read from menu state. BAT (2026-06-02) proved the game
// routine at 0x004BE790 that rewrites the working junction array runs on a CONFIRM
// (even a no-op confirm that changes nothing) and does NOT run on a CANCEL. The HW
// write-BP below sets this flag from inside that routine while the Auto submenu is
// focused (+0x22E==11); the action-menu resolution reads it: set => confirm
// (announce), clear => cancel (silent). Replaces the v0.18.2.3 magic-changed
// snapshot, which was silent on no-op confirms (Aaron: "reads as broken").
static volatile bool s_juncAutoRoutineRan = false;


// ============================================================================
// v0.18.2.6 — auto-junction CONFIRM detector (HW write BP on the working byte)
// ============================================================================
// v0.18.2.4 BAT proved the menu module does NOT update pEngineInputConfirmedButtons
// (zero [JuncBtnDiag] lines across a full Auto session), so the engine button
// bitmask can't tell us a confirm happened. Instead we find the routine that
// rearranges the magic: on a confirm it writes the menu's working junction array
// at pMenuStateA+0x6C2 (BAT log: 0x6C2 0->18, 0x6C4 32->0). A 1-byte hardware
// WRITE breakpoint on that fixed address fires INSIDE the auto-junction routine.
// We log EIP + registers + FF8-.text stack return addresses; the return addresses
// sets s_juncAutoRoutineRan when it fires while the Auto submenu is focused. DR3
// is used (DR0/1/2 are the battle BPs); each VEH checks its own DR6 bit so they
// coexist. Armed on Junction-menu activation, dropped on Junction reset. This is
// now load-bearing (the apply/cancel signal), not a throwaway diagnostic.
static const int      JUNC_AUTO_WORK_OFF = 0x6C2;   // working junction byte the routine writes
static volatile bool  s_juncAutoBPArmed  = false;
static PVOID          s_juncAutoBPVEH    = nullptr;
static uint32_t       s_juncAutoBPTarget = 0;       // resolved pMenuStateA + 0x6C2

static LONG CALLBACK JuncAutoBP_VEH(PEXCEPTION_POINTERS pEx)
{
    if (pEx->ExceptionRecord->ExceptionCode != EXCEPTION_SINGLE_STEP)
        return EXCEPTION_CONTINUE_SEARCH;
    if (!((DWORD)pEx->ContextRecord->Dr6 & 0x08))  // DR3 condition bit — not our hit
        return EXCEPTION_CONTINUE_SEARCH;
    pEx->ContextRecord->Dr6 &= ~0x0F;  // acknowledge

    // The write fires from inside the game's auto-junction routine (0x004BE790),
    // which runs on a CONFIRM of the Auto submenu (including a no-op confirm) and
    // NOT on a cancel. Gate on the Auto submenu being focused (+0x22E==11) so the
    // same byte's menu-load / manual-junction writes don't trip the flag.
    //
    // **v0.23.3: that gate is load-bearing, and it was closer than it looked.**
    // 0x004BE790 is ALSO called by the L1/R1 character swap -- 0x004DABA9 and
    // 0x004DAD05, both in the action-row handler on the way into states 4 and 6.
    // Without the focus test every character switch would announce "Junctioned
    // automatically for ...", and it would do so only after an Auto submenu had
    // been opened at some point, which is exactly the kind of intermittent that
    // costs a BAT cycle to pin down. Anyone tempted to widen this gate should
    // read that sentence twice.
    __try {
        if (pMenuStateA && ((uint8_t*)pMenuStateA)[0x22E] == 11)
            s_juncAutoRoutineRan = true;
    } __except(EXCEPTION_EXECUTE_HANDLER) {}
    return EXCEPTION_CONTINUE_EXECUTION;
}

static void JuncAutoBP_SetAllThreads(bool arm)
{
    DWORD pid = GetCurrentProcessId();
    DWORD myTid = GetCurrentThreadId();
    HANDLE snap = CreateToolhelp32Snapshot(TH32CS_SNAPTHREAD, 0);
    if (snap == INVALID_HANDLE_VALUE) return;
    THREADENTRY32 te; te.dwSize = sizeof(te);
    int done = 0;
    if (Thread32First(snap, &te)) {
        do {
            if (te.th32OwnerProcessID != pid) continue;
            HANDLE h = OpenThread(
                THREAD_SUSPEND_RESUME | THREAD_GET_CONTEXT | THREAD_SET_CONTEXT,
                FALSE, te.th32ThreadID);
            if (!h) continue;
            bool isSelf = (te.th32ThreadID == myTid);
            if (!isSelf) SuspendThread(h);
            CONTEXT ctx; ctx.ContextFlags = CONTEXT_DEBUG_REGISTERS;
            if (GetThreadContext(h, &ctx)) {
                if (arm) {
                    ctx.Dr3 = s_juncAutoBPTarget;
                    ctx.Dr7 &= ~((DWORD)0x40 | ((DWORD)0x0F << 28)); // clear L3 + RW3 + LEN3
                    ctx.Dr7 |= (DWORD)0x40;                          // L3 local enable (bit 6)
                    ctx.Dr7 |= ((DWORD)0x01 << 28);                  // RW3 = 01 (write-only)
                    // LEN3 = 00 (1 byte)
                } else {
                    ctx.Dr3 = 0;
                    ctx.Dr7 &= ~((DWORD)0x40 | ((DWORD)0x0F << 28));
                }
                if (SetThreadContext(h, &ctx)) done++;
            }
            if (!isSelf) ResumeThread(h);
            CloseHandle(h);
        } while (Thread32Next(snap, &te));
    }
    CloseHandle(snap);
    Log::Menu("[JuncAutoBP] %s DR3 on 0x%08X (1-byte write) — threads=%d",
               arm ? "armed" : "disarmed", s_juncAutoBPTarget, done);
}

static void JuncAutoBP_Arm()
{
    if (s_juncAutoBPArmed) return;
    if (!pMenuStateA) return;
    if (!s_juncAutoBPVEH) {
        s_juncAutoBPVEH = AddVectoredExceptionHandler(1, JuncAutoBP_VEH);
        Log::Menu("[JuncAutoBP] VEH registered: 0x%08X", (uint32_t)(uintptr_t)s_juncAutoBPVEH);
    }
    s_juncAutoBPTarget = (uint32_t)(uintptr_t)((uint8_t*)pMenuStateA + JUNC_AUTO_WORK_OFF);
    JuncAutoBP_SetAllThreads(true);
    s_juncAutoBPArmed = true;
}

static void JuncAutoBP_Disarm()
{
    if (!s_juncAutoBPArmed) return;
    JuncAutoBP_SetAllThreads(false);
    s_juncAutoBPArmed = false;
}

static void ResetJunctionState()
{
    JuncAutoBP_Disarm();  // v0.18.2.6: drop the HW write BP when the Junction state resets
    s_juncActive = false;
    s_juncPrevCharCursor = 0xFF;
    s_juncPrevFocus = 0xFF;
    s_juncPrevActionCursor = 0xFF;
    s_juncCharSelectAnnounced = false;
    s_juncPrevSuboptCursor = 0xFF;
    s_juncPrevGfListCursor = 0xFF;
    s_juncPrevGfToggle = 0xFF;
    s_juncPrevAbilLeftCursor = 0xFF;
    s_juncPrevAbilRightCursor = 0xFF;
    s_juncPrevAbilFocus = 0xFF;
    s_abilLastLeftCursor = 0;
    memset(s_juncCachedGfMasks, 0, sizeof(s_juncCachedGfMasks));
    s_juncSelectedCharIdx = 0xFF;
    s_juncPrevAutoCursor = 0xFF;
    s_juncAutoConfirmPending = false;
    s_juncAutoConfirmOpt     = 0xFF;
    s_juncAutoRoutineRan     = false;
}

// Compute character level from EXP. FF8: each level needs 1000 EXP flat.
static int ComputeCharLevel(uint32_t exp)
{
    int lvl = (int)(exp / 1000) + 1;
    if (lvl > 100) lvl = 100;
    return lvl;
}

// SEH-safe: Announce a party member for Junction character select.
// Uses inline literal addresses to avoid forward reference issues.
// savemap=0x1CFDC5C, chars at +0x48C (8×0x98), compStats at 0x1CFF000 (3×0x1D0)
//
// v0.09.41: The cursor at +0x1E9 indexes directly into the formation array
// at savemap+0xAF0. The engine places characters in the visual slot positions:
//   1 member  → formation=[FF, charIdx, FF, FF] (middle slot)
//   2 members → formation=[charA, charB, FF, FF] (top + middle)
//   3 members → formation=[charA, charB, charC, FF] (all three)
// So formation[cursorPos] gives the character at the cursor's visual slot,
// or 0xFF for an empty slot. No compaction or centering formula needed.
static void AnnounceJuncCharSelect(uint8_t cursorPos, bool announceGroup = false)
{
    __try {
        uint8_t* sm = (uint8_t*)0x1CFDC5C;  // SAVEMAP_BASE
        // Party formation at +0xAF0: 4 bytes, char index 0-7 or 0xFF.
        // Cursor indexes directly into this array — engine handles centering.
        uint8_t* party = sm + 0xAF0;
        
        uint8_t* roster = (uint8_t*)pMenuStateA + 0x1DB;  // v0.18.2.14: char-select cursor indexes the roster (all available chars incl. reserves), NOT the 3-slot formation
        if (cursorPos > 7) {
            Log::Menu("[JuncTTS] CharSelect cursor %u out of range", (unsigned)cursorPos);
            return;
        }
        
        uint8_t charIdx = roster[cursorPos];
        if (charIdx == 0xFF || charIdx > 10) {
            ScreenReader::Speak("Empty", true);
            Log::Menu("[JuncTTS] CharSelect cursor %u -> empty (roster[%u]=0x%02X)",
                       (unsigned)cursorPos, (unsigned)cursorPos, (unsigned)charIdx);
            return;
        }
        // Inline name lookup (GetCharacterNameByPortrait defined later in file)
        static const char* JUNC_CHAR_NAMES[] = {
            "Squall", "Zell", "Irvine", "Quistis", "Rinoa", "Selphie", "Seifer", "Edea",
            "Laguna", "Kiros", "Ward"
        };
        // v0.17.8.17.7: Dream-party name fix (same model as victory screen). The
        // formation index (charIdx, e.g. [5,0,1] = Selphie/Squall/Zell) is the
        // STALE regular party during a Laguna dream; the dream character's data
        // is loaded into char-data[charIdx], whose model_id (+0x08) reads 8/9/10
        // for Laguna/Kiros/Ward. Prefer model_id when it names a dream member,
        // else fall back to the formation index (unchanged for normal play, where
        // model_id == charIdx for the 8 mains). The modelId is added to the log
        // line below so a dream BAT confirms the value without a separate diag.
        uint8_t modelId = *(sm + 0x48C + charIdx * 0x98 + 0x08);
        const char* name;
        if (modelId >= 8 && modelId <= 10) name = JUNC_CHAR_NAMES[modelId];
        else                               name = (charIdx < 11) ? JUNC_CHAR_NAMES[charIdx] : "Unknown";
        
        // Get HP from computed stats (0x1CFF000, stride 0x1D0, curHP +0x172, maxHP +0x174)
        // Map charIdx to party slot via party array
        uint16_t curHP = 0, maxHP = 0;
        for (int s = 0; s < 3; s++) {
            if (party[s] == charIdx) {
                uint8_t* cs = (uint8_t*)0x1CFF000 + s * 0x1D0;
                uint16_t csMax = *(uint16_t*)(cs + 0x174);
                if (csMax > 0 && csMax < 10000) {
                    curHP = *(uint16_t*)(cs + 0x172);
                    maxHP = csMax;
                }
                break;
            }
        }
        // v0.18.2.14: reserve (not in the battle formation) -> the menu's per-
        // character HP display array at pMenuStateA+0x71E (stride 0x20, curHP +0,
        // maxHP +2, indexed by character index; the #47 benched-capable source).
        if (maxHP == 0) {
            uint8_t* hp = (uint8_t*)pMenuStateA + 0x71E + (int)charIdx * 0x20;
            uint16_t dCur = *(uint16_t*)(hp + 0x00);
            uint16_t dMax = *(uint16_t*)(hp + 0x02);
            Log::Menu("[JuncTTS] CharSelect reserve HP[+71E idx %u]: cur=%u max=%u",
                       (unsigned)charIdx, (unsigned)dCur, (unsigned)dMax);
            if (dMax > 0 && dMax < 10000) { curHP = dCur; maxHP = dMax; }
        }
        // Final fallback: savemap character struct (curHP live; savemap maxHP is 0)
        if (charIdx < 8) {
            uint8_t* smChar = sm + 0x48C + charIdx * 0x98;
            if (curHP == 0) curHP = *(uint16_t*)(smChar + 0x00);
            if (maxHP == 0) maxHP = *(uint16_t*)(smChar + 0x02);
        }
        
        // Get level from EXP (FF8: level = EXP/1000 + 1)
        uint8_t* charData = sm + 0x48C + charIdx * 0x98;
        uint32_t exp = *(uint32_t*)(charData + 0x04);
        int level = ComputeCharLevel(exp);
        
        char mbuf[256];
        if (maxHP > 0)
            sprintf(mbuf, "%s, Level %d, HP %u of %u", name, level, (unsigned)curHP, (unsigned)maxHP);
        else
            sprintf(mbuf, "%s, Level %d, HP %u", name, level, (unsigned)curHP);

        // v0.18.2.22: prepend the active/reserve grouping legend (start cues only)
        // in the SAME utterance — a separate Speak would interrupt it away. "Active"
        // = the char is in the battle formation (savemap+0xAF0); else "Reserve".
        const char* groupPrefix = "";
        if (announceGroup) {
            bool isActive = false;
            for (int gs = 0; gs < 3; gs++) { if (party[gs] == charIdx) { isActive = true; break; } }
            int group = isActive ? 1 : 2;
            if (group != s_charSelPrevGroup) {
                groupPrefix = isActive ? "Active Party. " : "Reserve Party. ";
                s_charSelPrevGroup = group;
            }
        }
        char buf[320];
        sprintf(buf, "%s%s", groupPrefix, mbuf);
        
        ScreenReader::Speak(buf, true);
        s_juncCharSelSpoke = charIdx;   // consumed by the Junction character watcher
        Log::Menu("[JuncTTS] CharSelect: %s (cursor=%u roster[%u]=%u modelId=%u)",
                   buf, (unsigned)cursorPos, (unsigned)cursorPos, (unsigned)charIdx, (unsigned)modelId);
    } __except(EXCEPTION_EXECUTE_HANDLER) {
        Log::Menu("[JuncTTS] Exception in AnnounceJuncCharSelect");
    }
}

// SEH-safe: Get GF name by index (0-15). Reads from savemap GF struct.
// GFs at savemap +0x4C, 16 × 68 bytes. Name at +0x00 (12 bytes, FF8-encoded).
// Exists flag at +0x11.
static const char* GetGfName(uint8_t gfIdx, char* nameBuf, int bufSize)
{
    if (gfIdx >= GF_COUNT) return "Unknown GF";
    
    __try {
        uint8_t* sm = (uint8_t*)0x1CFDC5C;  // SAVEMAP_BASE
        uint8_t* gf = sm + 0x4C + gfIdx * GF_STRUCT_SIZE;
        uint8_t exists = gf[0x11];
        
        if (!exists) return GF_DEFAULT_NAMES[gfIdx];  // shouldn't appear in list, but fallback
        
        // Decode GF name from FF8 encoding.
        // GF names in live savemap use +0x20 offset (same as save files).
        // Subtract 0x20 from each non-zero byte before decoding.
        int pos = 0;
        for (int i = 0; i < 12 && pos < bufSize - 1; i++) {
            uint8_t raw = gf[i];
            uint8_t c = (raw >= 0x20) ? (raw - 0x20) : raw;
            if (c == 0x00) { nameBuf[pos++] = ' '; }
            else if (c >= 0x01 && c <= 0x0A) { nameBuf[pos++] = '0' + (c - 0x01); }
            else if (c >= 0x25 && c <= 0x3E) { nameBuf[pos++] = 'A' + (c - 0x25); }
            else if (c >= 0x3F && c <= 0x58) { nameBuf[pos++] = 'a' + (c - 0x3F); }
            else break;  // terminator or unknown
        }
        while (pos > 0 && nameBuf[pos-1] == ' ') pos--;
        nameBuf[pos] = '\0';
        
        if (pos > 0) return nameBuf;
        return GF_DEFAULT_NAMES[gfIdx];  // empty name, use default
    } __except(EXCEPTION_EXECUTE_HANDLER) {
        return GF_DEFAULT_NAMES[gfIdx];
    }
}

// Check if a GF is currently junctioned to the selected character.
// Reads character's GF bitmask from savemap character struct +0x58 (uint16).
static bool IsGfJunctioned(uint8_t gfIdx, uint8_t charIdx)
{
    if (gfIdx >= GF_COUNT || charIdx > 7) return false;
    __try {
        uint8_t* sm = (uint8_t*)0x1CFDC5C;
        uint8_t* chr = sm + 0x48C + charIdx * 0x98;
        uint16_t gfMask = *(uint16_t*)(chr + 0x58);
        return (gfMask & (1 << gfIdx)) != 0;
    } __except(EXCEPTION_EXECUTE_HANDLER) {
        return false;
    }
}

// Find which character (if any) has a GF junctioned. Returns charIdx 0-7 or 0xFF if none.
static uint8_t FindGfOwner(uint8_t gfIdx)
{
    if (gfIdx >= GF_COUNT) return 0xFF;
    __try {
        uint8_t* sm = (uint8_t*)0x1CFDC5C;
        for (int c = 0; c < 8; c++) {
            uint8_t* chr = sm + 0x48C + c * 0x98;
            uint16_t gfMask = *(uint16_t*)(chr + 0x58);
            if (gfMask & (1 << gfIdx)) return (uint8_t)c;
        }
    } __except(EXCEPTION_EXECUTE_HANDLER) {}
    return 0xFF;
}

// Get the currently selected character index from the Junction char cursor.
// v0.09.41: Read formation[cursor] directly — cursor indexes the formation array.
static uint8_t GetJuncSelectedCharIdx()
{
    __try {
        uint8_t* base = (uint8_t*)pMenuStateA;
        uint8_t* roster = base + 0x1DB;  // v0.18.2.14: cursor indexes the roster (incl. reserves)
        uint8_t cursor = base[JUNC_CHARSEL_CURSOR_OFF];
        if (cursor <= 7) {
            uint8_t charIdx = roster[cursor];
            if (charIdx != 0xFF && charIdx <= 10) return charIdx;
        }
        // v0.09.49: Engine rewrites formation during Junction editing.
        // Fall back to cached charIdx from char select.
        if (s_juncSelectedCharIdx != 0xFF) return s_juncSelectedCharIdx;
    } __except(EXCEPTION_EXECUTE_HANDLER) {}
    return 0xFF;
}

// v0.23.0 (#82): BuildAbilityRightPanel lived here. It reconstructed the
// available-ability list by unioning the junctioned GFs' completeAbilities
// bitmaps and filtering by id range (20-38 for a command slot, 39-82 for an
// ability slot) -- which is exactly what the game's own builder at 0x004E0110
// does, into 0x01D8B258 and 0x01D8B280. Since the cursor indexes THOSE arrays,
// the reconstruction was a second opinion that could only ever agree or be
// wrong, so it is gone and the focus==28 block reads the arrays directly.

// Main Junction submenu poller — called every frame while top-level cursor == 0
// Gate: +0x1E8==17 means Junction subsystem is active. This is set when the
// player confirms Junction from the top menu. Character select happens while
// +0x1E8==17 AND focus==0. The subsystem flag is the reliable entry indicator.
static void PollJunctionSubmenu()
{
    if (!pMenuStateA) return;
    
    __try {
        uint8_t* base = (uint8_t*)pMenuStateA;
        uint8_t juncActiveFlag = base[JUNC_ACTIVE_OFFSET];
        uint8_t focus = base[JUNC_FOCUS_OFFSET];
        
        // Detect Junction subsystem activation (+0x1E8 transitions to 17)
        if (juncActiveFlag == 17 && !s_juncActive) {
            s_juncActive = true;
            s_juncPrevCharCursor = 0xFF;  // force announce on first poll
            s_juncPrevFocus = 0xFF;
            s_juncPrevActionCursor = 0xFF;
            s_juncCharSelectAnnounced = false;
            // v0.09.49: Cache GF bitmasks for ALL characters NOW,
            // before the engine zeroes them during Junction editing.
            // The user can switch characters without leaving Junction,
            // so we need all masks upfront.
            {
                uint8_t* sm2 = (uint8_t*)0x1CFDC5C;
                for (int ci = 0; ci < 8; ci++) {
                    s_juncCachedGfMasks[ci] = *(uint16_t*)(sm2 + 0x48C + ci * 0x98 + 0x58);
                }
                Log::Menu("[JuncTTS] Cached GF bitmasks: [%04X %04X %04X %04X %04X %04X %04X %04X]",
                           (unsigned)s_juncCachedGfMasks[0], (unsigned)s_juncCachedGfMasks[1],
                           (unsigned)s_juncCachedGfMasks[2], (unsigned)s_juncCachedGfMasks[3],
                           (unsigned)s_juncCachedGfMasks[4], (unsigned)s_juncCachedGfMasks[5],
                           (unsigned)s_juncCachedGfMasks[6], (unsigned)s_juncCachedGfMasks[7]);
            }
            Log::Menu("[JuncTTS] Junction subsystem activated (+0x1E8=17)");
            ResetCharSelGroup();  // v0.18.2.22: fresh active/reserve grouping for this visit
            JuncAutoBP_Arm();  // v0.18.2.6: arm the HW write BP that detects Auto-submenu confirms
        }
        
        // Detect Junction subsystem deactivation
        // Back-out from Junction returns to the top-level menu (Junction/Item/etc),
        // so the top-level cursor handler will announce the menu item.
        if (juncActiveFlag != 17 && s_juncActive) {
            Log::Menu("[JuncTTS] Junction subsystem deactivated (+0x1E8=%u)",
                       (unsigned)juncActiveFlag);
            ResetJunctionState();
            return;
        }
        
        if (!s_juncActive) return;
        
        // DEBUG: Log unhandled focus states.
        // v0.23.3: 49..62 are the grid, the magic list and their slide/scroll
        // states, and PollJunctionStats owns all of them -- logging them as
        // "unhandled" made a solved screen read like a hole in the next BAT log.
        if (focus != 0 && focus != 3 && focus != 8 && focus != 11 && focus != 37 && focus != 38 && focus != 41 &&
            !(focus >= 20 && focus <= 28) && !(focus >= 49 && focus <= 62)) {
            static uint8_t s_lastLoggedFocus = 0xFF;
            if (focus != s_lastLoggedFocus) {
                s_lastLoggedFocus = focus;
                Log::Menu("[JuncTTS] Unhandled focus=%u +271=%u +272=%u +275=%u",
                           (unsigned)focus, (unsigned)base[0x271], (unsigned)base[0x272], (unsigned)base[0x275]);
            }
        }
        
        // ---- Auto submenu CLOSED — resolve apply vs cancel at the action menu ----
        // Confirm and cancel both leave the Auto submenu (focus 11) via the same
        // path (11 -> char-select 8 -> action menu 3), so the focus path can't tell
        // them apart. Mark "pending" on the way out and decide at the action menu
        // (focus==3 block) from whether the auto-junction routine ran (the HW
        // write-BP flag). While pending, the
        // char-select re-announce is muted so it can't precede the confirmation.
        if (s_juncPrevFocus == JUNC_AUTO_FOCUS && (focus == 0 || focus == 8) &&
            s_juncPrevAutoCursor < JUNC_AUTO_OPT_COUNT) {
            s_juncAutoConfirmPending = true;
            s_juncAutoConfirmOpt     = s_juncPrevAutoCursor;
            Log::Menu("[JuncTTS] AutoMenu closed: opt=%u (focus %u->%u), awaiting apply check",
                       (unsigned)s_juncAutoConfirmOpt, (unsigned)s_juncPrevFocus, (unsigned)focus);
        }

        // ---- Ability Screen (focus 20-28 range) ----
        // v0.09.45: Confirmed via v0.09.44 diagnostic:
        //   LEFT panel:  focus=28, cursor at +0x271 (equipped command/ability slots)
        //   RIGHT panel: focus=24, cursor at +0x27C (available abilities from GFs)
        //   Other focus values (21, 22, 26, 27) are transitions — ignore.
        if (focus >= 20 && focus <= 28) {
            // Detect panel transitions (focus changes between 24 and 28)
            // Only re-announce when switching BETWEEN panels (24↔ 28), not on
            // first entry from outside the 20-28 range (avoids transition artifact
            // where focus passes through 28 briefly when entering from action menu).
            if (focus != s_juncPrevAbilFocus) {
                bool fromOtherPanel = (s_juncPrevAbilFocus == ABIL_LEFT_FOCUS ||
                                       s_juncPrevAbilFocus == ABIL_RIGHT_FOCUS);
                if (focus == ABIL_LEFT_FOCUS && fromOtherPanel) {
                    s_juncPrevAbilLeftCursor = 0xFF;  // force re-announce on left entry
                    Log::Menu("[AbilTTS] -> LEFT panel (focus=%u)", (unsigned)focus);
                }
                if (focus == ABIL_RIGHT_FOCUS && fromOtherPanel) {
                    s_juncPrevAbilRightCursor = 0xFF;  // force re-announce on right entry
                    Log::Menu("[AbilTTS] -> RIGHT panel (focus=%u, leftCursor=%u)",
                               (unsigned)focus, (unsigned)s_abilLastLeftCursor);
                }
                s_juncPrevAbilFocus = focus;
            }

            // LEFT PANEL (focus=24): read equipped ability from savemap
            if (focus == ABIL_LEFT_FOCUS) {
                uint8_t cursor = base[ABIL_LEFT_CURSOR_OFF];
                if (cursor != s_juncPrevAbilLeftCursor) {
                    s_juncPrevAbilLeftCursor = cursor;
                    s_abilLastLeftCursor = cursor;  // v0.09.48: track for right panel filtering
                    __try {
                        uint8_t charIdx = GetJuncSelectedCharIdx();
                        if (charIdx <= 7) {
                            uint8_t* sm = (uint8_t*)0x1CFDC5C;
                            uint8_t* chr = sm + 0x48C + charIdx * 0x98;
                            uint8_t abilId = 0;
                            // Slot layout: cursor 0-2 = commands[0-2], cursor 3-6 = abilities[0-3]
                            if (cursor <= 2) {
                                abilId = chr[0x50 + cursor];
                            } else if (cursor >= 3 && cursor <= 6) {
                                abilId = chr[0x54 + (cursor - 3)];
                            }
                            const char* name = (abilId == 0) ? "Empty" : GetAbilityName(abilId);
                            ScreenReader::Speak(name, true);
                            Log::Menu("[AbilTTS] LEFT slot %u: id=%u -> %s",
                                       (unsigned)cursor, (unsigned)abilId, name);
                        }
                    } __except(EXCEPTION_EXECUTE_HANDLER) {}
                }
            }

            // RIGHT PANEL (focus=28): available abilities from junctioned GFs.
            //
            // v0.23.0 (#82) -- THE CHARACTER-ABILITY LIST WAS READING A CURSOR
            // THAT HAD STOPPED MOVING. The state-28 handler at 0x004DAE12
            // addresses its cursor as `module[0x52 + kind]`, where kind (module
            // +0x56 = pMenuStateA + 0x274) is 1 for the COMMAND list and 2 for
            // the CHARACTER list. The command list is therefore +0x271 -- which
            // is what this block read, and why commands worked -- and the
            // character list is +0x272, which nothing read at all. Aaron: *"the
            // character and party abilities list (command abilities are hooked
            // already)"*. That sentence describes this exact off-by-one.
            //
            // The list CONTENTS now come from the game's own arrays too. The
            // builder at 0x004E0110 unions the junctioned GFs' completeAbilities
            // bitmaps into 0x01D8B580, then walks ids 20..38 into 0x01D8B258
            // (count 0x01D8B690) and ids 39..82 into 0x01D8B280 (count
            // 0x01D8B691), as {id, nameIdx} pairs. BuildAbilityRightPanel
            // reconstructed the same membership from the same bitmaps, which was
            // a fair guess -- but a reconstruction can agree on membership and
            // still disagree on ORDER, and order is the only thing a cursor
            // index means. Reading the array the cursor actually indexes cannot
            // be off by one, so the reconstruction is gone.
            if (focus == ABIL_RIGHT_FOCUS) {
                uint8_t kind   = base[JUNC_ABIL_KIND_OFF];
                uint8_t cursor = 0;
                int     count  = 0;
                int     abilId = -1;
                if (kind == 1 || kind == 2) {
                    cursor = base[JUNC_ABIL_CUR_OFF + kind];
                    const uint8_t* list = (const uint8_t*)
                        (kind == 1 ? JUNC_ABIL_CMD_LIST : JUNC_ABIL_CHAR_LIST);
                    count = (kind == 1)
                          ? (int)(*(const uint32_t*)JUNC_ABIL_CMD_COUNT & 0xFF)
                          : (int)(*(const uint8_t*)JUNC_ABIL_CHAR_COUNT);
                    if (count > 0 && cursor < count) abilId = (int)list[cursor * 2];

                    // The remembered position folds in the KIND, so switching
                    // lists always re-announces instead of looking like "the
                    // cursor did not move".
                    uint8_t sig = (uint8_t)((kind << 6) | (cursor & 0x3F));
                    if (sig != s_juncPrevAbilRightCursor) {
                        s_juncPrevAbilRightCursor = sig;
                        const char* name = (abilId >= 0) ? GetAbilityName((uint8_t)abilId) : "Empty";
                        ScreenReader::Speak(name, true);
                        Log::Menu("[AbilTTS] RIGHT kind=%u cursor=%u/%d: id=%d -> %s",
                                   (unsigned)kind, (unsigned)cursor, count, abilId, name);
                    }
                }
            }
        }
        
        // ---- Character Select (focus == 0 or 8) ----
        // v0.09.41: focus=8 is char select after Switch rearrangement.
        // focus=0 is the normal char select on first entry.
        //
        // v0.23.3: the "force re-announce on return from deeper" reset used to
        // live at the END of this function, which announced the character TWICE
        // on every return -- once with the stale cursor still matching, then
        // again on the next frame after the reset. The BAT log has it plainly:
        // two identical "CharSelect: Irvine, Level 19, HP 522 of 1837" lines in
        // the same second, at 17:39:45 and again at 17:40:23. Doing the reset
        // BEFORE the announce makes the arrival frame the only one that speaks.
        if ((focus == 0 || focus == 8) &&
            s_juncPrevFocus != 0 && s_juncPrevFocus != 8 && s_juncPrevFocus != 0xFF &&
            !s_juncAutoConfirmPending) {
            s_juncPrevCharCursor = 0xFF;
        }
        if (focus == 0 || focus == 8) {
            uint8_t charCursor = base[JUNC_CHARSEL_CURSOR_OFF];
            if (s_juncAutoConfirmPending) {
                // Auto submenu just closed; this char-select hop is transient and
                // resolves at the action menu. Stay silent and keep prev in sync.
                s_juncPrevCharCursor = charCursor;
            } else if (charCursor <= 7 && charCursor != s_juncPrevCharCursor) {
                AnnounceJuncCharSelect(charCursor, true);
                // v0.09.49: Cache the resolved charIdx NOW, while formation is still intact.
                // The engine rewrites the formation array once Junction editing starts.
                {
                    uint8_t ci = GetJuncSelectedCharIdx();
                    if (ci != 0xFF) s_juncSelectedCharIdx = ci;
                }
                s_juncPrevCharCursor = charCursor;
                s_juncCharSelectAnnounced = true;
            }
            // Reset action menu state when back on char select
            s_juncPrevActionCursor = 0xFF;
        }
        
        // ---- Action Menu (focus == 3) ----
        if (focus == 3) {
            uint8_t actionCursor = base[JUNC_ACTION_CURSOR_OFF];
            bool spokeConfirm = false;

            // Resolve a just-closed Auto submenu. The HW write-BP set
            // s_juncAutoRoutineRan iff the game's auto-junction routine ran while
            // the submenu was focused, which happens on a CONFIRM (even a no-op
            // confirm) and never on a cancel. Set => speak the confirmation (and
            // suppress the action re-announce). Clear => it was a cancel; say
            // nothing here and let the normal action announce run below.
            if (s_juncAutoConfirmPending) {
                bool applied = s_juncAutoRoutineRan;
                if (applied) {
                    const char* opt = (s_juncAutoConfirmOpt < JUNC_AUTO_OPT_COUNT)
                                      ? JUNC_AUTO_OPT_NAMES[s_juncAutoConfirmOpt] : "";
                    char abuf[64];
                    sprintf(abuf, "Junctioned automatically for %s", opt);
                    ScreenReader::Speak(abuf, true);
                    Log::Menu("[JuncTTS] AutoApplied: %s (confirm detected)", opt);
                    s_juncPrevActionCursor = actionCursor;  // suppress the action re-announce
                    spokeConfirm = true;
                } else {
                    Log::Menu("[JuncTTS] AutoMenu cancelled (auto-junction routine "
                              "did not run) opt=%u",
                              (unsigned)s_juncAutoConfirmOpt);
                }
                s_juncAutoConfirmPending = false;
                s_juncAutoConfirmOpt     = 0xFF;
                s_juncAutoRoutineRan     = false;
            }

            // Announce on entry to action menu OR cursor change
            if (!spokeConfirm && actionCursor < JUNC_ACTION_COUNT) {
                if (s_juncPrevFocus != 3 || actionCursor != s_juncPrevActionCursor) {
                    const char* actionName = JUNC_ACTION_NAMES[actionCursor];
                    ScreenReader::Speak(actionName, true);
                    Log::Menu("[JuncTTS] ActionMenu: %s (cursor=%u)",
                               actionName, (unsigned)actionCursor);
                    s_juncPrevActionCursor = actionCursor;
                }
            }
            // Reset other cursors when in action menu
            s_juncPrevCharCursor = 0xFF;
            s_juncPrevSuboptCursor = 0xFF;
            s_juncPrevGfListCursor = 0xFF;
            // v0.09.48: Reset Ability screen state so re-entry announces correctly
            s_juncPrevAbilLeftCursor = 0xFF;
            s_juncPrevAbilRightCursor = 0xFF;
            s_juncPrevAbilFocus = 0xFF;
        }

        // ---- Auto-junction submenu (focus == 11) ----
        // Confirming "Auto" from the action menu opens a 3-option submenu
        // (Atk/Mag/Def) selected by +0x26A; focus stays 11 throughout. Announce
        // the option + what it optimizes on entry and on cursor change.
        if (focus == JUNC_AUTO_FOCUS) {
            // On entry, clear the apply flag so the action-menu resolution can
            // tell this Auto session's confirm (write-BP sets it) from a cancel.
            if (s_juncPrevFocus != JUNC_AUTO_FOCUS) {
                s_juncAutoRoutineRan = false;  // fresh apply-window; the write-BP sets it on a confirm
            }
            uint8_t autoCursor = base[JUNC_AUTO_CURSOR_OFF];
            if (autoCursor < JUNC_AUTO_OPT_COUNT &&
                (s_juncPrevFocus != JUNC_AUTO_FOCUS || autoCursor != s_juncPrevAutoCursor)) {
                ScreenReader::Speak(JUNC_AUTO_OPT_NAMES[autoCursor], true);
                Log::Menu("[JuncTTS] AutoMenu: %s (cursor=%u)",
                           JUNC_AUTO_OPT_NAMES[autoCursor], (unsigned)autoCursor);
                s_juncPrevAutoCursor = autoCursor;
            }
        }
        
        // ---- Junction Sub-option (focus == 37 or 38) ----
        // Player chose "Junction" from action menu, now picks GF or Magic
        if (focus == 37 || focus == 38) {
            uint8_t suboptCursor = base[JUNC_SUBOPTION_CURSOR_OFF];
            if (suboptCursor <= 1 && suboptCursor != s_juncPrevSuboptCursor) {
                ScreenReader::Speak(JUNC_SUBOPTION_NAMES[suboptCursor], true);
                Log::Menu("[JuncTTS] SubOption: %s (cursor=%u focus=%u)",
                           JUNC_SUBOPTION_NAMES[suboptCursor], (unsigned)suboptCursor, (unsigned)focus);
                s_juncPrevSuboptCursor = suboptCursor;
            }
            // Reset GF list cursor for fresh entry
            s_juncPrevGfListCursor = 0xFF;
            s_juncPrevGfToggle = 0xFF;
        }
        
        // ---- GF List (focus == 41) ----
        // Player is browsing the GF list to junction/unjunction.
        // +0x26D cursor indexes into OBTAINED GFs only (not all 16).
        // Must build obtained-GF list and map cursor to real GF index.
        if (focus == 41) {
            uint8_t gfCursor = base[JUNC_GF_LIST_CURSOR_OFF];
            uint8_t gfToggle = base[JUNC_GF_TOGGLE_OFF];
            
            // Build list of obtained GF indices
            // Diagnostic: dump exists flags for all 16 GFs on first entry
            static bool s_gfDiagDone = false;
            uint8_t obtainedGfs[GF_COUNT];
            int obtainedCount = 0;
            __try {
                uint8_t* sm = (uint8_t*)0x1CFDC5C;
                if (!s_gfDiagDone) {
                    s_gfDiagDone = true;
                    char diag[512] = {};
                    int dp = 0;
                    dp += sprintf(diag + dp, "[JuncTTS] GF exists dump: ");
                    for (int g = 0; g < GF_COUNT && dp < 480; g++) {
                        uint8_t* gfs = sm + 0x4C + g * GF_STRUCT_SIZE;
                        dp += sprintf(diag + dp, "%d:[%02X,%02X,%02X,%02X] ",
                                      g, gfs[0x10], gfs[0x11], gfs[0x12], gfs[0x13]);
                    }
                    Log::Menu("%s", diag);
                }
                for (int g = 0; g < GF_COUNT; g++) {
                    uint8_t* gfStruct = sm + 0x4C + g * GF_STRUCT_SIZE;
                    if (gfStruct[0x11] != 0)  // exists flag
                        obtainedGfs[obtainedCount++] = (uint8_t)g;
                }
            } __except(EXCEPTION_EXECUTE_HANDLER) {}
            
            // Map cursor to real GF index
            uint8_t realGfIdx = (gfCursor < obtainedCount) ? obtainedGfs[gfCursor] : 0xFF;
            
            if (realGfIdx < GF_COUNT && gfCursor != s_juncPrevGfListCursor) {
                char nameBuf[32];
                const char* gfName = GetGfName(realGfIdx, nameBuf, sizeof(nameBuf));
                
                // Check who owns this GF
                static const char* JUNC_CHAR_NAMES2[] = {
                    "Squall", "Zell", "Irvine", "Quistis", "Rinoa", "Selphie", "Seifer", "Edea",
                    "Laguna", "Kiros", "Ward"
                };
                uint8_t owner = FindGfOwner(realGfIdx);
                uint8_t selChar = GetJuncSelectedCharIdx();
                // v0.17.8.17.7: dream-aware owner name. owner is a regular char
                // index (0-7) from FindGfOwner; during a dream the dream member's
                // struct is loaded into char-data[owner] and its model_id (+0x08)
                // reads 8/9/10. Map through that so "on <name>" says Laguna/Kiros/
                // Ward, not the stale regular name. (Literal savemap addr used
                // because the shared resolver is defined in a later include.)
                uint8_t ownerName = owner;
                if (owner < 11) {
                    __try {
                        uint8_t m = *((uint8_t*)0x1CFDC5C + 0x48C + owner * 0x98 + 0x08);
                        if (m >= 8 && m <= 10) ownerName = m;
                    } __except(EXCEPTION_EXECUTE_HANDLER) {}
                }
                
                char buf[128];
                if (owner != 0xFF && owner == selChar) {
                    sprintf(buf, "%s, junctioned", gfName);
                } else if (owner != 0xFF && owner < 11) {
                    sprintf(buf, "%s, on %s", gfName, JUNC_CHAR_NAMES2[ownerName]);
                } else {
                    sprintf(buf, "%s", gfName);
                }
                
                ScreenReader::Speak(buf, true);
                Log::Menu("[JuncTTS] GFList: %s (cursor=%u realIdx=%u owner=%u selChar=%u)",
                           buf, (unsigned)gfCursor, (unsigned)realGfIdx, (unsigned)owner, (unsigned)selChar);
                s_juncPrevGfListCursor = gfCursor;
                s_juncPrevGfToggle = gfToggle;
            }
            // Detect toggle change (junction/unjunction) on same GF
            else if (realGfIdx < GF_COUNT && gfToggle != s_juncPrevGfToggle && s_juncPrevGfToggle != 0xFF) {
                char nameBuf[32];
                const char* gfName = GetGfName(realGfIdx, nameBuf, sizeof(nameBuf));
                const char* action = (gfToggle == 1) ? "junctioned" : "removed";
                
                char buf[128];
                sprintf(buf, "%s %s", gfName, action);
                ScreenReader::Speak(buf, true);
                Log::Menu("[JuncTTS] GFToggle: %s (toggle %u->%u)",
                           buf, (unsigned)s_juncPrevGfToggle, (unsigned)gfToggle);
                s_juncPrevGfToggle = gfToggle;
            }
        }
        
        // (The "returning to char select" re-announce reset now runs ABOVE the
        //  announce block -- see the v0.23.3 note there.)
        
        // Reset sub-phase cursors when leaving those phases
        if (focus != 37 && focus != 38 && s_juncPrevFocus >= 37 && s_juncPrevFocus <= 38) {
            s_juncPrevSuboptCursor = 0xFF;
        }
        if (focus != 41 && s_juncPrevFocus == 41) {
            s_juncPrevGfListCursor = 0xFF;
            s_juncPrevGfToggle = 0xFF;
        }
        if (focus != JUNC_AUTO_FOCUS && s_juncPrevFocus == JUNC_AUTO_FOCUS) {
            s_juncPrevAutoCursor = 0xFF;
        }
        
        // Track focus changes for transition detection
        s_juncPrevFocus = focus;
        
    } __except(EXCEPTION_EXECUTE_HANDLER) {
        Log::Menu("[JuncTTS] Exception in PollJunctionSubmenu");
    }
}

// (/) On-demand help for the Junction Auto submenu option under the cursor.
// Returns true (and speaks the help) ONLY while the Auto submenu is up, so the
// "/" dispatch chain in MenuTTS::Update() falls through to the normal help bar
// everywhere else. Mirrors GFSpeakSelectedAbilityHelp()/AbilitySpeakSelectedHelp().
// Reads focus/cursor live (the / hotkey fires earlier in the frame than
// PollJunctionSubmenu, so the stashed prev-cursor could lag). SEH-safe.
static bool JunctionAutoSpeakHelp()
{
    if (!s_juncActive || !pMenuStateA) return false;
    __try {
        uint8_t* base = (uint8_t*)pMenuStateA;
        if (base[JUNC_ACTIVE_OFFSET] != 17) return false;
        if (base[JUNC_FOCUS_OFFSET] != JUNC_AUTO_FOCUS) return false;
        uint8_t cur = base[JUNC_AUTO_CURSOR_OFF];
        if (cur >= JUNC_AUTO_OPT_COUNT) return false;
        ScreenReader::Speak(JUNC_AUTO_OPT_HELP[cur], true);
        Log::Menu("[JuncTTS] AutoHelp (/): cursor=%u \"%s\"", (unsigned)cur, JUNC_AUTO_OPT_HELP[cur]);
        return true;
    } __except(EXCEPTION_EXECUTE_HANDLER) { return false; }
}

// F12 diagnostic: track menu_draw_text / get_character_width call counts
static bool     s_diagActive = false;
static DWORD    s_diagLastLogTime = 0;
static int      s_diagScanCount = 0;
static const int DIAG_SCAN_MAX = 60;  // 60 x 500ms = 30 seconds
static LONG     s_diagPrevMDT = 0;   // previous menu_draw_text count
static LONG     s_diagPrevGCW = 0;   // previous get_character_width count

// ============================================================================
