// world_map_trigger_data.inl - Static trigger-program data + logger
//
// PART OF world_map.cpp -- TEXTUAL INCLUDE. Do NOT compile standalone.
//
// Holds the 38 decoded field-entry trigger programs from wmsetus.obj
// Section 8. The data was originally hex-dumped at v0.14.92, decoded by
// Python (decode_wmsetus_section8.py) for v0.14.93, and embedded here as
// a static C++ array. Each program describes one possible field-entry
// destination keyed by location ID, with an optional top-level vehicle/
// story gate plus one or more clauses (each carrying its own vehicle
// predicate, region operand, story window, and unknown-flag bits).
//
// Layout (sized by trigger_data.inl):
//   - TRIG_VEH_*  / TRIG_UNK_*  scalar constants
//   - TriggerClause / TriggerProgram structs
//   - s_cl00 ... s_cl37 (38 individual clause arrays)
//   - s_triggerPrograms[] table -- the entry point read by AD's planner
//   - TRIGGER_PROGRAM_COUNT
//   - LogTriggerPrograms (init-time diagnostic dump)
//
// NOTE: s_triggerPrograms[].top_story_gte for entry 9 was changed from
// 290 to 0 in v0.14.98 (Balamb Town planner-decline fix). The original
// disassembler had put 0xFF02 0x0122 in the wrong scope; corrected here.

static const uint16_t TRIG_VEH_ANY        = 0x0000;
static const uint16_t TRIG_VEH_FOOT       = 0x0080;
static const uint16_t TRIG_VEH_FOOT_ALT   = 0x0084;
static const uint16_t TRIG_VEH_GARDEN     = 0x0030;
static const uint16_t TRIG_VEH_CHOCOBO    = 0x0031;
static const uint16_t TRIG_VEH_RAGNAROK   = 0x0032;

static const uint16_t TRIG_UNK_0F = 0x0001;
static const uint16_t TRIG_UNK_10 = 0x0002;
static const uint16_t TRIG_UNK_11 = 0x0004;
static const uint16_t TRIG_UNK_12 = 0x0008;
static const uint16_t TRIG_UNK_13 = 0x0010;
static const uint16_t TRIG_UNK_20 = 0x0020;
static const uint16_t TRIG_UNK_21 = 0x0040;

struct TriggerClause {
    uint16_t vehicle;     // TRIG_VEH_* constant; 0 = any (used when top-level vehicle is set)
    uint16_t region;      // segment region-byte to match against Section 2
    uint16_t story_gte;   // savemap-word lower bound (0 = none)
    uint16_t story_lt;    // savemap-word upper bound (0 = +inf)
    uint16_t unk_flags;   // bitmask of UNK opcodes present in original clause (TRIG_UNK_*)
};

struct TriggerProgram {
    uint16_t loc_id;          // wmField/location ID from 0xFF06
    uint16_t top_story_gte;   // top-level story gate lower bound (0 = none)
    uint16_t top_story_lt;    // top-level story gate upper bound (0 = +inf)
    uint16_t top_vehicle;     // top-level vehicle restriction (TRIG_VEH_*; 0 = none)
    uint8_t  num_clauses;     // count of entries in clauses[]
    const TriggerClause* clauses;
};

// 38 per-program clause arrays. The array index matches s_triggerPrograms[]
// index for cross-reference to the decoded artifact (which uses the same
// idx column). s_clNN means "clauses for program NN." When num_clauses == 0
// (program 18, the late-game Chocobo-only mobile destination with top-level
// vehicle restriction and no inner-clause requirements), the pointer is
// nullptr and there is no s_cl18 array.
static const TriggerClause s_cl00[] = {
    { TRIG_VEH_FOOT,    0x14, 0,    0,    0 },
    { TRIG_VEH_CHOCOBO, 0x14, 0,    0,    0 },
};
static const TriggerClause s_cl01[] = {
    { TRIG_VEH_FOOT,    0x21, 0,    0,    0 },
    { TRIG_VEH_CHOCOBO, 0x21, 0,    0,    0 },
};
static const TriggerClause s_cl02[] = {
    { TRIG_VEH_FOOT,    0x22, 0,    0,    0 },
    { TRIG_VEH_CHOCOBO, 0x22, 0,    0,    0 },
};
static const TriggerClause s_cl03[] = {
    { TRIG_VEH_FOOT,    0x13, 0,    0,    0 },
    { TRIG_VEH_CHOCOBO, 0x13, 0,    0,    0 },
};
static const TriggerClause s_cl04[] = {
    { TRIG_VEH_FOOT,    0x13, 0,    0,    TRIG_UNK_12 },
    { TRIG_VEH_CHOCOBO, 0x13, 0,    0,    TRIG_UNK_12 },
    { TRIG_VEH_FOOT,    0x23, 0,    0,    TRIG_UNK_10 },
    { TRIG_VEH_CHOCOBO, 0x23, 0,    0,    TRIG_UNK_10 },
};
static const TriggerClause s_cl05[] = {
    { TRIG_VEH_FOOT,    0x24, 0,    0,    0 },
    { TRIG_VEH_CHOCOBO, 0x24, 0,    0,    0 },
};
static const TriggerClause s_cl06[] = {
    { TRIG_VEH_FOOT, 0x09, 0,    0,    0 },
};
static const TriggerClause s_cl07[] = {
    { TRIG_VEH_FOOT,     0x03, 0,    0,    0 },
    { TRIG_VEH_FOOT_ALT, 0x03, 0,    0,    0 },
};
static const TriggerClause s_cl08[] = {
    { TRIG_VEH_FOOT,     0x08, 0,    0,    0 },
    { TRIG_VEH_FOOT_ALT, 0x08, 0,    0,    0 },
};
static const TriggerClause s_cl09[] = {
    // Heavy UNK flags on r=0x06; cleaner path on r=0x07.
    { TRIG_VEH_FOOT, 0x06, 0,    490,  TRIG_UNK_11 | TRIG_UNK_0F | TRIG_UNK_12 | TRIG_UNK_10 },
    { TRIG_VEH_FOOT, 0x07, 0,    3900, TRIG_UNK_12 },
};
static const TriggerClause s_cl10[] = {
    { TRIG_VEH_FOOT, 0x05, 290,  315,  0 },
};
static const TriggerClause s_cl11[] = {
    { TRIG_VEH_FOOT,     0x01, 0,    0,    0 },
    { TRIG_VEH_FOOT_ALT, 0x01, 0,    0,    0 },
};
static const TriggerClause s_cl12[] = {
    { TRIG_VEH_FOOT, 0x00, 0,    0,    0 },
};
static const TriggerClause s_cl13[] = {
    { TRIG_VEH_FOOT, 0x02, 0,    0,    TRIG_UNK_11 },
    { TRIG_VEH_FOOT, 0x00, 0,    570,  TRIG_UNK_0F },
};
static const TriggerClause s_cl14[] = {
    { TRIG_VEH_FOOT,    0x16, 0,    0,    TRIG_UNK_0F },
    { TRIG_VEH_CHOCOBO, 0x16, 0,    0,    TRIG_UNK_0F },
    { TRIG_VEH_FOOT,    0x17, 0,    0,    TRIG_UNK_11 },
    { TRIG_VEH_CHOCOBO, 0x17, 0,    0,    TRIG_UNK_11 },
};
static const TriggerClause s_cl15[] = {
    { TRIG_VEH_FOOT,     0x0B, 0,    0,    TRIG_UNK_12 },
    { TRIG_VEH_FOOT_ALT, 0x0B, 0,    0,    TRIG_UNK_12 },
};
static const TriggerClause s_cl16[] = {
    { TRIG_VEH_FOOT,     0x0A, 0,    0,    0 },
    { TRIG_VEH_FOOT_ALT, 0x0A, 0,    0,    0 },
};
static const TriggerClause s_cl17[] = {
    { TRIG_VEH_FOOT, 0x04, 0,    0,    0 },
};
// program 18 (locID 0x0172, story>=3900, topVeh=Chocobo): no inner clauses
// — the top-level vehicle restriction alone defines the trigger.
static const TriggerClause s_cl19[] = {
    { TRIG_VEH_ANY, 0x0D, 0,    3900, TRIG_UNK_20 },
};
static const TriggerClause s_cl20[] = {
    { TRIG_VEH_ANY, 0x0C, 0,    3900, 0 },
};
static const TriggerClause s_cl21[] = {
    { TRIG_VEH_FOOT, 0x18, 0,    3000, 0 },
    { TRIG_VEH_FOOT, 0x2E, 3000, 3900, 0 },
};
static const TriggerClause s_cl22[] = {
    { TRIG_VEH_FOOT, 0x19, 0,    0,    0 },
};
static const TriggerClause s_cl23[] = {
    { TRIG_VEH_FOOT, 0x1C, 0,    3000, 0 },
    { TRIG_VEH_FOOT, 0x39, 3000, 5000, 0 },
};
static const TriggerClause s_cl24[] = {
    { TRIG_VEH_FOOT, 0x0E, 0,    0,    TRIG_UNK_11 },
    { TRIG_VEH_FOOT, 0x0F, 0,    0,    TRIG_UNK_0F },
};
static const TriggerClause s_cl25[] = {
    // Multi-vehicle late-game evolution; most complex program in Section 8.
    { TRIG_VEH_RAGNAROK, 0x1B, 0,    3000, TRIG_UNK_0F | TRIG_UNK_20 },
    { TRIG_VEH_RAGNAROK, 0x44, 3000, 3900, TRIG_UNK_0F | TRIG_UNK_20 },
    { TRIG_VEH_CHOCOBO,  0x44, 3900, 0,    TRIG_UNK_0F },
    { TRIG_VEH_FOOT,     0x1A, 0,    3900, TRIG_UNK_11 },
    { TRIG_VEH_FOOT_ALT, 0x1A, 0,    3900, TRIG_UNK_11 },
};
static const TriggerClause s_cl26[] = {
    { TRIG_VEH_FOOT,     0x1A, 0,    3900, 0 },
    { TRIG_VEH_FOOT_ALT, 0x1A, 0,    3900, 0 },
};
static const TriggerClause s_cl27[] = {
    { TRIG_VEH_FOOT,     0x1A, 0,    3900, 0 },
    { TRIG_VEH_FOOT_ALT, 0x1A, 0,    3900, 0 },
};
static const TriggerClause s_cl28[] = {
    { TRIG_VEH_FOOT,     0x1A, 0,    3900, 0 },
    { TRIG_VEH_FOOT_ALT, 0x1A, 0,    3900, 0 },
};
static const TriggerClause s_cl29[] = {
    { TRIG_VEH_FOOT, 0x1E, 0,    3000, 0 },
    { TRIG_VEH_FOOT, 0x45, 3000, 0,    0 },
};
static const TriggerClause s_cl30[] = {
    { TRIG_VEH_FOOT, 0x1D, 0,    3000, 0 },
    { TRIG_VEH_FOOT, 0x2F, 0,    0,    0 },
};
static const TriggerClause s_cl31[] = {
    { TRIG_VEH_FOOT,    0x27, 0,    0,    0 },
    { TRIG_VEH_CHOCOBO, 0x27, 0,    0,    0 },
};
static const TriggerClause s_cl32[] = {
    // Esthar-candidate locID 0x01FA: 4 story-windowed regions
    // (region cycles 0x1F -> 0x30 -> 0x31 -> 0x1F across story 0..5000).
    { TRIG_VEH_FOOT, 0x1F, 0,    2500, 0 },
    { TRIG_VEH_FOOT, 0x30, 2500, 3000, 0 },
    { TRIG_VEH_FOOT, 0x31, 3000, 3900, 0 },
    { TRIG_VEH_FOOT, 0x1F, 3900, 5000, 0 },
};
static const TriggerClause s_cl33[] = {
    { TRIG_VEH_FOOT,    0x10, 0,    0,    0 },
    { TRIG_VEH_CHOCOBO, 0x10, 0,    0,    0 },
};
static const TriggerClause s_cl34[] = {
    { TRIG_VEH_FOOT,    0x12, 0,    0,    0 },
    { TRIG_VEH_CHOCOBO, 0x12, 0,    0,    0 },
};
static const TriggerClause s_cl35[] = {
    { TRIG_VEH_FOOT,    0x26, 0,    0,    0 },
    { TRIG_VEH_CHOCOBO, 0x26, 0,    0,    0 },
};
static const TriggerClause s_cl36[] = {
    { TRIG_VEH_FOOT,    0x25, 0,    0,    0 },
    { TRIG_VEH_CHOCOBO, 0x25, 0,    0,    0 },
};
static const TriggerClause s_cl37[] = {
    { TRIG_VEH_ANY, 0x15, 0,    0,    TRIG_UNK_20 },
};

// Helper macro keeps the program table compact while letting the compiler
// derive num_clauses from the array's actual length — no risk of the
// hand-written count getting out of sync with the array size.
#define WMS_NCLS(arr)  ((uint8_t)(sizeof(arr) / sizeof(arr[0])))

static const TriggerProgram s_triggerPrograms[] = {
    // [00] locID=0x0031 story>=750 — foot/Choco region 0x14
    { 0x0031,  750,    0, TRIG_VEH_ANY,      WMS_NCLS(s_cl00), s_cl00 },
    // [01] locID=0x0051 — foot/Choco region 0x21
    { 0x0051,    0,    0, TRIG_VEH_ANY,      WMS_NCLS(s_cl01), s_cl01 },
    // [02] locID=0x0091 — foot/Choco region 0x22
    { 0x0091,    0,    0, TRIG_VEH_ANY,      WMS_NCLS(s_cl02), s_cl02 },
    // [03] locID=0x0095 story>=750 — foot/Choco region 0x13
    { 0x0095,  750,    0, TRIG_VEH_ANY,      WMS_NCLS(s_cl03), s_cl03 },
    // [04] locID=0x0096 story>=750 — 4 clauses with UNK flags (regions 0x13/0x23)
    { 0x0096,  750,    0, TRIG_VEH_ANY,      WMS_NCLS(s_cl04), s_cl04 },
    // [05] locID=0x00DB — foot/Choco region 0x24
    { 0x00DB,    0,    0, TRIG_VEH_ANY,      WMS_NCLS(s_cl05), s_cl05 },
    // [06] locID=0x00EA — foot region 0x09
    { 0x00EA,    0,    0, TRIG_VEH_ANY,      WMS_NCLS(s_cl06), s_cl06 },
    // [07] locID=0x00EE story>=36 — foot/footAlt region 0x03
    { 0x00EE,   36,    0, TRIG_VEH_ANY,      WMS_NCLS(s_cl07), s_cl07 },
    // [08] locID=0x0108 story>=333 — foot/footAlt region 0x08
    { 0x0108,  333,    0, TRIG_VEH_ANY,      WMS_NCLS(s_cl08), s_cl08 },
    // [09] locID=0x010B (Balamb Town) — v0.14.98 fix: top_story_gte changed
    //      from 290 to 0. See world_map_history.h for v0.14.98 narrative.
    { 0x010B,    0,    0, TRIG_VEH_ANY,      WMS_NCLS(s_cl09), s_cl09 },
    // [10] locID=0x010C — foot region 0x05 [story 290..315]
    { 0x010C,    0,    0, TRIG_VEH_ANY,      WMS_NCLS(s_cl10), s_cl10 },
    // [11] locID=0x0111 — foot/footAlt region 0x01
    { 0x0111,    0,    0, TRIG_VEH_ANY,      WMS_NCLS(s_cl11), s_cl11 },
    // [12] locID=0x0112 story<570 — foot region 0x00
    { 0x0112,    0,  570, TRIG_VEH_ANY,      WMS_NCLS(s_cl12), s_cl12 },
    // [13] locID=0x0113 — foot region 0x02 (UNK_11) OR foot region 0x00 [<570] (UNK_0F)
    { 0x0113,    0,    0, TRIG_VEH_ANY,      WMS_NCLS(s_cl13), s_cl13 },
    // [14] locID=0x0117 — 4 clauses regions 0x16/0x17 with UNK flags
    { 0x0117,    0,    0, TRIG_VEH_ANY,      WMS_NCLS(s_cl14), s_cl14 },
    // [15] locID=0x0147 story 350..490 — foot/footAlt region 0x0B (UNK_12)
    { 0x0147,  350,  490, TRIG_VEH_ANY,      WMS_NCLS(s_cl15), s_cl15 },
    // [16] locID=0x0169 story>=350 — foot/footAlt region 0x0A
    { 0x0169,  350,    0, TRIG_VEH_ANY,      WMS_NCLS(s_cl16), s_cl16 },
    // [17] locID=0x016D story>=205 — foot region 0x04
    { 0x016D,  205,    0, TRIG_VEH_ANY,      WMS_NCLS(s_cl17), s_cl17 },
    // [18] locID=0x0172 story>=3900 topVeh=Chocobo — NO inner clauses (mobile destination)
    { 0x0172, 3900,    0, TRIG_VEH_CHOCOBO,  0,                 nullptr },
    // [19] locID=0x0172 story>=636 topVeh=Ragnarok — region 0x0D [<3900] +UNK_20
    { 0x0172,  636,    0, TRIG_VEH_RAGNAROK, WMS_NCLS(s_cl19), s_cl19 },
    // [20] locID=0x0172 story>=636 topVeh=Garden — region 0x0C [<3900]
    { 0x0172,  636,    0, TRIG_VEH_GARDEN,   WMS_NCLS(s_cl20), s_cl20 },
    // [21] locID=0x0175 story>=1600 — foot region 0x18 [<3000] OR 0x2E [3000..3900]
    { 0x0175, 1600,    0, TRIG_VEH_ANY,      WMS_NCLS(s_cl21), s_cl21 },
    // [22] locID=0x0176 — foot region 0x19
    { 0x0176,    0,    0, TRIG_VEH_ANY,      WMS_NCLS(s_cl22), s_cl22 },
    // [23] locID=0x017A story>=1750 — foot region 0x1C [<3000] OR 0x39 [3000..5000]
    { 0x017A, 1750,    0, TRIG_VEH_ANY,      WMS_NCLS(s_cl23), s_cl23 },
    // [24] locID=0x0189 story>=750 — foot regions 0x0E (UNK_11) / 0x0F (UNK_0F)
    { 0x0189,  750,    0, TRIG_VEH_ANY,      WMS_NCLS(s_cl24), s_cl24 },
    // [25] locID=0x0196 story>=1750 — 5 clauses, multi-vehicle late-game evolution
    { 0x0196, 1750,    0, TRIG_VEH_ANY,      WMS_NCLS(s_cl25), s_cl25 },
    // [26] locID=0x0197 story>=1750 — foot/footAlt region 0x1A [<3900]
    { 0x0197, 1750,    0, TRIG_VEH_ANY,      WMS_NCLS(s_cl26), s_cl26 },
    // [27] locID=0x01B6 story>=1750 — foot/footAlt region 0x1A [<3900]
    { 0x01B6, 1750,    0, TRIG_VEH_ANY,      WMS_NCLS(s_cl27), s_cl27 },
    // [28] locID=0x01B7 story>=1750 — foot/footAlt region 0x1A [<3900]
    { 0x01B7, 1750,    0, TRIG_VEH_ANY,      WMS_NCLS(s_cl28), s_cl28 },
    // [29] locID=0x01B9 story>=1750 — foot region 0x1E [<3000] OR 0x45 [3000..]
    { 0x01B9, 1750,    0, TRIG_VEH_ANY,      WMS_NCLS(s_cl29), s_cl29 },
    // [30] locID=0x01BB story>=1750 — foot region 0x1D [<3000] OR 0x2F
    { 0x01BB, 1750,    0, TRIG_VEH_ANY,      WMS_NCLS(s_cl30), s_cl30 },
    // [31] locID=0x01D2 — foot/Choco region 0x27
    { 0x01D2,    0,    0, TRIG_VEH_ANY,      WMS_NCLS(s_cl31), s_cl31 },
    // [32] locID=0x01FA story>=1750 — 4 story-windowed regions (Esthar candidate)
    { 0x01FA, 1750,    0, TRIG_VEH_ANY,      WMS_NCLS(s_cl32), s_cl32 },
    // [33] locID=0x0250 — foot/Choco region 0x10
    { 0x0250,    0,    0, TRIG_VEH_ANY,      WMS_NCLS(s_cl33), s_cl33 },
    // [34] locID=0x028C story>=900 — foot/Choco region 0x12
    { 0x028C,  900,    0, TRIG_VEH_ANY,      WMS_NCLS(s_cl34), s_cl34 },
    // [35] locID=0x028D — foot/Choco region 0x26
    { 0x028D,    0,    0, TRIG_VEH_ANY,      WMS_NCLS(s_cl35), s_cl35 },
    // [36] locID=0x02B5 — foot/Choco region 0x25
    { 0x02B5,    0,    0, TRIG_VEH_ANY,      WMS_NCLS(s_cl36), s_cl36 },
    // [37] locID=0x02C1 topVeh=Ragnarok — region 0x15 (UNK_20)
    { 0x02C1,    0,    0, TRIG_VEH_RAGNAROK, WMS_NCLS(s_cl37), s_cl37 },
};
static const int TRIGGER_PROGRAM_COUNT = sizeof(s_triggerPrograms) / sizeof(s_triggerPrograms[0]);

// ============================================================================
// LogTriggerPrograms — walks s_triggerPrograms[] at module init and emits one
// log line per program for runtime sanity-check that the embedded v0.14.93
// trigger data compiled correctly into the binary.
// ============================================================================
static void LogTriggerPrograms()
{
    int totalClauses = 0;
    for (int i = 0; i < TRIGGER_PROGRAM_COUNT; i++) {
        totalClauses += s_triggerPrograms[i].num_clauses;
    }
    Log::World("WorldMap: [TRIGGER-PROGRAMS] count=%d totalClauses=%d (sanity check that embedded data compiled)",
               TRIGGER_PROGRAM_COUNT, totalClauses);

    for (int i = 0; i < TRIGGER_PROGRAM_COUNT; i++) {
        const TriggerProgram& p = s_triggerPrograms[i];

        char gateBuf[40];
        if (p.top_story_gte == 0 && p.top_story_lt == 0) {
            snprintf(gateBuf, sizeof(gateBuf), "any");
        } else if (p.top_story_lt == 0) {
            snprintf(gateBuf, sizeof(gateBuf), "[%u,inf)", (unsigned)p.top_story_gte);
        } else if (p.top_story_gte == 0) {
            snprintf(gateBuf, sizeof(gateBuf), "[0,%u)", (unsigned)p.top_story_lt);
        } else {
            snprintf(gateBuf, sizeof(gateBuf), "[%u,%u)",
                     (unsigned)p.top_story_gte, (unsigned)p.top_story_lt);
        }

        char clausesBuf[768];
        clausesBuf[0] = '\0';
        size_t cpos = 0;

        if (p.num_clauses == 0 || p.clauses == nullptr) {
            snprintf(clausesBuf, sizeof(clausesBuf), "(none)");
        } else {
            for (uint8_t k = 0; k < p.num_clauses; k++) {
                const TriggerClause& c = p.clauses[k];

                char storyB[40];
                if (c.story_gte == 0 && c.story_lt == 0) {
                    storyB[0] = '\0';
                } else if (c.story_lt == 0) {
                    snprintf(storyB, sizeof(storyB), ",s=[%u,inf)", (unsigned)c.story_gte);
                } else if (c.story_gte == 0) {
                    snprintf(storyB, sizeof(storyB), ",s=[0,%u)", (unsigned)c.story_lt);
                } else {
                    snprintf(storyB, sizeof(storyB), ",s=[%u,%u)",
                             (unsigned)c.story_gte, (unsigned)c.story_lt);
                }

                char unkB[20];
                if (c.unk_flags == 0) {
                    unkB[0] = '\0';
                } else {
                    snprintf(unkB, sizeof(unkB), ",unk=0x%04X", (unsigned)c.unk_flags);
                }

                int written = snprintf(clausesBuf + cpos,
                                       sizeof(clausesBuf) - cpos,
                                       "%s(v=0x%02X,r=0x%02X%s%s)",
                                       (k == 0) ? "" : ",",
                                       (unsigned)c.vehicle, (unsigned)c.region,
                                       storyB, unkB);
                if (written < 0 || (size_t)written >= sizeof(clausesBuf) - cpos) {
                    break;
                }
                cpos += (size_t)written;
            }
        }

        Log::World("WorldMap: [TRIGGER-PROGRAMS] [%02d] loc=0x%04X storyGate=%s topVeh=0x%02X clauses=%u: [%s]",
                   i, (unsigned)p.loc_id, gateBuf, (unsigned)p.top_vehicle,
                   (unsigned)p.num_clauses, clausesBuf);
    }
}

// ============================================================================
// v0.18.3.206: DECODED ENTRY FIRING AREAS (offline/TRIGGER_FIRING_AREAS.md).
// The trigger system is now FULLY decoded from the exe + wmsetus Section 8:
// a field entry fires only while standing on a wmx poly with byte14 bit 3 set
// (hand-painted entry polys at each gate mouth), inside the program's 8192u
// segment, within the clause's sub-segment coordinate bounds, with the vehicle
// and story gates satisfied. The former "unknown" predicate bits were the
// sub-segment bounds; 0xFF08 is the destination ACTION, not a region test.
// This table holds, per catalog destination, a VALIDATED aim point inside the
// firing area plus the area's bbox: aim = drive-target override; bbox = the
// final-approach mow zone (replaces the blind orbit, which at Timber circled
// radius 610-1330u around a firing patch that lies entirely within 432u --
// the orbit had a hole exactly where the target was). Validated against the
// .205 log: Dollet's successful entry fired ON its area edge; every failed
// Timber orbit position lies OUTSIDE its area.
struct EntryAimInfo {
    const char* name;         // catalog name (matched against s_driveTargetName)
    int32_t     aimX, aimY;   // validated point inside the firing area
    int32_t     x0, x1;       // area bbox x [min,max]
    int32_t     y0, y1;       // area bbox y [min,max]
    bool        footOnly;     // no FOOT_ALT clause: cannot be entered by car
};
// ----------------------------------------------------------------------------
// v0.21.6 (#79): THE TABLE WAS RIGHT AND SEVEN ROWS LONG.
//
// The comment above has said since v0.18.3.206 that an entry fires only while
// standing on a wmx poly with byte 14 bit 3 set. Three sessions of Edea's House
// hunting then went looking for a story gate, a "master gate" and a destination
// table -- and the v0.21.5 [TRIGWALK] interpreter reproduced that same blind
// spot: it models the 8192u SEGMENT and the clause bounds, so it printed MATCH
// at every one of Aaron's positions across a whole 8 km square. The real
// positional gate is per-POLYGON, and this table is where it lives. It was never
// wrong. It was seven rows long, and Edea's House was not one of them.
//
// So the rows below are now GENERATED from wmx.obj instead of hand-found
// (offline/gen_entryaims.py):
//
//   1. every polygon with byte 0x0E bit 3 set              -> 7,359 map-wide
//   2. keep only those also foot-walkable, byte 0x0F bit 7 -> 2,877
//   3. flood-fill into patches; take the patch nearest the catalog marker
//   4. aim = the interior sample farthest from the patch edge, so an approach
//      that overshoots by tens of units still lands on a trigger
//
// Cross-check, which is why this is trustworthy: run the generator against the
// five hand-proven aims above and it returns Timber within 91u, Dollet 54u,
// Balamb Town 47u, Fire Cavern 83u, Galbadia Station 379u -- every one inside
// its own proven bbox. tests/entryaim_test.cpp keeps that honest.
//
// **WHY EDEA'S HOUSE REFUSED.** Segment 652 holds 103 entry polys and only
// SEVEN are foot-walkable -- the other 96 are inside walls the move validator
// will not let Squall stand on. Those seven cover x[-29975,-29310]
// y[69632,70078]: about 665 x 446 units, roughly a three-hundredth of the
// segment. The catalog marker was (-28950,70090), 234 units east of the patch,
// off the only ground that can open the door. In the 2026-08-16 BAT Aaron's
// closest approach was (-29144,70004) -- 287 units short. Every gate the exe
// names passed on every frame because they all genuinely did pass; he was never
// standing on a trigger polygon. The aim below sits 140 units inside the patch
// in every direction.
//
// Only destinations whose generated aim is within 800u of the existing marker
// are added -- "the marker is just outside its own door", which is unambiguous.
// Deling City (1,966u), Great Salt Lake (1,717u), D-District Prison (1,462u),
// Trabia Garden (1,443u) and Winhill (1,234u) also have patches, but a retarget
// that large deserves its own BAT; they are listed in
// docs/WORLDMAP_ENTRY_POLYGONS.md and deliberately NOT shipped yet.
// ----------------------------------------------------------------------------
static const EntryAimInfo s_entryAims[] = {
    // --- hand-proven in the field; left exactly as they were ---
    { "Timber",           -22580,  -5291, -22685, -22371,  -5632,  -5120, true  },
    { "Dollet",           -14513, -39119, -15409, -13516, -39951, -38175, false },
    { "Balamb Town",       12560, -26800,  12288,  12884, -26896, -26624, false },
    { "Balamb Garden",     24304, -30300,  23552,  25410, -31370, -29696, true  },
    { "Fire Cavern",       30239, -29528,  30112,  30394, -29750, -29192, true  },
    { "Galbadia Garden",  -36895, -27082, -37764, -35964, -28036, -26236, true  },
    { "Galbadia Station", -38914, -24767, -39426, -38398, -24936, -24682, true  },
    // --- v0.21.6: generated from the entry polygons (patch tris / edge margin) ---
    { "Edea's House",     -29459,  69772, -29975, -29310,  69632,  70078, true  },   //   7 tris, margin 140, marker was 600u out
    { "Tomb of the Unknown King",
                          -42011, -36843, -42335, -41648, -37163, -36541, true  },   //  64 tris, margin 204, marker 539u
    { "Centra Ruins",       6143,  55295,   5632,   6656,  54784,  55808, true  },   // 291 tris, margin 259, marker 744u
    { "Shumi Village",     12743, -84026,  12638,  12800, -84341, -83625, true  },   //   8 tris, margin  50, marker  58u (the v0.20 marker fix lands inside)
    { "Chocobo Forest 1",  11507, -64253,  11099,  11971, -64679, -63828, true  },   //  32 tris, margin 294, marker 619u
    { "Chocobo Forest 2",  10740, -80384,  10326,  11199, -80810, -79959, true  },   //  32 tris, margin 294, marker 653u
    { "Chocobo Forest 4",  97792, -48650,  97316,  98267, -49140, -48140, true  },   //  98 tris, margin 336, marker 671u
    { "Chocobo Forest 5",  17908,  22528,  17494,  18367,  22102,  22953, true  },   //  32 tris, margin 294, marker 735u
    { "Chocobo Forest 6",  44020,  75776,  43606,  44479,  75350,  76201, true  },   //  32 tris, margin 294, marker 684u
    { "Chocobo Forest 7", -21004,  69632, -21418, -20545,  69206,  70057, true  },   //  32 tris, margin 294, marker 728u -- the known-good control
    // ------------------------------------------------------------------------
    // v0.21.7: THE FIVE HELD-BACK RETARGETS, RESOLVED FROM THE PROGRAM TABLE.
    //
    // v0.21.6 assigned patches to destinations by nearest centroid, which is a
    // guess, so anything needing a 1-2 km move was held back. The authority is
    // not distance: **a patch sits in a SEGMENT, a segment has exactly one entry
    // PROGRAM, and that program names its destinations with clause bounds.**
    //
    //   Deling City        seg 264  prog 8   dest 8   story>=333  no bound
    //   D-District Prison  seg 361  prog 16  dest 10  story>=350  no bound
    //   Trabia Garden      seg 149  prog 3   dest 19  story>=750  no bound
    //   Winhill            seg 393  prog 24  dest 14/15  story>=750  SPLIT
    //   Great Salt Lake    seg 373  prog 21  dest 24  story>=1600 foot only
    //
    // Each of the first four markers is IN the segment its patch is in, so the
    // binding is not an inference -- the door and the icon are in the same
    // 8192-unit square and the square has one program. The 1-2 km is just how
    // far a city icon sits from its gate.
    //
    // **WINHILL WAS THE ONE WORTH HOLDING BACK.** Program 24 splits segment 393
    // at Xoff 6144: destination 14 on the high side, 15 on the low. The v0.21.6
    // generated aim was at Xoff 5825 -- the LOW half, a different destination
    // from the one the marker (Xoff 7059) sits over. Taking the interior point
    // of the whole patch would have shipped a confidently-wrong coordinate of
    // exactly the kind this table exists to stop. The aim below is restricted to
    // the high side and its whole bbox clears the split (Xoff 6147 at its west
    // edge). The low half is deliberately not covered, so the planner does not
    // treat it as a no-go zone for other routes.
    //
    // **GREAT SALT LAKE vs CHOCOBO FOREST 3, settled.** Program 21 has NO
    // chocobo clause and a story>=1600 gate. Every chocobo forest's program has
    // a vehicle-49 clause and no story gate at all (progs 1, 2, 5, 31, 35, 36).
    // So segment 373 is not a forest, and the patch is Great Salt Lake's -- which
    // fits a location that opens after the Lunar Cry. Chocobo Forest 3's marker
    // is in segment 374, whose program (22) is also foot-only, and segment 374
    // has no walkable entry polygon at all. That marker is wrong and its real
    // home is an open question, not a guess to ship -- see the doc.
    //
    // footOnly is now DERIVED rather than judged: a program with a vehicle-132
    // (FOOT_ALT) clause can be entered by car. That rule reproduces all seven
    // hand-set flags above -- Dollet and Balamb Town have 132 and are false;
    // Timber, Fire Cavern and Galbadia Station do not and are true.
    //
    // Great Salt Lake's gate is story>=1600 and Aaron is at 912, so that row is
    // correct but cannot be BAT-confirmed until much later in the game. Shipped
    // anyway: it is strictly better than the marker it replaces and cannot
    // regress anything that does not already refuse.
    // ------------------------------------------------------------------------
    { "Deling City",       -61947, -30631, -62453, -60616, -31456, -29696, false },   //  48 tris, margin 374, marker 1,966u -- prog 8 dest 8
    { "D-District Prison", -55308,  -6296, -55743, -54858,  -6556,  -5741, false },   // 260 tris, margin 195 -- prog 16 dest 10. SEE THE PRISON NOTE BELOW: this door never opens.
    // v0.21.8: Trabia's firing area is BOTH segments, not one. See the note below.
    { "Trabia Garden",      49096, -59393,  48128,  50176, -60416, -58368, true  },   // 366 tris across segs 149+150, margin 737 -- prog 3 dest 19 unconditional, prog 4 dest 19 where Yoff>4096
    { "Winhill",           -51071,   6326, -51199, -50679,   6200,   6464, true  },   //   6 tris, margin 126 -- prog 24 dest 14, HIGH side of the Xoff 6144 split (bbox from vertices: Xoff 6145..6665)
    { "Great Salt Lake",    48248,  -2174,  48128,  48640,  -2294,  -2050, true  },   //  46 tris, margin 120 -- prog 21 dest 24, story>=1600 so untestable at story 912
    // ------------------------------------------------------------------------
    // v0.56.0 (#118): ESTHAR. FIVE MARKERS THAT COULD NEVER HAVE OPENED ANYTHING.
    //
    // Aaron reached disc 3 and drove to Lunar Gate. The walk worked -- 31 km,
    // arrived, `[DRIVE] Entered final approach zone (dist=982)` -- and then:
    //
    //     [TRIGWALK] tick seg=410 -- no entry program covers this square
    //
    // He was standing within 10 units of the catalog marker (88021,7865) and
    // segment 410 has no entry program at all. Checked against the shipped
    // polygons, ALL FIVE Esthar markers stand on ZERO foot-walkable entry
    // triangles; the five aims below each stand on exactly one. The old
    // coordinates were never measured -- their digits give them away
    // (...521/...021, ...865/...135) -- and three of them are not even in a
    // segment that has a door.
    //
    // WORLDMAP_ENTRY_POLYGONS.md listed all five under "no foot-walkable entry
    // polygon anywhere near them, which is correct -- they are not walked into".
    // **That conclusion was wrong.** Every one of them has a real patch; they
    // are 3.7-12.1 km from the markers, which is simply further than that scan
    // looked. The doc is corrected.
    //
    // Bound the same way v0.21.7 bound Deling City and the rest: a patch sits in
    // a SEGMENT, a segment has one entry PROGRAM, and that program names its
    // destinations. Two are facts (marker and patch in the same segment); three
    // are argued, and the argument is written down rather than hidden:
    //
    //   Sorceress Memorial  seg 441  prog 29  dest 30  story>=1750   FACT: the
    //     marker is in seg 441 and seg 441 has exactly one program. 248 walkable
    //     entry tris of 248 -- all of them, which is unusually clean.
    //   Tears' Point        seg 506  prog 32  dest 31  story>=1750   FACT: same
    //     shape. 24 tris in FOUR bars around a hollow centre; the aim is the
    //     SOUTH bar only, because the game's own arrival record for dest 31 sits
    //     272 units due south of it -- the approach the engine expects. The
    //     whole-ring bbox is 47% hole and is deliberately not what ships.
    //   Esthar City         segs 406/407/438/439, progs 25-28, all dest 26.
    //     ARGUED, and strongly: those four segments are a contiguous 2x2 block
    //     holding eight door patches in mirror pairs about the 406/407|438/439
    //     seam -- one structure straddling four squares, which is exactly why it
    //     needs four programs, and exactly what a city with four gates looks
    //     like. The aim is the seg-438 gate, the one the engine's own arrival
    //     record 26 sits 263 units north of.
    //   Lunatic Pandora Lab seg 378  prog 23  dest 28  story>=1750
    //   Lunar Gate          seg 443  prog 30  dest 29  story>=1750
    //     ARGUED. Segment/marker co-location settles the first three, leaving
    //     two names and two doors, and no single-segment fact pins which is
    //     which. Four independent arguments agree, and the fourth is the one
    //     worth the ink: the FIELD NAMES. Destination 28's fields are `edlabo*`
    //     and `edmoor*` -- laboratory, and the mooring Lunatic Pandora sits in.
    //     Destination 29's are `escont1`, `escouse*`, `esform1`, `esfreez1` --
    //     and the Lunar Gate is where you are sealed into a cryogenic capsule
    //     before launch. The other three arguments are displacement (7.4/7.7 km
    //     this way, 11.4/25.5 km swapped -- larger than any wrong marker ever
    //     found in this project), the relative orientation of the two markers
    //     being preserved in both axes, and segment adjacency.
    //
    //     IF THE PAIR IS SWAPPED, ONE BAT SAYS SO AND THE FIX IS TWO LINES: the
    //     `[DRIVE] Arrival via game-mode` line prints fieldName. `edlabo`/
    //     `edmoor`/`edview` is the Laboratory; `escont`/`escouse`/`esform`/
    //     `esfreez`/`esview` is the Gate. The geometry is right either way --
    //     only the two labels would move.
    //
    // Story: all five programs are gated story>=1750 and Aaron is at 2000, so
    // all five are live now. The clause selected changes at 2500 (Tears' Point),
    // 3000 (Lab, Gate, Memorial) and 3900 (Esthar City), but the SEGMENTS AND
    // DOOR POLYGONS DO NOT MOVE, so these aims stay valid past those boundaries.
    //
    // footOnly is derived by the v0.21.7 rule (a vehicle-132 FOOT_ALT clause
    // makes a door car-enterable): only Esthar City has one.
    { "Esthar City",        56965,   9788,  56773,  57130,   9628,  10350, false },   //   4 tris, margin 136 -- prog 27 dest 26, marker was 12,083u out (seg 374, no polygons)
    { "Lunatic Pandora Lab",83966,  -3199,  83706,  84213,  -3435,  -3072, true  },   //   4 tris, margin 116 -- prog 23 dest 28, marker was  7,416u out (seg 345, no program)
    { "Lunar Gate",         95460,   9956,  95232,  97280,   9728,  10752, true  },   //  28 tris, margin 228 -- prog 30 dest 29, marker was  7,727u out (seg 410, the "no entry program covers this square" square)
    { "Sorceress Memorial", 77820,  12162,  76800,  78848,  10752,  13257, true  },   // 248 tris, margin 315 -- prog 29 dest 30, marker was  3,713u out
    { "Tears' Point",       86020,  25836,  85170,  86861,  25716,  26249, true  },   //   8 tris, margin 120 -- prog 32 dest 31, south bar of a four-bar ring, marker was 6,734u out
};
// ----------------------------------------------------------------------------
// v0.21.8: THREE THINGS THE 2026-08-16 BAT SAID.
//
// **TRABIA'S DOOR IS TWICE THE SIZE THIS TABLE CLAIMED.** v0.21.7 restricted the
// aim to segment 149, where program 3 grants destination 19 with no coordinate
// bound, because that was the conservative choice. But program 4 grants the SAME
// destination 19 in segment 150 whenever Yoff > 4096, and the patch runs straight
// across the seam: 194 walkable entry triangles in 149 and 172 more in 150. The
// BAT entered at (49966,-58834) -- Yoff 6702, comfortably past the split, in
// segment 150 -- which is 1,363 units from the v0.21.7 aim. The drive got in
// anyway because it passed through the eastern half on its way to the western
// one. Taking both halves moves the aim to the middle of the real 2048x2048 door
// and raises its edge margin from 418 to 737, the largest in the table.
//   The whole bbox is safe to treat as one rectangle: its y range is -60416 to
//   -58368, which is Yoff 5120 to 7168, so every part of it clears the 4096
//   split. Being conservative about a clause is right; being conservative about
//   which HALF of a door to aim at is just aiming at the far side.
//
// **THE D-DISTRICT PRISON DOOR NEVER OPENS.** Aaron: *"it is not possible to
// enter the D-District Prison. You can see it on the world map but can never
// enter it from the world map. It is entered via a story sequence triggered in
// Deling City."* The geometry here is real and correct -- program 16, 260
// walkable entry polygons, story >= 350, and the BAT drove onto them -- and no
// field loads. The prison is a mobile drilling rig that relocates and sinks
// during the story, so the likeliest reading is that its world-map presence is
// vestigial by disc 3. **The row stays deliberately**, for two reasons Aaron
// asked for: the drive still delivers the player to the gate for an equivalent
// experience, and the planner still routes other journeys around a real firing
// area. Do not read a future "arrived but nothing loaded" here as a regression.
//
// **WINHILL HAS TWO DOORS AND THIS IS THE RIGHT ONE.** Aaron: *"Winhill also has
// two entry points... the one that auto-drive took me to now is the one in the
// north part of town."* That is destination 14, the high side of the Xoff 6144
// split, field 0x029E -- the half v0.21.7 moved the aim onto, and the half the
// v0.21.6 whole-patch aim would have missed. Destination 15, the low side, is
// the other door and stays uncatalogued by his call. The bbox is now taken from
// the triangle VERTICES rather than the raster samples the aim search uses (the
// raster under-reports by up to one step); its west edge is Xoff 6145, one unit
// inside the clause, since Xoff exactly 6144 satisfies neither `> 6144` nor
// `< 6143` and would open no door at all.
// ----------------------------------------------------------------------------
static const int ENTRY_AIM_COUNT = (int)(sizeof(s_entryAims) / sizeof(s_entryAims[0]));
static int FindEntryAim(const char* name)
{
    for (int i = 0; i < ENTRY_AIM_COUNT; i++)
        if (strcmp(s_entryAims[i].name, name) == 0) return i;
    return -1;
}
