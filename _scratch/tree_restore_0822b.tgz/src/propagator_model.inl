// propagator_model.inl -- the PURE model of the Ragnarok Propagator puzzle
// (field set `rg*`, disc 3).
//
// PART OF field_navigation.cpp -- TEXTUAL INCLUDE. Do NOT compile standalone.
// Compiled standalone by tests/propagator_compile.cpp.
//
// ============================================================================
// THE PUZZLE, AND WHAT A BLIND PLAYER CANNOT SEE (#112)
// ============================================================================
//
// `rgguest2` msg 2 states the rule in the game's own words: *"So basically, we
// have to kill them in pairs that have the same colors, right?"* Eight
// Propagators, four colours, two of each. Kill two of a colour in a row and
// both stay dead; kill one of a colour and then one of another, and the first
// comes back.
//
// Aaron: *"There is also the question of how the blind player will know which
// is which color."* The colour is the only cue the game gives, and it is
// purely visual.
//
// ============================================================================
// THE PAIRING IS IN THE BYTECODE, AND THAT IS WHAT ACTUALLY SOLVES IT
// ============================================================================
//
// Three field variables run the whole rule:
//
//     var[445] 0x01CFEB75  bit 0x04 = a kill is pending (unmatched)
//     var[446] 0x01CFEB76  eight death bits, one per Propagator
//     var[447] 0x01CFEB77  the pending kill's own bit
//
// Each Propagator's `alien0N::default` tests `var[446] & OWN` to decide whether
// it still exists, and after winning its battle tests `var[447] & PARTNER` --
// "was the last unmatched kill my partner?". If not, `var[446] &= ~var[447]`
// revives that one. So the pairing is a fixed bit-partner table, read straight
// out of eight scripts:
//
//     rgair1   0x01 <-> 0x80  rgguest2      BATTLE 819 / 816
//     rgroad1  0x02 <-> 0x20  rghang2       BATTLE 815 / 815
//     rgroad2  0x04 <-> 0x08  rgroad3       BATTLE  85 /  85
//     rghang1  0x10 <-> 0x40  rgexit1       BATTLE 814 / 817
//
// **The mod announces the partner's location as well as the colour**, and that
// is deliberate: the partner is proven from bytecode, the colour is a label on
// top of it. If a colour name were ever wrong the puzzle would still be
// solvable from what the mod says.
//
// THE COLOURS come from the battle scenes: `0x069 BATTLE(enc, flags)` gives an
// encounter id, `scene.out` (battle.fs entry 64) gives its enemy slots at
// record offset 0x38 as monsterId + 0x10, and the four Propagator monsters'
// palettes peak at 89 = (96,24,240) purple, 97 = (152,240,24) green,
// 98 = (240,152,24) amber/yellow, 111 = (248,16,16) red. Two of those are
// corroborated by an outside source without being taken from it: a published
// walkthrough puts the yellow pair at the airlock and the passenger cabin,
// which is exactly `rgair1` and `rgguest2` -- the pair the bit table gives.
// The field models agree too: each field's alien has five texture pages whose
// palettes are byte-identical within a pair.
//
// A TRAP WORTH NAMING: `rgroad3` has a NINTH alien, entity `alien01`, that is
// cutscene-only and can never be fought. The fightable one there is `alien02`.
// A catalog that announced both would send the player hunting a phantom.
//
// THE PUZZLE ENDS when `var[446] == 255`, tested in exactly one place --
// `rgroad1 :: lift::talk` dwords 102-105 -- which then opens the lift. The game
// also has its OWN mercy rule: `var[437] > 24` forces `var[446] = 255`, so 25
// battles of any kind solve it. That is the only game-provided skip and the mod
// does not need to invent one.

static const int      PG_VAR_PENDFLAG = 445;          // bit 0x04 = a kill is pending
static const int      PG_VAR_DEAD     = 446;          // eight death bits
static const int      PG_VAR_PENDBIT  = 447;          // which one is pending
static const uint32_t PG_ADDR_PENDFLAG = 0x01CFEB75u;
static const uint32_t PG_ADDR_DEAD     = 0x01CFEB76u;
static const uint32_t PG_ADDR_PENDBIT  = 0x01CFEB77u;
static const uint8_t  PG_PENDING_MASK  = 0x04;
static const uint8_t  PG_ALL_DEAD      = 0xFF;

struct Propagator {
    const char* field;        // internal field name
    const char* entity;       // the .sym entity that IS the monster
    uint8_t     bit;          // its bit in var[446]
    uint8_t     partnerBit;   // the bit its script accepts as a match
    const char* colour;       // spoken colour
    const char* place;        // spoken location, for naming the partner
};

// One row per fightable Propagator. Ordered by bit so the table reads as the
// four pairs it is.
static const Propagator PG_LIST[] = {
    { "rgair1",   "alien01", 0x01, 0x80, "yellow", "the airlock"          },
    { "rgroad1",  "alien01", 0x02, 0x20, "green",  "the lift corridor"    },
    { "rgroad2",  "alien01", 0x04, 0x08, "red",    "the middle corridor"  },
    { "rgroad3",  "alien02", 0x08, 0x04, "red",    "the far corridor"     },
    { "rghang1",  "alien01", 0x10, 0x40, "purple", "the hangar"           },
    { "rghang2",  "alien01", 0x20, 0x02, "green",  "the far hangar"       },
    { "rgexit1",  "alien01", 0x40, 0x10, "purple", "the exit passage"     },
    { "rgguest2", "alien01", 0x80, 0x01, "yellow", "the passenger cabin"  },
};
static const int PG_COUNT = (int)(sizeof(PG_LIST) / sizeof(PG_LIST[0]));

// The cutscene-only decoy in rgroad3 -- never fightable, never announced.
static const char* PG_DECOY_FIELD  = "rgroad3";
static const char* PG_DECOY_ENTITY = "alien01";

static const Propagator* PgForField(const char* field)
{
    if (!field) return nullptr;
    for (int i = 0; i < PG_COUNT; i++)
        if (_stricmp(PG_LIST[i].field, field) == 0) return &PG_LIST[i];
    return nullptr;
}
static const Propagator* PgForBit(uint8_t bit)
{
    for (int i = 0; i < PG_COUNT; i++)
        if (PG_LIST[i].bit == bit) return &PG_LIST[i];
    return nullptr;
}
static bool PgIsRagnarokField(const char* field)
{
    return field && (field[0] == 'r' || field[0] == 'R') &&
                    (field[1] == 'g' || field[1] == 'G');
}
// Every table row's partner must itself point back, and both must agree on the
// colour. Cheap enough to assert at runtime as well as in the probe.
static bool PgTableConsistent()
{
    uint8_t seen = 0;
    for (int i = 0; i < PG_COUNT; i++) {
        const Propagator* p = &PG_LIST[i];
        if (p->bit == 0 || (seen & p->bit)) return false;
        seen = (uint8_t)(seen | p->bit);
        const Propagator* q = PgForBit(p->partnerBit);
        if (!q || q->partnerBit != p->bit) return false;
        if (_stricmp(q->colour, p->colour) != 0) return false;
    }
    return seen == PG_ALL_DEAD;
}

// What to say about the state of the hunt. `dead` is var[446], `pendBit` is
// var[447], `pending` is var[445] & 0x04.
static void PgStatusLine(uint8_t dead, uint8_t pendBit, bool pending,
                         char* out, size_t n)
{
    if (dead == PG_ALL_DEAD) { snprintf(out, n, "All eight are down. The lift is open."); return; }
    int left = 0;
    for (int i = 0; i < PG_COUNT; i++) if (!(dead & PG_LIST[i].bit)) left++;
    if (pending) {
        const Propagator* p = PgForBit(pendBit);
        const Propagator* q = p ? PgForBit(p->partnerBit) : nullptr;
        if (p && q) {
            snprintf(out, n, "%d left. A %s one is down and unmatched -- kill the other %s "
                             "one, in %s, next, or the first comes back.",
                     left, p->colour, q->colour, q->place);
            return;
        }
    }
    snprintf(out, n, "%d left. No kill is pending, so any one may be killed next.", left);
}

// What to say about the Propagator standing in this field.
static void PgHereLine(const Propagator* p, uint8_t dead, uint8_t pendBit, bool pending,
                       char* out, size_t n)
{
    if (!p) { snprintf(out, n, "No Propagator here."); return; }
    if (dead & p->bit) { snprintf(out, n, "The %s Propagator here is already down.", p->colour); return; }
    const Propagator* q = PgForBit(p->partnerBit);
    const bool partnerDown = q && (dead & q->bit);
    // MASK, not equality -- because that is what the script does:
    //     PSHM_B var[447] ; PSHN_L <partnerBit> ; OPER AND ; PSHN_L 0 ; OPER EQ
    // var[447] only ever holds a single bit today, so the two agree; matching
    // the game's own test costs nothing and cannot drift away from it.
    const bool matchesPending = pending && ((pendBit & p->partnerBit) != 0);
    if (matchesPending) {
        snprintf(out, n, "%s Propagator. This is the match for the pending kill -- "
                         "killing it now finishes the pair.", p->colour);
    } else if (pending) {
        const Propagator* pend = PgForBit(pendBit);
        snprintf(out, n, "%s Propagator. Do NOT kill it yet: a %s one is unmatched and "
                         "would come back. Its pair is in %s.",
                 p->colour, pend ? pend->colour : "another", q ? q->place : "another room");
    } else if (partnerDown) {
        snprintf(out, n, "%s Propagator. Its pair is already down and matched.", p->colour);
    } else {
        snprintf(out, n, "%s Propagator. Its pair is in %s.", p->colour, q ? q->place : "another room");
    }
}
