// world_map_state.inl - Module-level statics, type definitions, constants
//
// PART OF world_map.cpp -- TEXTUAL INCLUDE. Do NOT compile standalone.
//
// This file is included FIRST inside the WorldMap namespace by the slim
// world_map.cpp. Holds:
//   - Foundational type definitions (enums + structs) used by every other
//     .inl file: VehicleType, SegTerrainClass, LocationEntry.
//   - Address / dimension / sizing constants: WM_POS_*, WM_WIDTH/HEIGHT,
//     WMX_*, WMSETUS_*, MAX_LOCATIONS.
//   - All mutable module statics: refined-coord arrays, navigation state,
//     auto-drive state, terrain grid, segment-region map, drive path state,
//     s_destPlannerEligible[] (v0.16.0 planner-eligibility flag).
//
// Catalog data (s_locations[] + LOCATION_COUNT) lives in
// world_map_catalog.inl. To decouple state-array sizing from the catalog
// table size, this file defines MAX_LOCATIONS (a generous upper bound);
// catalog.inl asserts LOCATION_COUNT <= MAX_LOCATIONS at compile time.

// ============================================================================
// v0.18.3.101: Runtime walkability diagnostic gate
// ============================================================================
// Defined in state.inl (the first-included file) so both the variable
// declaration below AND the call sites in segments.inl / world_map.cpp
// all see the same macro value.
#define WM_RUNTIME_WALK_DIAG 1

// ============================================================================
// v0.18.3.104: Triangle-navmesh diagnostic gate (NON-INVASIVE port)
// ============================================================================
// Defined here (first-included file) so world_map_navmesh.inl's #if guard, the
// Reset/AddTriangle/Build calls in segments.inl, and Navmesh_LogConnectivity()
// in world_map.cpp all see the same value. LOCAL-ONLY while the navmesh is
// diagnostic-only (no routing depends on it yet -- the .99 chain still drives).
#define NAVMESH_DIAG 1
// v0.18.3.186: per-frame motion-fidelity capture ([MFRAME]) so the offline sim can learn the
// engine's exact wall-slide and its true ground height vs our oracle. Set to 0 to silence.
// v0.21.4: OFF. This emits ONE UNTHROTTLED [MFRAME] line per poll tick, and
// Log::World flushes synchronously -- 120-180 formatted file writes a second on
// the poll thread for the whole of every drive. It was built to feed the offline
// motion sim and that work is done; turn it on for a capture session, not for a
// shipped build.
#define WM_MOTION_DIAG 0

// ============================================================================
// v0.18.3.106: Navmesh routing toggle (#70 routing swap, stage 1)
// ============================================================================
// When 1, PlanDrivePath routes drives on the walkability-filtered triangle
// navmesh (A* ungated -> triangle path -> fine-cell waypoints the #68 executor
// consumes UNCHANGED) instead of the fine-grid clearance Dijkstra. When 0, the
// proven .99 fine-grid chain runs (instant revert). Requires NAVMESH_DIAG (the
// navmesh is built in LoadTerrainGrid under that gate). LOCAL-only this stage;
// the executor + .81/.85/#69 fine-grid stack are UNTOUCHED -- the BAT shows
// whether the executor follows the navmesh route or the old forward-guard
// fights it (the latter -> stage 2 retires the fine-grid stack).
#define NAVMESH_ROUTING 1

// ============================================================================
// Sizing upper bound for state arrays (v0.16.0)
// ============================================================================
// State arrays indexed by catalog slot are sized to MAX_LOCATIONS, NOT to
// LOCATION_COUNT directly. This decouples them from the s_locations[] table
// definition (in catalog.inl, which is included later) so that state.inl
// can be processed first. catalog.inl static_asserts that the actual catalog
// count fits. Current catalog has 37 entries; 64 leaves comfortable headroom
// for adding new destinations without re-sizing state.
static const int MAX_LOCATIONS = 64;

// ============================================================================
// Confirmed static addresses (from deep research + ff8-speedruns + v0.11.02 diag)
// ============================================================================
static const uint32_t WM_POS_X      = 0x0203EE80;  // DWORD - player X
static const uint32_t WM_POS_Y      = 0x0203EE84;  // DWORD - player Y
static const uint32_t WM_POS_Z      = 0x0203EE88;  // DWORD - player Z
static const uint32_t WM_HEADING    = 0x0203FE52;   // WORD  - 0=North, 0-4095 CW
// v0.18.3.201: world-map camera system (exe-verified; offline/CAMERA_EXE_ANALYSIS.md).
// The camera struct is 0x0203ECF8 (angles pitch/yaw/roll at +8/+0xA/+0xC); on foot the
// engine derives the move heading from the camera yaw inside 0x557A90 every tick:
// heading = camYaw + key*512 + triBias/2. So the camera yaw is the true steering lever.
static const uint32_t WM_CAM_YAW        = 0x0203ED02;  // WORD  - camera yaw (logic AND render yaw)
static const uint32_t WM_CAM_PITCH      = 0x0203ED00;  // WORD  - camera pitch (cosmetic)
static const uint32_t WM_CAM_VEL        = 0x0204DAE8;  // WORD  - camera yaw follow velocity (int16, clamp +-0x80; yaw += vel>>3)
static const uint32_t WM_TRI_BIAS       = 0x020409EC;  // WORD  - per-triangle heading bias (engine adds bias/2 on foot)
static const uint32_t WM_CAM_LOCK       = 0x020409E4;  // DWORD - region camera lock flag (1 = controller forces yaw toward WM_CAM_FORCED at +-0x20/frame)
static const uint32_t WM_CAM_FORCED     = 0x00C76D22;  // WORD  - forced camera yaw target used when WM_CAM_LOCK==1
static const uint32_t WM_SCRIPT_CAM_PTR = 0x0203FD5C;  // DWORD - nonzero = scripted keyframe camera owns the view (cinematics)
static const uint32_t WM_LOCOMOTION = 0x02040A5E;   // BYTE  - locomotion / vehicle mode. v0.14.83 whitelisted to canonical {0..4}; per `Plan & Research Documents/World Map Terrain and Locomotion Reference.md` legitimate values include 0=Squall foot, 6=Selphie foot, 10=train, 31=Chocobo, 32=invisible-car — our GetVehicleName uses 0/1/2/3/4 for foot/Car/Chocobo/Ship/Ragnarok which DISAGREES with the research-doc enum (research says Chocobo=31, we say 2). Empirical reconciliation needed; see v0.14.84 changelog.
// v0.18.3.256 (#79): the byte above is an ANIMATION-STATE byte (cycles 0->3->7->10->14
// while walking; read 0 in the exam car) -- never authoritative for vehicle detection.
// The .255 [VEHDUMP] BAT (states F11-screenshot-verified) found the ENGINE-TRUTH flag:
static const uint32_t WM_INVEHICLE_FLAG = 0x02040A68;  // BYTE - 0 = on foot, 1 = player entity is a vehicle (exam car: 1 at world-map ENTRY and throughout driving; foot: 0). Same engine struct as the animation byte. Reader: GetInVehicleFlag() in segments.inl (defer-guarded).
static const uint32_t WM_SCENE_FLAG = 0x0203ED2C;   // WORD  - 0=worldmap, 1=field

// ============================================================================
// v0.14.103: Savemap WORLDMAP struct addresses (deep research validated)
// ============================================================================
// Per `Plan & Research Documents/Vehicle state and car position deep research
// results.md`, the savemap WORLDMAP struct IS maintained live in RAM during
// driving (refuting the prior "PC version may omit positions" caveat from
// the older deep-research doc). Hyne's WORLDMAP_PC 26-byte struct describes
// only what gets serialised to disk; the runtime engine keeps the full
// PSX-format struct in memory because the world-map driving code was ported
// expecting the position arrays to be there.
//
// SAVEMAP base = 0x01CFDC5C (76-byte header, NOT 96-byte — see SAVEMAP
// OFFSET CORRECTION in userMemories). The deep research recommended +0x125C
// for the WORLDMAP struct (= prior research's +0x1270 minus 0x14 for the
// header correction).
//
// Layout within the WORLDMAP struct (each *_pos[6] is uint16: X, Z, Y, unk,
// unk, rotation — 12 bytes total):
//   +0x00  char_pos[6]      — foot character mirror
//   +0x18  ragnarok_pos[6]
//   +0x24  bgu_pos[6]       — mobile Balamb Garden
//   +0x30  car_pos[6]       — rental car
//   +0x62  car_rent (1 byte) — boolean: rental car possessed
//
// VERIFICATION: addresses below are arithmetic derivations and must be
// verified by the v0.14.103 [VEH-VERIFY] diagnostic block at module init.
// Decision tree: char_pos X coord ~ foot DWORD X / 4096 at game start
// confirms +0x125C; car drive showing car_pos updating confirms address;
// values looking like ASCII or pointer-shaped (0x004xxxxx) indicate
// arithmetic is wrong and v0.14.103.1 patches with empirical offsets.
static const uintptr_t WM_SAVEMAP_BASE     = 0x01CFDC5C;
static const uint32_t  WM_WORLDMAP_OFFSET  = 0x125C;
static const uint32_t  WMS_CHAR_POS_OFFSET     = 0x00;   // foot mirror (uint16 x6)
static const uint32_t  WMS_RAGNAROK_POS_OFFSET = 0x18;
static const uint32_t  WMS_BGU_POS_OFFSET      = 0x24;
static const uint32_t  WMS_CAR_POS_OFFSET      = 0x30;   // rental car (uint16 x6)
static const uint32_t  WMS_CAR_RENT_OFFSET     = 0x62;

// Convenience: absolute runtime addresses derived from the above.
static const uintptr_t WM_CAR_POS_ADDR      = WM_SAVEMAP_BASE + WM_WORLDMAP_OFFSET + WMS_CAR_POS_OFFSET;       // 0x01CFFEE8
static const uintptr_t WM_RAGNAROK_POS_ADDR = WM_SAVEMAP_BASE + WM_WORLDMAP_OFFSET + WMS_RAGNAROK_POS_OFFSET;  // 0x01CFFED0
static const uintptr_t WM_BGU_POS_ADDR      = WM_SAVEMAP_BASE + WM_WORLDMAP_OFFSET + WMS_BGU_POS_OFFSET;       // 0x01CFFEDC
static const uintptr_t WM_CHAR_POS_ADDR     = WM_SAVEMAP_BASE + WM_WORLDMAP_OFFSET + WMS_CHAR_POS_OFFSET;      // 0x01CFFEB8
static const uintptr_t WM_CAR_RENT_ADDR     = WM_SAVEMAP_BASE + WM_WORLDMAP_OFFSET + WMS_CAR_RENT_OFFSET;      // 0x01CFFF1A

// Foot DWORDs are 20.12 fixed-point (multiply savemap uint16 X by 4096 to
// align coordinate spaces). Savemap uint16 coords are signed when interpreted
// as int16 (the world map coordinate system has a non-zero origin offset
// per the wmx.obj documentation; the foot DWORDs at WM_POS_X/Y/Z carry that
// offset already, but the savemap uint16 coords store raw block-relative
// values that need to be sign-extended and scaled).
// v0.14.103.3: BAT empirically proved this should be 1, not 4096. The
// [VEH-VERIFY] dump at 22:11:38 showed: foot DWORDs X=16031, Y=-26948 versus
// car_pos[0]=16031, car_pos[2]=-26948 (exact 1:1 match). The savemap WORLDMAP
// struct stores positions at the SAME scale as foot DWORDs, NOT in 20.12
// fixed-point. The original assumption was wrong; correcting now.
static const int32_t WM_SAVEMAP_TO_DWORD_SCALE = 1;

static const uint32_t WM_STORY_FLAG = 0x02036BDE;   // WORD  - savemap story-flag word read by sub_545F10's 0xFF02 (GTE) / 0xFF03 (LT) opcodes; v0.14.94 reads this for s_triggerPrograms[] gate evaluation. Range observed in artifact: 0..5000 across the 38 programs.

// World map dimensions (wrapping torus)
static const double WM_WIDTH  = 262144.0;
static const double WM_HEIGHT = 196608.0;

// ============================================================================
// wmx.obj terrain grid constants (v0.14.85 restoration from v0.11.16 impl)
// ============================================================================
// world.fi entry 9 points at wmx.obj inside world.fs. The mesh contains 835
// segments. Of those, the first 768 form the playable 32x24 grid; the remainder
// are story variants. Each segment is exactly 36864 (0x9000) bytes and is
// structured as:
//   bytes 0..3   : group_id (uint32)
//   bytes 4..67  : 16 x uint32 block offsets (relative to segment base)
//   then 16 variable-length blocks at the offsets above
//   then padding to 36864.
// Each block starts with a 4-byte header:
//   byte 0: poly_count (1 byte)
//   byte 1: vert_count (1 byte)
//   byte 2: norm_count (1 byte)
//   byte 3: pad
// Followed by poly_count x 16-byte polygon records, vert_count x 8-byte
// vertices, norm_count x 8-byte normals, and a 4-byte end pad.
// Each polygon's terrain (ground type) byte lives at polygon offset 0x0D.
// Ocean values are 32 (shallow) / 33 (light) / 34 (dark); everything else
// is land. Source: `Plan & Research Documents/wmx.obj polygon format deep
// research findings.md`. Earlier reconstructed parsers that scanned a flat
// `segment[poly * 16 + 13]` stride from segment offset 0 (ignoring the
// per-block headers) read garbage bytes — v0.14.85 BAT classified all 768
// segments as land because the garbage-byte distribution rarely landed in
// the 32-34 range. The correct walker per the research doc is implemented
// in v0.14.85.1's LoadTerrainGrid.
static const int      WMX_FL_INDEX        = 9;
static const int      WMX_SEG_COLS        = 32;
static const int      WMX_SEG_ROWS        = 24;
static const int      WMX_PLAYABLE_SEGS   = 768;
static const int      WMX_TOTAL_SEGS      = 835;
static const uint32_t WMX_SEGMENT_SIZE    = 36864;
static const int      WMX_BLOCKS_PER_SEG  = 16;
static const int      WMX_SEG_HEADER_SIZE = 4 + 16 * 4;   // group_id + 16 block offsets = 68 bytes
static const int      WMX_BLOCK_HDR_SIZE  = 4;            // poly_count + vert_count + norm_count + pad
static const int      WMX_POLY_SIZE       = 16;
static const int      WMX_TERRAIN_OFFSET  = 0x0D;

// ============================================================================
// wmsetus.obj section constants (v0.14.92 — field-entry bytecode decoder)
// ============================================================================
// world.fi entry 10 points at wmsetus.obj inside world.fs (the EN-locale
// wmset; bare wmset.obj is unused leftover per the FF Inside wiki). The file
// begins with a 48-entry section-offset header: 48 little-endian uint32s
// (192 bytes total), each holding the byte offset within wmsetus.obj where
// that section's data starts.
//
// Per disassembly of FF8_EN.exe sub_542DA0 (the wmsetus section-pointer
// setup function, 1-indexed iteration order matches array index +1):
//   Section 1 (392 bytes)  → [0x2040068]  encounter table, sub_541C80
//   Section 2 (772 bytes)  → [0x2040330]  region/terrain map (32x24+hdr)
//   Section 3 (88 bytes)   → [0x2040090]
//   Section 4 (1348 bytes) → [0x2036be8]  encounter destinations
//   Section 5 (8 bytes)    → [0x203ed40]
//   Section 6 (68 bytes)   → [0x2040080]
//   Section 7 (56 bytes)   → [0x2040074]  adjacent to 8, possibly metadata
//   Section 8 (2652 bytes) → [0x2040070]  FIELD ENTRY BYTECODE, sub_545EA0
//   ...
//   (Section 17/18 turn out to be wm2field-style destination data, not
//   trigger geometry as the deep research had hypothesized.)
//
// THIS BUILD hex-dumps Sections 7 and 8 to ff8_world.log under [TRIGGER-DUMP].
// Section 8 is the field-entry bytecode (the data we need to decode for AD).
// Section 7 is small enough (56 bytes) to dump for free in case it turns out
// to be related metadata (entry-point index, region-to-bytecode-offset map,
// etc.). Earlier sections (encounters / region map / destinations) are NOT
// dumped here — they're future work for an 'encounter warning' feature, not
// needed for the v0.14.92 → v0.14.94 AD-steering plan. The 48-entry section
// table is still logged in full so we have a layout sanity-check.
static const int      WMSETUS_FL_INDEX            = 10;
static const int      WMSETUS_SECTION_COUNT       = 48;
static const int      WMSETUS_HEADER_BYTES        = WMSETUS_SECTION_COUNT * 4;   // 192
static const uint32_t WMSETUS_DUMP_CAP_BYTES      = 16384; // safety cap per section in the hex-dump

// Sections to hex-dump (1-indexed in user-facing logs; array index = N-1).
// Order is dump-order in the log; the table sanity-check log line lists all
// 48 sections regardless. Adding more sections to this list is a one-line
// change for any future build that needs a different slice of wmsetus.obj.
// v0.14.93 added Section 2 (the 32x24 segment-region byte map): each byte
// is the region ID for one segment, addressed at file offset row * 32 + col.
// (A 4-byte trailer '00 00 00 00' lives at file offset 768 — not a header.)
// The 0xFF08 region operands in Section 8's bytecode reference these bytes.
// AD steering (v0.14.94+) uses Section 2 to translate catalog (X, Y) into
// a region byte and then matches that against s_triggerPrograms[]'s clauses.
static const int      WMSETUS_DUMP_SECTIONS_1IDX[] = { 2, 7, 8, 9, 19 };  // v0.14.95: +9,19 (also 772b each — hypothesis: per-area region maps; Section 2 alone has only 19 of the 45 region IDs s_triggerPrograms[] references, so the world is split across multiple 32x24 maps)
static const int      WMSETUS_DUMP_COUNT           = sizeof(WMSETUS_DUMP_SECTIONS_1IDX) / sizeof(WMSETUS_DUMP_SECTIONS_1IDX[0]);

// Vehicle classification used by the BFS reachability rules.
// Locomotion enum values per `Plan & Research Documents/World Map Terrain
// and Locomotion Reference.md`:
//   0  = Squall on foot       6  = Selphie on foot
//   3  = Ship (BAT-validated v0.14.83)
//   31 = Chocobo             32-40 = Cars
//   48 = Garden (mobile)     50 = Ragnarok
// Mode 4 is NOT in the canonical list. Earlier builds (v0.14.83-v0.14.85.2)
// tagged it 'Ragnarok' based on a v0.14.82 BAT log where Claude assumed the
// 'Ragnarok session' label, but Aaron's v0.14.85.2 BAT clarified he doesn't
// have Ragnarok in the current save — mode 4 was a transient byte read at
// a Fire Cavern field-transition moment, not a vehicle. v0.14.85.3 drops
// the assumption: mode 4 (and any other non-canonical value) defaults to
// VEH_ON_FOOT for BFS purposes and is silently ignored by CheckVehicleChange.
enum VehicleType {
    VEH_ON_FOOT,
    VEH_CHOCOBO,
    VEH_CAR,
    VEH_GARDEN,
    VEH_RAGNAROK
};

// ============================================================================
// LocationEntry — catalog row type (v0.14.85.1)
// ============================================================================
// One row per world-map entry destination. Holds display name + canonical
// (X, Y) icon-center coordinate. The full table (s_locations[]) and its
// derived LOCATION_COUNT live in world_map_catalog.inl. State that depends
// on a catalog slot (s_catalog, s_refined*, s_destPlannerEligible) is sized
// to MAX_LOCATIONS here so we don't need to see s_locations[] first.
struct LocationEntry {
    const char* name;
    int32_t x;
    int32_t y;
};

// ============================================================================
// Refined entry coordinates table (v0.14.89, Option B — empirical capture)
// ============================================================================
// Parallel to s_locations[]. When a successful on-foot auto-drive ends with
// the world map exiting to MODE_FIELD inside the DRIVE_ARRIVED_ON_EXIT_DIST
// proximity to the catalog target, the field-entry handler captures the
// player's last-known world-map (X, Y) into this table at the same index.
// On subsequent drives to the same destination, StartAutoDrive prefers the
// refined coord over the catalog center for steering — making the second
// visit to a narrow-entrance location (e.g. Balamb Town, Dollet) direct,
// no sweep required.
//
// PERSISTENCE: this build keeps the table in-memory only. Refined coords
// are lost on game restart. Persistent storage (a JSON file alongside
// DEVNOTES, or in %APPDATA%) is queued for v0.14.90 alongside the
// already-deferred 'persistent accessibility settings' priority.
//
// CORRECTNESS: refined coords reflect WHERE THE PLAYER WAS at the moment
// the trigger fired — i.e. the actual on-the-ground entry point. Not the
// trigger-zone center, not the catalog center. Distance from this coord
// to the autopilot center is typically 300-1500 units (matches the prior
// deep research's 'triggers offset by ~300-800 units' estimate).
static int32_t s_refinedX[MAX_LOCATIONS];
static int32_t s_refinedY[MAX_LOCATIONS];
static bool    s_refinedHas[MAX_LOCATIONS];

// ============================================================================
// Planner-eligibility flag per catalog entry (v0.16.0 — Part C)
// ============================================================================
// Computed at Initialize() time by ComputePlannerEligibility() in
// world_map_planner.inl, walking s_triggerPrograms[] and checking whether
// each catalog's region byte appears in any clause with a foot vehicle code
// (0x80 = Squall foot, 0x84 = alt-leader foot). Destinations that fail this
// test are geometric-trigger destinations -- entry via terrain-29 polygon
// trigger, NOT wmsetus script event. They must use v0.11.11-era simple-coord
// steering toward catalog coordinates, NOT the A* planner. Without this
// distinction the v0.14.95 closest-active-region fallback misroutes drives
// toward unrelated destinations (e.g. Fire Cavern -> bggate_1 in v0.15.13.2).
//
// Catalog index aligned with s_locations[]. Sized to MAX_LOCATIONS to keep
// the array sizing decoupled from catalog.inl's data table.
static bool s_destPlannerEligible[MAX_LOCATIONS];

// ============================================================================
// Navigation state
// ============================================================================
static struct LocationEntry s_catalog[MAX_LOCATIONS];  // distance-sorted working copy
static int  s_catalogCount = 0;        // v0.14.85: post-filter count (≤ LOCATION_COUNT, MAX_LOCATIONS)
static bool s_catalogBuilt = false;
static int s_catalogIndex = 0;       // current selected location (0 = nearest)
static int s_lastVehicle = -1;       // last known vehicle state
static bool s_onWorldMap = false;    // true when on world map
static DWORD s_lastMovementTick = 0; // last time position changed significantly

// ============================================================================
// Auto-drive state (v0.14.86, restored from v0.11.08-v0.11.10)
// ============================================================================
// World map auto-drive uses keyboard injection rather than the field-nav
// fake gamepad. Discovered v0.11.05-v0.11.07: the world map's input handler
// `worldmap_input_update_sub_559240` has its own input pipeline separate
// from the field's `engine_eval_keyboard_gamepad_input`, so the fake gamepad
// signal never reaches it. `keybd_event` injection at the OS level reaches
// both pipelines and works reliably on the world map. v0.11.08 BAT validated.
//
// Steering uses heading-relative bearing (0-4095 native units; 0=North CW)
// computed each tick. Three behaviors based on relative bearing magnitude:
//   ahead   (within ~18°)  : just walk forward
//   diag    (~18-45°)      : turn AND walk forward (saves time vs. turn-then-walk)
//   side    (>45°)         : turn only until aligned, then forward
// Final approach (<DRIVE_ARRIVE_DIST*2 ≈ 1000 units): just walk forward —
// most catalog coordinates are not exactly on entrance triggers, and walking
// straight through the area sweeps reliably onto the trigger zone.
//
// State target is captured by VALUE (X/Y/name) at StartAutoDrive time, not
// as a catalog index. The catalog rebuilds whenever the player crosses a
// BFS rule-class boundary, which would invalidate any stored index. Stable
// X/Y/name lets the drive survive arbitrary catalog rebuilds.
static const double DRIVE_ARRIVE_DIST           = 600.0;   // vehicle arrival proximity (on-foot uses world-map-exit detection)
static const double DRIVE_APPROACH_DIST         = 3000.0;  // one-shot "Approaching X" threshold
static const double DRIVE_FINAL_APPROACH_DIST   = 1000.0;  // walk-forward (no steering) below this
static const double FINAL_APPROACH_FORWARD_DIST = 200.0;   // v0.14.100: below this, walk forward; 200..1000 uses bearing
// v0.18.3.259 (#68): VEHICLE final-approach circle. The car's turning radius
// at speed is ~1000u (MFRAME telemetry: ~64u/frame forward, ~40/4096-turn
// slew/frame -> v/omega ~ 1043u), so inside ~1200u of the aim a stop-and-pivot
// cycle can only ORBIT the target -- exactly the .258 Balamb approach (dist
// swung 402->561 while circling, reverse bursts, ~5s lost). Inside this circle
// the vehicle law NEVER pivots: hold forward and arc-steer toward the aim,
// sweeping across the (broad) entry trigger instead of circling it. Foot paths
// don't read this constant.
static const double VEH_FINAL_APPROACH_DIST     = 1200.0;
static const double DRIVE_ARRIVED_ON_EXIT_DIST  = 1500.0;  // v0.14.87: world-map exit while closer than this counts as arrival
static const double DRIVE_NEAR_LOCATION_DIST    = 1500.0;  // v0.14.103: bounce-detection radius for non-car-friendly arrivals
static const DWORD  DRIVE_ANNOUNCE_INTERVAL_MS  = 5000;    // periodic distance announce
static const DWORD  DRIVE_STUCK_CHECK_INTERVAL_MS = 3000;  // stuck-detection sample window
static const double DRIVE_STUCK_THRESHOLD       = 100.0;   // movement floor in one window
static const int    DRIVE_STUCK_MAX             = 6;       // 6 windows × 3s = 18s no movement → give up

// #67 BAT 2 stage 2 (v0.18.3.59): planner-path follow + recovery tuning.
// DRIVE_PLAN_LOOKAHEAD_DIST: the drive steers at the first path cell at least
// this many world units ahead (straight-line) of the player. The v0.18.3.58
// BAT crawled because a one-cell (1024u) target sits inside the steering law's
// turn-in-place cone -- the bearing swings as the player inches, so it spins
// instead of driving. A target ~2400u out keeps the bearing stable (forward
// motion) while staying close enough to the clearance-centred route that the
// straight-line cut stays inside the corridor (offline follow sim: deviation
// ~720u at this range vs >1600u at a 4+ cell lookahead).
static const double DRIVE_PLAN_LOOKAHEAD_DIST   = 2400.0;
// Mid-route stuck recovery: after this many stuck windows on a planned drive,
// re-plan from the player's CURRENT position (a fresh clearance route from
// where he actually is) rather than giving up. Bounded per drive so a true
// hard-jam still terminates instead of looping.
static const int    DRIVE_REPLAN_TRIGGER        = 2;       // stuck windows before a recovery re-plan
static const int    DRIVE_MAX_REPLANS           = 24;      // v0.18.3.202: 8 -> 24. With the learned
                                                           // engine-block overlay each re-plan now routes
                                                           // AROUND discovered obstacles (genuinely different
                                                           // routes, not the .201 sterile identical loop), so
                                                           // re-plans are productive; offline the worst
                                                           // recovery case needed well over 8.

// #70 v0.18.3.97: departure bridge-out. A planned route that starts inside a
// tiny disconnected pocket (the Dollet shelf -- the #69 height-step guard seals
// the coastal shelf IN, the same way it keeps routes off the cliff) expands
// only a handful of cells and dead-ends far short of the target. Detect that
// (expanded <= WM_POCKET_MAX_EXPANDED AND still WM_POCKET_MIN_DIST cells short)
// and steer to the nearest ROAD cell -- the guard-exempt escape ramp the
// character arrived on -- then re-plan from there. Mirrors the arrival sweep.
static const int    WM_POCKET_MAX_EXPANDED  = 40;     // pocket if the BFS reached <= this many cells
static const int    WM_POCKET_MIN_DIST      = 6;      // ...AND the route ends >= this many cells short of target
static const double WM_BRIDGE_ARRIVE_DIST   = 1536.0; // reached the road once within ~1.5 fine cells of it
static const int    WM_BRIDGE_MAX           = 6;      // give-up guard: max bridge attempts per drive
static const int    WM_BRIDGE_ROAD_RADIUS   = 30;     // nearest-road ring search limit (fine cells)

// #67 v0.18.3.60: mid-route arc-steering bands (relBearing units; 4096 = 360deg,
// so 1deg ~= 11.4 units). The old law walked forward only within ~17.5deg of the
// target and turned in place otherwise, with no damping -- so the heading
// overshot the target and rocked across it (v0.18.3.59 oscillated in place).
// New mid-route law: within STEER_DEADZONE of dead-ahead, drive STRAIGHT with no
// turn (this damps the overshoot -- the player stops correcting once roughly
// aimed); between deadzone and STEER_FWD_CONE, drive forward AND turn (arc);
// beyond the cone, turn in place toward the target (handles sharp path bends,
// like the old law). Tunable: widen the deadzone if it still oscillates, narrow
// it if it drifts into walls. Final-approach steering is unchanged.
static const int    STEER_DEADZONE              = 320;     // ~28deg: drive straight, no turning
static const int    STEER_FWD_CONE              = 576;     // ~50deg: forward while turning up to here

// #67 v0.18.3.62: motion-derived heading + self-calibrating turn sign. The
// v0.18.3.61 diagnostic proved GetWorldMapHeading() returns a frozen value (540)
// during a drive, so every relBearing was computed against a fake facing and the
// steering turned the wrong way into terrain. Instead we derive the player's
// facing from his ACTUAL motion (bearing of his recent position delta) and learn
// whether RIGHT raises or lowers that bearing by watching how it rotates when we
// turn -- so a wrong initial guess self-corrects within a sample. Heading -1 =
// not yet known (bootstrap: drive straight to establish it).
static int      s_driveMoveHeading    = -1;   // 0..4095, or -1 = unknown
static int32_t  s_driveHeadRefX       = 0;    // ref point for the next heading sample
static int32_t  s_driveHeadRefY       = 0;
static int      s_driveTurnSign       = 1;    // +1: RIGHT raises bearing; -1: RIGHT lowers it
static bool     s_driveTurnedSinceRef = false;
static bool     s_driveLastTurnRight  = false;
static DWORD    s_driveLastMoveTime   = 0;    // wall-slide: last time he actually moved
static int32_t  s_driveLastMovePosX   = 0;
static int32_t  s_driveLastMovePosY   = 0;
static DWORD    s_driveWedgeReverseUntil = 0;   // #67 v0.18.3.68: reverse-burst end tick (0 = not reversing)
static int      s_driveWedgeReverseCount = 0;   // reverse bursts used since the last genuine progress
static double   s_driveWedgeProgressDist = 0.0; // watermark: closest dist-to-target seen; refreshes the reverse budget
static int32_t  s_driveWedgeAnchorX      = 0;   // #67 v0.18.3.69: net-displacement wedge anchor (defeats wall-vibration)
static int32_t  s_driveWedgeAnchorY      = 0;
static DWORD    s_driveWedgeAnchorTime   = 0;
static const int   MOVE_HEADING_MIN_DELTA = 50;   // motion (units) needed to trust a heading sample
static const int   TURN_CAL_MIN_DELTA     = 80;   // heading change needed to trust a sign calibration
static const DWORD WALL_SLIDE_MS          = 600;  // stationary this long -> force a turn to slide off
static const int   WALL_SLIDE_EPS         = 40;   // movement under this (units) counts as "not moving"
// #67 v0.18.3.68: reverse un-wedge tuning.
static const DWORD  HARD_WEDGE_MS         = 1200;  // no real movement this long -> reverse off the wall
static const DWORD  REVERSE_BURST_MS      = 600;   // duration of one reverse burst
static const int    MAX_WEDGE_REVERSE     = 4;     // reverse bursts before falling through to stuck-detection
static const double WEDGE_PROGRESS_EPS    = 500.0; // got this much closer to target -> refresh the reverse budget
static const double WEDGE_NET_EPS         = 250.0; // #67 v0.18.3.69: net travel under this over HARD_WEDGE_MS = wedged (vibration-proof)
static const int   DRIVE_LOOKAHEAD_CELLS   = 1;    // #67 v0.18.3.64: aim at the NEXT route cell only (always walkable-adjacent, never across a wall)
static const DWORD TURN_DUTY_ON_MS         = 60;   // #67 v0.18.3.64: duty-cycle the turn to damp overshoot -- turn this long...
static const DWORD TURN_DUTY_OFF_MS        = 120;  // ...then go straight this long (forward frames let the heading catch up)

// ============================================================================
// #67 v0.18.3.74: SCREEN-RELATIVE self-calibrating on-foot steering
// ============================================================================
// The v0.18.3.73 camera diagnostic was decisive: WM_HEADING (0x0203ED02) is
// FROZEN on foot, G/H do NOT rotate the camera (nothing in memory responded to
// 5 taps each), and the UP-walk vector never changed -- on foot the arrows WALK
// screen-relative, and the screen->world mapping differs by region (UP was NE at
// the Dollet jam, NW near Galbadia Garden). So on-foot steering cannot use a
// heading or control the camera; instead it MEASURES the screen->world basis
// from the character's own motion (press an arrow, read the world delta) and
// presses the arrow combo whose screen direction points at the target. The
// basis is measured at drive start (a brief UP then RIGHT probe) and refreshed
// live from single-arrow motion, so it tracks the camera as it swings. Vehicle
// drives keep the existing heading-based steering (cars rotate-then-go).
enum DriveCalPhase { DCAL_NONE = 0, DCAL_PROBE_UP, DCAL_SETTLE_UR, DCAL_PROBE_RIGHT, DCAL_DONE };
static DriveCalPhase s_driveCalPhase = DCAL_DONE;
static DWORD    s_driveCalStart = 0;
static int32_t  s_driveCalX = 0, s_driveCalY = 0;   // current probe's start position
static int      s_driveCalTry = 0;
static double   s_camUx = 0.0, s_camUy = -1.0;      // screen-UP    -> world unit vector (default North)
static double   s_camRx = 1.0, s_camRy =  0.0;      // screen-RIGHT -> world unit vector (default East)
static bool     s_camBasisValid = false;
static bool     s_drivePrevUp = false, s_drivePrevDown = false, s_drivePrevLeft = false, s_drivePrevRight = false;
static int32_t  s_drivePrevX = 0, s_drivePrevY = 0;
static bool     s_drivePrevHadKeys = false;
static DWORD    s_driveSidestepUntil = 0;           // screen-relative un-wedge: slide laterally past an obstacle
static int      s_driveSidestepSign  = 1;           // alternates each stuck (right / left)

// #67 v0.18.3.77: GREEDY EMPIRICAL ARROW-PROBE state (replaces the basis decision).
// Hold ONE cardinal arrow; each window measure whether it moved the character
// toward the steer target; keep it if so, else rotate to the next cardinal.
// Trusts only MEASURED progress -- immune to camera swing / wall-slide that
// defeated the maintained screen->world basis across the .74/.75/.76 BATs.
static int      s_driveProbeArrow   = 0;     // 0=UP 1=RIGHT 2=DOWN 3=LEFT (committed cardinal)
static bool     s_driveProbeValid   = false; // false until the first window is armed
static int32_t  s_driveProbeAnchorX = 0, s_driveProbeAnchorY = 0;  // position at window start
static DWORD    s_driveProbeTime    = 0;     // window start tick
static int      s_driveProbeFails   = 0;     // consecutive non-progressing windows

static const DWORD  DRIVE_CAL_PROBE_MS      = 320;   // hold each calibration probe arrow this long
static const DWORD  DRIVE_CAL_SETTLE_MS     = 150;   // settle between the UP and RIGHT probes
static const int    DRIVE_CAL_MIN_MOVE      = 60;    // min world units moved to accept a probe
static const int    DRIVE_CAL_MAX_TRY       = 3;     // probe retries before falling back
static const double STEER_AXIS_C            = 0.383; // cos(67.5deg): 8-way arrow thresholds
static const int    DRIVE_BASIS_REFRESH_MIN = 10;    // #67 v0.18.3.75: min single-arrow move (units) to refresh the basis. Was 40 -- ABOVE the per-tick walk delta (~15u), so the .74 BAT never refreshed and the basis went stale over a 15km drive as the camera swung. 10 tracks walking motion while still excluding wedge jitter (<1u/tick).
static const double DRIVE_BASIS_EMA         = 0.30;  // EMA weight pulling the basis toward fresh motion
static const double DRIVE_BASIS_AGREE_MIN   = 0.50;  // #67 v0.18.3.76: only refine the basis when observed motion agrees with the pressed arrow's predicted direction (dot > this, ~within 60deg). The .75 BAT tracked fine on open ground but a wall stall at the route corner fed perpendicular/reversed slide motion into the refresh, rotating uHat ~90deg off and driving him BACKWARD. Rejecting disagreeing motion blocks that while still allowing gradual camera tracking (which always agrees closely).
static const DWORD  DRIVE_SIDESTEP_MS       = 700;   // lateral slide burst on a mid-route stuck

// #67 v0.18.3.77: greedy arrow-probe tuning.
static const DWORD  DRIVE_PROBE_WINDOW_MS    = 250;   // hold one cardinal this long, then evaluate the window
static const double DRIVE_PROBE_MIN_MOVE     = 40.0;  // must actually move this far in the window (else the arrow is walled -> rotate)
static const double DRIVE_PROBE_ALIGN_MIN    = 0.55;  // window motion must align with the target dir within ~57deg to KEEP the arrow
static const int    DRIVE_PROBE_MAX_FAILS    = 8;     // this many non-progressing windows in a row -> re-plan (genuine pocket / dead end)

// #67 v0.18.3.61: per-tick steering DIAGNOSTIC. DRIVE_STEER_DIAG gates a
// throttled [DRIVE-DIAG] trace in UpdateAutoDrive (position + delta-moved,
// heading + delta, target bearing, relBearing/off, keys pressed, and which band
// the law took) so the stuck-follow behavior is finally visible tick-by-tick
// instead of inferred from 3-second stuck-checks. The delta-moved per line tells
// pivot-in-place (no forward key, heading turning) apart from forward-into-
// collision (UP pressed but position frozen). Per-session diagnostic -- set
// false (or remove this block + the trace) before the #67 push.
static const bool   DRIVE_STEER_DIAG            = false;  // #70 v0.18.3.98 turned this on "to watch the bridge-out steer toward the road cell (set false before push)" -- v0.21.4 does what that comment asked. 50 ms of synchronous file I/O on the poll thread, every drive.
static const int    DRIVE_STEER_DIAG_INTERVAL_MS = 50;    // v0.18.3.179: 200->50ms, denser movement-physics data

// #70 v0.18.3.201: CAMERA-WRITE steering. true = the on-foot executor steers by writing
// the camera yaw each frame and holding UP (the engine derives heading = camYaw + bias/2
// itself; exe-verified in offline/CAMERA_EXE_ANALYSIS.md, 24/24 sim pairs in
// offline/SIM_CAMERA_RESULTS.md). false = the .200 8-way key steering (kept as fallback).
static const bool   DRIVE_CAMWRITE              = true;

// v0.14.87 — sweep search constants. Activated when on-foot drive is stuck
// inside the final-approach zone (target within 1000 units but no entrance
// trigger has fired). Past chats v0.11.10 validated 6-phase alternating
// turn-then-walk as effective for narrow entrances like Balamb Town.
static const int    SWEEP_MAX_PHASES        = 16;    // v0.18.3.194: 6->16. Bounded local ENTRY SEARCH.
                                                    // Open towns whose icon is offset from the real
                                                    // field trigger (Galbadia Garden: the icon sits on
                                                    // the ring, the entry is the center) need the sweep
                                                    // to COVER the area around the icon, not walk off in
                                                    // one direction. More phases + shorter walks (below)
                                                    // make a tight rotating search that crosses the
                                                    // center trigger; capture-on-success then pins it.
static const DWORD  SWEEP_TURN_BASE_MS      = 800;   // phase 1 turn duration; +200ms per phase
static const DWORD  SWEEP_WALK_DURATION_MS  = 800;   // v0.18.3.194: 3000->800. Short probes keep the search
                                                    // local (the 3s walk drifted ~3000u and bounced);
                                                    // ~800u per probe crosses a nearby offset trigger
                                                    // while staying within the final-approach zone.
static const DWORD  FINAL_APPROACH_TIMEOUT_MS = 6000;// in final approach >6s without exit → sweep

#if WM_RUNTIME_WALK_DIAG
// v0.18.3.102: the one-shot runtime-walkmesh dump is armed on world-map entry
// and fired from Poll() once the mesh is actually populated -- NOT merely once
// [0x020402DC] is non-zero (the .101 BAT proved that fires too early, while the
// player position is still (0,0) and the descriptor entries are garbage).
static bool s_rtWalkDumpPending  = false;  // armed on world-map entry
static int  s_rtWalkSettleTicks  = -1;     // -1 until player position valid; then counts ticks since (settle delay)
static int  s_rtWalkPollTicks    = 0;      // total ticks polled since armed (fire-anyway safety budget)
#endif

// v0.18.3.203: LEARNED FIELD-TRIGGER footprints. Locations' field triggers are REGIONS,
// not points -- the .202 BAT proved 'ggview1' (Galbadia Garden) fires ~1815u from its
// entrance coordinate (the whole plateau is the trigger), so a through-route that clips a
// non-target region yanks the player into that field. Region extents aren't stored anywhere
// we can read, so we LEARN them: every off-target field entry during a drive records
// (location center, observed entry distance + margin) here; the grid planner then
// soft-penalizes cells inside a non-target circle, routing around it when terrain allows.
// Circles containing the drive's START are exempt -- the engine DISARMS a trigger you spawn
// inside until you leave it (which is exactly why drives *leaving* G-Garden never re-enter
// it). Session-scope for now (re-learned after a restart; persistence is a follow-up).
static const int TRIG_AVOID_MAX = 24;
static int32_t s_trigAvoidX[TRIG_AVOID_MAX];
static int32_t s_trigAvoidY[TRIG_AVOID_MAX];
static int     s_trigAvoidR[TRIG_AVOID_MAX];
static int     s_trigAvoidN = 0;

static bool s_driveActive            = false;
// v0.18.3.257 (#79): physics-detector state. s_driveVehicleSig latches TRUE for
// the CURRENT drive when the motion discriminator reaches verdict (>=20 of last
// 24 clean disagreement frames side with mh) while steering as foot --
// UpdateAutoDrive then treats the drive as a VEHICLE (the turn-then-go law).
// All fields reset in StartAutoDrive so a stale ring from a car drive can never
// latch a following foot drive.
//
// v0.21.0: **THE VERDICT WAS NOT UNREACHABLE ON FOOT. IT FIRED FIVE TIMES IN
// ONE WALK TO EDEA'S HOUSE, AND EACH TIME IT THREW THE DRIVE INTO AN ORBIT IT
// COULD NOT LEAVE.** See the note above the detector in world_map_drive_exec.inl.
// Two guards now stand in front of it: the engine's own vehicle id vetoes it
// outright, and frames where the character is mid-turn no longer count.
static bool     s_driveVehicleSig = false;
static int32_t  s_vsPx = 0, s_vsPy = 0;
static bool     s_vsHad = false;
static VehSigRing s_vsSig = { 0, 0, -1, false };   // see world_map_vehsig.inl
static DWORD    s_vsLastLog = 0;
// v0.18.3.203: PAUSED-IN-FIELD drive. An off-target field entry no longer kills the drive:
// it pauses (drive stays active, keys released, UpdateAutoDrive idle off-map) and the
// existing world-map re-entry resume path replans and continues -- with the trigger circle
// learned above, and the start now INSIDE it (disarmed), the resumed route walks out
// cleanly. Stale pauses (player stayed in the field > 5 min) cancel on re-entry.
static bool     s_drivePausedInField     = false;
static DWORD    s_drivePauseTick         = 0;
static int32_t  s_driveTargetX           = 0;
static int32_t  s_driveTargetY           = 0;
static char     s_driveTargetName[64]    = {};
static DWORD    s_driveStartTime         = 0;
// v0.18.3.216: bumped on every battle/field pause-resume. The .202 route-
// progress watchdog and .204 give-up keyed their reseed to s_driveStartTime
// alone, so after a battle their clocks were STALE by the battle's length:
// a >4s battle instantly fired "route-progress stalled" and a >40s battle
// instantly fired StopAutoDrive("Cannot reach...") on the first resumed
// frame (BAT .215, 21:24:14). Watchdogs key on startTime + this generation.
static DWORD    s_driveWatchdogGen       = 0;
// v0.21.4: true while a dialog window holds the world map. See the note at the
// top of UpdateAutoDrive -- a cutscene is not a stall, and on foot mistaking one
// for a stall wrote permanent damage into the learned-obstacle overlay.
static bool     s_driveInDialog          = false;
// v0.18.3.220: world-map re-entry resume replan is DEFERRED this many ticks.
// The .219 BAT showed the immediate replan races the engine: on the first
// re-entry frame GetWorldMapPosition_Active still returns the PRE-pause
// position (24380,-29748 vs actual spawn 24576,-29406), so the hop-on point
// landed inside Balamb Garden's firing area and steering re-entered the
// field. Steering is held (keys stay released) until the deferred replan
// runs with a settled position.
static int      s_driveResumeReplanTicks = 0;
// v0.18.3.221: FIRING-AREA ESCAPE. When a drive starts or resumes with the
// character standing INSIDE a decoded firing-area bbox that is not the drive
// target (the B-Garden front-gate spawn sits ~4u inside BG's north edge, so
// every BG->Fire Cavern drive re-entered BG within ~560ms before it could
// steer clear), the executor first steers straight OUT of that bbox by its
// nearest edge + margin, suppressing normal path steering, then skips any
// leading path waypoints still inside the bbox and resumes. Self-clearing
// once the character is outside every non-target firing area.
static bool     s_driveEscapeActive      = false;
static int32_t  s_driveEscapeX           = 0;
static int32_t  s_driveEscapeY           = 0;
static int      s_driveEscapeAreaIdx     = -1;   // s_entryAims index being escaped
// v0.18.3.223: the escape now routes AROUND the area's padded box toward the
// first on-route waypoint outside the area (captured here at arm time), not the
// final destination -- Timber->Dollet spawns N of Timber but the route goes SW,
// so steering at the destination (S) crossed Timber and broke the network plan.
static int32_t  s_driveEscapeTgtX        = 0;
static int32_t  s_driveEscapeTgtY        = 0;
static int      s_driveEscapeTgtIdx      = -1;   // path index of the on-route escape target
static DWORD    s_driveLastAnnounce      = 0;
static double   s_driveLastDist          = 0.0;
static int32_t  s_driveLastPosX          = 0;     // v0.14.89: last known player X (for refined-entry capture on MODE_FIELD)
static int32_t  s_driveLastPosY          = 0;
static int32_t  s_driveStuckX            = 0;
static int32_t  s_driveStuckY            = 0;
static DWORD    s_driveStuckCheckTime    = 0;
static int      s_driveStuckCount        = 0;
static int      s_driveReplanCount       = 0;      // #67 v0.18.3.59: mid-route recovery re-plans used this drive
static int      s_drivePlanExpanded      = 0;      // #70 v0.18.3.97: node count from the last PlanPathFine
static int      s_drivePlanDist          = 0;      // #70: cells from the route end to the target (0 = reached)
static bool     s_driveNavmeshPath       = false;  // #70 v0.18.3.109: the active s_drivePath came from PlanDrivePathNavmesh (funnel). The executor BYPASSES its coarse-grid LOS clamp + forward-guard on it -- the funnel corridor is navmesh-walkable by construction but legitimately crosses fine cells the coarse 1024u grid marks blocked (.81 coast box / false-coast steep-mtn).
static bool     s_driveBridgeActive      = false;  // #70: bridging out of a start pocket toward the nearest road cell
static int32_t  s_driveBridgeX           = 0;      // #70: bridge target (nearest road cell, world coords)
static int32_t  s_driveBridgeY           = 0;
static int      s_driveBridgeCount       = 0;      // #70: bridge attempts used this drive (bounded by WM_BRIDGE_MAX)
static bool     s_driveApproachAnnounced = false;  // one-shot guard
static bool     s_driveOnFootAtStart     = true;   // v0.14.87: captured at StartAutoDrive; arrival semantics differ
static DWORD    s_finalApproachEnterTick = 0;      // v0.14.87: when player crossed below FINAL_APPROACH_DIST (0 = not yet)

// v0.14.103.7: per-destination foot-friendliness flag, computed once at
// AD start by IsLocationFootFriendly(). When TRUE, a foot trigger exists
// for the destination's region (engine will auto-dismount cars onto it):
// keep the standard DRIVE_BOUNCE_ABORT_THRESHOLD=2 retry budget. When
// FALSE, the destination's region is vehicle-only (Garden-style landing
// pad like Balamb Garden's region 0x0C, only program 20 = top_vehicle=
// Garden, no foot clause): cars will never trigger entry, so bounce-
// arrived fires on the FIRST sweep-abort (~13s instead of ~27s). The
// sweep-abort hook reads this flag via the inline ternary at the
// threshold check. Defaults to TRUE so any failure to compute the flag
// (region map not loaded, destination off-map, etc.) preserves
// v0.14.103.6 behavior rather than firing bounce-arrived prematurely.
static bool         s_destFootFriendly            = true;

// v0.16.0.2: per-drive planner-eligibility flag, captured once at
// StartAutoDrive from s_destPlannerEligible[locIdx] and consulted by the
// replan path in Poll() after world-map re-entry. The v0.16.0.1 BAT
// showed Fire Cavern's drive correctly skipping the planner at start
// (Part C), but the replan-on-world-map-re-entry path called
// PlanDrivePath() unconditionally, converting a clean simple-coord drive
// into a planner-routed drive toward the closest-active-region fallback
// (Balamb Town's seg(18,20)). Part B caught the off-target arrival, but
// Fire Cavern was never reached. Storing the decision once at
// drive-start lets Poll()'s replan honor the same gate. Defaults to TRUE
// so any future code path that doesn't set this flag preserves
// pre-v0.16.0.2 behavior (always call planner).
static bool         s_drivePlannerEligible        = true;

static const int    DRIVE_BOUNCE_ABORT_THRESHOLD = 2;
static int          s_sweepAbortCount             = 0;     // increments on each sweep-abort, reset on AD start

// v0.14.96: deferred arrival decision state. Use the game's settled game
// mode AFTER the world-map exit to disambiguate field-entry from random
// encounter. Decision table:
//   MODE_FIELD (1)        : entered a field — REAL ARRIVAL
//   MODE_SWIRL (3)        : pre-battle swirl — ENCOUNTER (paused)
//   MODE_BATTLE (999)     : in battle — ENCOUNTER (paused)
//   MODE_AFTER_BATTLE (4) : post-battle return — ENCOUNTER (paused)
//   anything else (incl. lingering MODE_WORLDMAP=2) : keep waiting
// Wait timeout: ARRIVAL_DECISION_TIMEOUT_MS. On timeout, fall back to the
// v0.14.95 segment-membership / distance heuristic as safety net.
//
// While awaiting decision: drive keys are released (no arrow-key injection
// during field/battle), s_driveActive stays true (so cancel works), Poll()
// runs ResolveDeferredArrival() each tick before its !s_onWorldMap early
// return so the decision can resolve.
static const DWORD ARRIVAL_DECISION_TIMEOUT_MS = 2000;
static bool  s_driveAwaitingArrivalDecision = false;
static DWORD s_driveExitTick                = 0;

// v0.14.87 sweep search state. Sweep alternates between TURNING and WALKING
// sub-states. Each phase: turn for SWEEP_TURN_BASE_MS + (phase-1)*200ms,
// then walk forward SWEEP_WALK_DURATION_MS. Odd phases turn right, even left.
// Field exit during any sub-state → arrival; sweep exhaustion → give up.
static bool     s_sweepActive  = false;
static int      s_sweepPhase   = 0;     // 1..SWEEP_MAX_PHASES (0 = not in sweep)
static bool     s_sweepTurning = true;  // sub-state: true = turn, false = walk
static DWORD    s_sweepStateEnd = 0;    // tick when current sub-state ends

// Held-key tracking for keybd_event injection. Press/release tracking lets
// SetDriveKeys() be idempotent — pressing UP twice doesn't double-press.
static bool s_keyUpHeld    = false;
static bool s_keyLeftHeld  = false;
static bool s_keyRightHeld = false;
// v0.14.102: Restore gas-pedal injection from v0.11.14 design. The car's
// forward/gas key is A (VK=0x41, scan=0x1E) — must be HELD continuously
// like a real gas pedal; arrow keys steer only and don't accelerate the
// car. ALWAYS injected alongside UP arrow because the locomotion byte at
// 0x02040A5E reads non-canonical values (e.g. 21 for rental car) when in
// vehicles, making reliable car detection impossible — the always-inject
// approach is harmless on foot (A is unbound for walking; the engine
// ignores it) and essential for cars. Critically, A is NOT an extended
// key, so PressKey/ReleaseKey are called with extended=false.
static bool s_keyGasHeld   = false;
// #67 v0.18.3.68: DOWN arrow (reverse), VK_DOWN (0x28), scan 0x50, extended.
// Drives the wedge-recovery reverse burst -- backing off a wall the drive
// cannot turn away from (on the world map the character only rotates WHILE
// moving forward, so a forward-wedge freezes the heading; reversing regains
// motion and room).
static bool s_keyDownHeld  = false;

// ============================================================================
// Terrain grid + BFS reachability state (v0.14.85, extended in v0.14.103)
// ============================================================================
// v0.14.103: extended from binary (0=land, 1=ocean) to 3-state classifier.
// Forest segments (terrain values 0-5 per `Plan & Research Documents/World
// Map Terrain and Locomotion Reference.md`) are walkable on foot/Chocobo but
// IMPASSABLE for cars (the engine's collision system rejects forest entry
// when the player is in a vehicle from the 32-40 locomotion family). Foot AD
// retains its existing land-only filter (forest counts as land for foot).
// Car AD adds forest as an impassable class.
//
// Loaded once at module init from wmx.obj inside world.fs. s_reachable[row]
// [col] is rebuilt per catalog build via BFS flood-fill from the player's
// current segment.
enum SegTerrainClass : uint8_t {
    SEG_LAND     = 0,   // walkable by all locomotion classes (default)
    SEG_FOREST   = 1,   // walkable on foot/Chocobo; impassable for cars
    SEG_OCEAN    = 2,   // walkable only by Garden/Ragnarok
    SEG_MOUNTAIN = 3    // #67: wmx terrain type 29. Impassable on foot (confirmed steep:
                        // avg face slope 57deg, the map's most common land type). BAT 1
                        // treats it as walkable land while the terrain logger calibrates
                        // it against real movement; BAT 2 flips it to blocked for foot.
                        // The coarse s_terrainGrid never emits this -- only the fine grid.
};
static uint8_t s_terrainGrid[WMX_SEG_ROWS][WMX_SEG_COLS];   // values from SegTerrainClass
static uint8_t s_reachable  [WMX_SEG_ROWS][WMX_SEG_COLS];
static bool    s_terrainLoaded = false;

// ============================================================================
// #67: Fine rasterized walkable grid + continuous-flood-fill reachability
// ============================================================================
// The 32x24 segment grid (s_terrainGrid) is too coarse for reachability: with
// the corrected coordinate mapping, NO land/ocean threshold both keeps same-
// continent coastal locations (e.g. Fire Cavern) AND separates continents
// across thin ocean straits (majority-rule drops coastal land; any-land bridges
// every continent into one blob). The faithful model rasterizes the wmx polygons
// into a fine grid (1024-unit cells, 256x192) and flood-fills in continuous
// space -- ocean straits block, mesh T-junctions don't. Validated offline 17/17
// (Balamb incl. Fire Cavern isolated; every other continent correctly unreachable
// on foot). See `Plan & Research Documents/World Map Reachability Rework -
// offline wmx analysis findings.md`.
//
// s_walkClassFine holds a SegTerrainClass per fine cell -- the class of the wmx
// polygon containing the cell centre, or SEG_OCEAN where no land polygon covers
// it. s_reachFine is the per-build flood-fill visited mask. s_walkGridLoaded
// gates the catalog onto the fine path; on load failure the catalog stays
// unfiltered (safer than a wrong filter).
static const int WM_FINE_CELL = 1024;                        // world units per fine cell
static const int WM_FINE_COLS = 256;                         // 262144 / 1024
static const int WM_FINE_ROWS = 192;                         // 196608 / 1024
static uint8_t s_walkClassFine[WM_FINE_ROWS][WM_FINE_COLS];  // SegTerrainClass per fine cell
static uint8_t s_reachFine     [WM_FINE_ROWS][WM_FINE_COLS]; // flood-fill visited (0/1)
static uint8_t s_roadFine      [WM_FINE_ROWS][WM_FINE_COLS]; // v0.18.3.128 (#70): road overlay (wmx terrain 27/28), populated by RasterizeTriRoad in segments.inl; declared here so the navmesh connection gate (NmEngineStepBlocked) can read it
static bool    s_walkGridLoaded = false;

// ============================================================================
// v0.18.3.101: Runtime walkability dump addresses
// ============================================================================
// Verified from FF8_EN.exe byte analysis (session 2026-06-24). The earlier
// theory in this block (0x020426C0 as a stride-40 ADJACENCY array) was WRONG
// and has been corrected. What was actually established:
//
// THE RUNTIME WALKMESH ADJACENCY (the structure we want):
//   0x020402DC = pointer to the polygon DESCRIPTOR ARRAY ("descBase").
//     Written ONCE at 0x542F17 by the world-map data-load batch pointer setup
//     (sub_542DA0 family): ecx = table[idx*4 + 0x01E9DC3C] + 0x01E9DC3C, then
//     mov [0x020402DC], ecx. 0x01E9DC3C is BSS (its file offset exceeds the
//     22.1MB exe size) -> runtime-allocated and populated from world.fs, NOT
//     baked in the exe. So [0x020402DC] becomes non-zero exactly when the mesh
//     blob finishes loading and stays valid for the whole world-map session:
//     it is the RELIABLE READINESS SIGNAL (poll [0x020402DC] != 0).
//   Descriptor entry = 12 bytes. For polygon N:
//     adjListPtr = *(uint32_t*)(descBase + N*12 + 0)
//     (+4 dword and +8 word are other per-poly fields; confirmed at 0x548B50
//      lea eax,[eax+edx*4] with edx=idx*3 => idx*12, the +0 dword stored to
//      0x0203EE80 just before the collision sub_548300 call).
//   Adjacency list = WORDS at STRIDE 32 (0x20). Read the word at offset 0 of
//     each 32-byte entry; advance by 32. Sentinels: 0xFFFF = END of list,
//     0xFFFE = IMPASSABLE edge (cliff / ocean boundary); any other value is a
//     neighbour polygon index. (Confirmed at the sentinel-checking code near
//     0x548800: mov ax,[ecx]; cmp 0xFFFF je end; cmp 0xFFFE je skip;
//     mov ax,[ecx+0x20]; add ecx,0x20.)
//   => To BFS the whole mesh: read descBase, then for each poly N walk its
//      adjListPtr stride-32 collecting non-sentinel neighbours.
//
// OPEN EMPIRICAL QUESTION (the whole point of the RTWALK diagnostic): does the
//   0xFFFE edge set encode the Dollet-shelf isolation, or is the shelf blocked
//   ONLY by the wmsetus zone-trigger system? If the shelf is REACHABLE in this
//   graph, the runtime mesh will NOT by itself solve #70 and the .81 AABB stays.
//   Only a successful live read answers it -- never achieved as of .101.
//
// 0x0203EE80 = pointer to the CURRENT polygon's adjacency list (set just before
//   the collision sub_548300 call). Same stride-32 walk applies. (This address
//   ALSO aliases WM_POS_X earlier in this file -- the foot DWORDs and this adj
//   pointer occupy overlapping documented uses across game states; the RTWALK
//   probe reads it purely as a sanity check, not for BFS.)
//
// DISCARDED / UNRELIABLE (kept as constants only because existing diag code
// references them; do NOT build the BFS on these):
//   0x020426C0 = transformed polygon GEOMETRY (positions/normals, written by
//     sub_548300), NOT adjacency. Iterated stride 0x28 (40) elsewhere but holds
//     geometry, not neighbour lists. The "stride-40 adjacency" theory was wrong.
//   0x02045C40 = a polygon COUNT (dword) tied to the 0x020426C0 geometry array;
//     a live BAT read it as 11 at one tick (mesh not yet populated) so it is
//     NOT a dependable count for the descriptor array. Offline-confirmed total
//     polygon count is 473193 (ocean 315777, forest 16187).
//   0x0203FD5C = path-dependent: the collision resolver writes the current
//     polygon INDEX here, but sub_548AF0 writes 0 (ebx is xor'd and never
//     changed) -- which is why it read 0 during 40s of active driving. Do not
//     trust it as either an index or a pointer.
//   0x02040304 = current polygon index (word), only transiently non-zero during
//     a collision frame.
static const uintptr_t WM_RT_DESC_BASE    = 0x020402DC; // ptr to polygon descriptor array (READINESS SIGNAL: != 0 when mesh loaded)
static const int       WM_RT_DESC_STRIDE  = 12;          // bytes per polygon descriptor; +0 = adj-list ptr
static const int       WM_RT_ADJ_STRIDE   = 32;          // bytes per adjacency-list entry; word at +0 = neighbour idx / sentinel
static const uintptr_t WM_RT_CUR_ADJ_PTR  = 0x0203EE80;  // ptr to the current polygon's adjacency list
static const uintptr_t WM_RT_POLY_ARRAY   = 0x020426C0; // DISCARDED: transformed geometry, NOT adjacency (kept for legacy diag refs)
static const uintptr_t WM_RT_POLY_IDX     = 0x02040304; // current polygon index (word, per-frame, transient)
static const uintptr_t WM_RT_POLY_COUNT   = 0x02045C40; // a poly count tied to the geometry array -- UNRELIABLE (read 11 live)
static const uintptr_t WM_RT_POLY_PTR     = 0x0203FD5C; // path-dependent (0 in the sub_548AF0 path) -- do not trust
static const int       WM_RT_ENTRY_STRIDE = 40;          // geometry-array stride (NOT adjacency)
static const uint16_t  WM_RT_SENTINEL_END   = 0xFFFF;   // end of adjacency list
static const uint16_t  WM_RT_SENTINEL_NOADJ = 0xFFFE;   // impassable edge (cliff / ocean boundary)

// #67 BAT 2 (slope-aware mountains): per-fine-cell steepness = the elevation
// spread (max - min vertex elevation) of the wmx polygon whose centre is in
// the cell. A MOUNTAIN-class cell whose steepness exceeds WM_MTN_STEEP_BLOCK is
// an impassable steep face for foot/chocobo/car; gentler mountain cells are
// passes/plateaus and stay walkable, so the map doesn't over-fragment (blanket
// type-29 blocking isolated Esthar and split Edea/Centra -- real passes exist).
// Garden/Ragnarok ignore it (hover/fly). The threshold was calibrated offline
// against destination reachability -- at 256, every Galbadia and Balamb catalog
// destination stays reachable and the full reachable set is unchanged vs no
// blocking -- and is refined in-game via the [WM-CALIB] steepness trace (if the
// player is ever logged standing on a BLOCKED cell, the threshold is too low).
static uint16_t s_steepFine[WM_FINE_ROWS][WM_FINE_COLS];
static const uint16_t WM_MTN_STEEP_BLOCK = 256;

// #69 v0.18.3.90 (mechanism 2): per-fine-cell ABSOLUTE elevation = the average
// of the three vertex elevations (vwz, the int16 -z mesh value) of the wmx
// polygon whose centre is in the cell. DISTINCT from s_steepFine, which is the
// WITHIN-cell elevation SPREAD; s_elevFine is the cell's representative floor
// height, used to detect the height STEP BETWEEN adjacent cells. A false coast
// reads as walkable LAND per-cell but is a cliff at the EDGE between a beach
// cell and a ledge cell -- the grid is NODE-based, the cliff is an EDGE -- so
// per-cell class/steepness cannot see it. The planner blocks an inter-cell edge
// when |s_elevFine[a]-s_elevFine[b]| > WM_CLIMB_STEP, so the cliff self-excludes
// even though both cells are "land". This is the geometry-based replacement for
// the .85/.86 road crutch + the .81 Dollet AABB. Sign of vwz is irrelevant --
// only the absolute difference between adjacent cells matters.
static int16_t s_elevFine[WM_FINE_ROWS][WM_FINE_COLS];
// Max walkable inter-cell height step. Above this, a cell-to-cell edge is a
// cliff and is blocked. TUNABLE and not yet calibrated against the wmx
// elevation scale -- starting at 400 (above Dollet's walkable spread ~301, low
// enough to catch a real coastal cliff). The road exemption (road-to-road steps
// are never blocked) keeps the Timber->Dollet ribbon connected regardless, so
// an over-aggressive value cannot disconnect Dollet via the road while the
// [ELEVMAP] dump reveals the real cliff-step magnitude for calibration.
static const int WM_CLIMB_STEP = 400;

// #67 v0.18.3.81 (RESTORED v0.18.3.93): Dollet false-coast no-walk patch bounds
// (world-coord AABB). Build 5 (.92) retired these; the .92 BAT regressed (the
// clearance planner routed through the un-blocked ledge and wedged ~15km out),
// because the height-step guard catches the cliff face but not the ledge's
// continuous-elevation approach -- the original #67 "no geometric rule
// separates this ledge from real land" finding. So the patch + these bounds
// STAY. The ledge SE of Dollet reads as walkable LAND in wmx but is impassable
// on foot in-game; the canyon road one cell WEST is the real approach.
static const int32_t DOLLET_COAST_X0 = -24576;   // -> fine col 104 (west edge)
static const int32_t DOLLET_COAST_X1 = -17408;   // -> fine col 111 (east edge)
static const int32_t DOLLET_COAST_Y0 = -37888;   // -> fine row 59 (north edge)
static const int32_t DOLLET_COAST_Y1 = -27648;   // -> fine row 69 (south edge)

// #67 BAT 2 stage 2 (v0.18.3.59): per-fine-cell CLEARANCE = the Chebyshev
// distance (in cells, capped at 255) to the nearest BLOCKED cell (ocean OR
// steep-mountain). Computed once at grid-load by a multi-source BFS from every
// blocked cell. The drive planner uses it to route down the CENTRE of walkable
// corridors instead of the wall-hugging shortest path: a Dijkstra step into a
// low-clearance cell costs extra (WM_CLEAR_PENALTY per cell below
// WM_CLEAR_TARGET), so the route threads the canyon centre wherever any margin
// exists. Offline analysis of the Dollet canyon: the wall-hugging shortest path
// runs 21 cells within 1 cell of a wall; the clearance-weighted route cuts that
// to 15 and lifts average clearance 1.2 -> 1.7. Blocked cells have clearance 0;
// the field is computed against the foot/car blocker set (ocean + steep
// mountain), which is the relevant one for every planner-eligible drive.
static uint8_t s_clearFine[WM_FINE_ROWS][WM_FINE_COLS];
static const int WM_CLEAR_PENALTY = 20;  // #67 v0.18.3.70: extra Dijkstra cost per clearance-cell below target. Raised 6->20 to PREFER OPEN GROUND over short distance (Aaron: prioritize an open, clean path over minimizing distance). At 20 a wall/water-adjacent cell (clearance 1) costs ~81 vs 1 for open, so the route detours far to stay clear of edges -- the .69 BAT screenshot showed the drive sawing east-west along a shoreline with wide-open grass right beside it, because the old weight (6) let the route hug the coast.
static const int WM_CLEAR_TARGET  = 5;   // #67 v0.18.3.70: want >=5 cells of clearance (raised 3->5); below that the per-cell penalty applies, so the route stays well clear of water/mountain edges and only dips to low clearance at the unavoidable coastal destination itself

// ============================================================================
// Segment-region byte map (v0.14.94)
// ============================================================================
// 32x24 byte map from wmsetus.obj Section 2. Each byte is the region ID for
// one segment; the 0xFF08 region operands in s_triggerPrograms[]'s clauses
// reference these bytes. Loaded once at module init by LoadTriggerZones
// (which already reads the archive for diagnostic dumping — we extract
// Section 2's bytes into s_segmentRegionMap[] in the same pass to avoid
// duplicate I/O). Index as s_segmentRegionMap[row][col] where row=0..23 and
// col=0..31. The byte at file offset (row*32 + col) is the region for that
// segment; 0xFF means 'no region' (typically deep ocean cells); non-FF bytes
// are region IDs in the 0x00..0x45 range observed in the v0.14.93 BAT dump.
// (The 4-byte trailer at file offset 768, '00 00 00 00', is a section
// terminator and is not part of the data.)
//
// AD path planner uses this to construct goal sets: for a catalog target
// (X, Y), find the matching s_triggerPrograms[] entry, collect every cell
// in s_segmentRegionMap whose byte equals any matching clause's region
// operand — that's the equivalent trigger zone. Multi-target A* then runs
// from the player's current segment to the closest goal cell.
static uint8_t s_segmentRegionMap[WMX_SEG_ROWS][WMX_SEG_COLS];
static bool    s_segmentRegionLoaded = false;

// ============================================================================
// Path planner state (v0.14.94)
// ============================================================================
// A* on the 32x24 segment grid produces a sequence of segment cells from
// the player's start segment to a goal segment. The drive then follows the
// path one waypoint at a time, advancing the index when the player crosses
// into the current waypoint's segment. Replanned on world-map re-entry
// after a battle pause (random encounters drift the player off the path).
//
// Encoding: each waypoint is packed as (row << 8) | col into a uint16_t.
// 768 waypoints is a hard upper bound (visiting every segment exactly once);
// real paths are typically <40 waypoints across the longest reachable
// diagonal. s_drivePathPlanned distinguishes 'planner produced a path'
// (segment-membership arrival, waypoint steering) from 'planner declined or
// failed' (catalog-center steering, distance-based arrival fallback).
static const int DRIVE_PATH_MAX = WMX_PLAYABLE_SEGS;   // 768

static uint16_t s_drivePath[DRIVE_PATH_MAX];           // packed (row<<8)|col FINE-cell (1024u) waypoints
// v0.18.3.163: precise path in WORLD coords at the planner's native 128u resolution. The
// executor follows these so it threads canyons exactly instead of cutting corners across the
// cliffs the fine (1024u) route detoured around. Filled by PlanPathGrid; s_drivePathWorld says
// it's valid (other planners leave it false -> executor falls back to the 1024u fine cells).
static int32_t  s_drivePathWX[DRIVE_PATH_MAX];
static int32_t  s_drivePathWY[DRIVE_PATH_MAX];
static bool     s_drivePathWorld    = false;
static int      s_drivePathLen      = 0;
static int      s_drivePathIdx      = 0;
static bool     s_drivePathPlanned  = false;

// Goal-segment set for arrival detection. Populated when the planner picks
// a destination program: every cell in s_segmentRegionMap whose byte equals
// any matching clause's region operand. The player entering ANY of these
// via world-map exit counts as arrival. Stored as packed (row<<8)|col, max
// 768 entries (entire grid in the degenerate case).
static uint16_t s_driveGoalSegs[DRIVE_PATH_MAX];
static int      s_driveGoalSegCount = 0;

static inline uint16_t PackSeg(int row, int col)
{
    return (uint16_t)(((row & 0xFF) << 8) | (col & 0xFF));
}
static inline int UnpackRow(uint16_t s) { return (s >> 8) & 0xFF; }
static inline int UnpackCol(uint16_t s) { return  s       & 0xFF; }

// ============================================================================
// #80: mobile Balamb Garden auto-drive -- forward declarations
// ============================================================================
// The Garden subsystem lives in world_garden.inl, which is included AFTER
// world_map_drive_helpers.inl (it drives the key injector). Three earlier
// files need to call into it, so their entry points are declared here:
//   - world_map_segments.inl : LoadTerrainGrid feeds every wmx triangle to the
//     Garden rasterizer in the same pass it builds the foot grids.
//   - world_catalog.inl      : BuildDistanceCatalog filters and re-labels the
//     catalog while the player is piloting the Garden, and injects the
//     "Mobile Balamb Garden" marker while the player is on foot.
//   - world_map_announce.inl : appends the not-reachable-by-Garden suffix.
// A static function may be declared and defined later in the same translation
// unit, which is what world_map.cpp is.
static void Garden_BuildBegin();
static void Garden_FeedPoly(const uint8_t* poly, const int32_t* vwx,
                            const int32_t* vwy, const int16_t* vwz, int vertCount);
static void Garden_LogVehPos(uintptr_t addr, const char* tag,
                             int32_t vx, int32_t vy, int32_t vz);
static void Garden_BuildEnd();
static bool Garden_IsAboard();
static bool Garden_Active();
static void Garden_Update();
static void Garden_Toggle();
static void Garden_Stop(const char* reason);
static bool Garden_LeavingIsArrival(char* out, size_t n);
static void Garden_ComputeReach(int32_t px, int32_t py);
static bool Garden_CellReachable(int32_t gx, int32_t gy);
// Park table row. Defined here rather than in world_garden.inl because
// world_catalog.inl and world_map_announce.inl -- both included earlier --
// read its fields.
//   park_x/park_y : the cell nearest the destination that is simultaneously
//                   Garden-traversable, Garden-parkable (engine bit 0x02) and
//                   on the destination's own foot landmass.
//   walk_units    : straight-line distance from that cell to the destination
//                   marker, announced so the player knows the walk ahead.
//   reachable     : false means no such cell exists anywhere on that landmass.
struct GardenPark {
    const char* name;
    int32_t     park_x;
    int32_t     park_y;
    int32_t     walk_units;
    bool        reachable;
    // v0.20.59: Fisherman's Horizon is not a park-and-walk destination -- you
    // DOCK there, and driving the hull into FH is what triggers the docking.
    // For a drive_in destination park_x/park_y is the approach point, arrival
    // is the world map handing off to a field, and there is no walk to
    // announce. Aaron supplied the mechanism; it is not derivable from the
    // trigger table, whose only Garden clause (program 20, locID 0x0172) is a
    // different destination entirely (field 370 is Lunatic Pandora).
    bool        drive_in;
    // v0.20.60: WHERE to press for a drive_in destination. The location marker
    // is no use for this: FH's marker (48790,-1788) sits 2.6 km inside ground
    // the Garden mask never permits, so no amount of pressing at it can reach
    // it -- the nearest Garden-navigable water to that marker, anywhere on the
    // compass, is 2560 units away. An adjacency scan of every Garden-water cell
    // within 7.7 km of the marker finds exactly ONE place where Garden water
    // touches FH's landmass with no wall cell between them: a ~450-unit gap at
    // x ~ 45700, z ~ +320..+770. Every other cell of that coast is terrain 29,
    // the Esthar mountain wall Aaron described. That gap is NORTH of the
    // transcontinental railroad, whose bridge (terrain 27) severs the water in
    // a solid 512-unit band at z ~ -1536..-1920 -- and the v0.20.59 approach
    // sat at z = -3392, on the far side of the track, which is exactly the
    // failure Aaron reported. Zero here means "aim at the location marker".
    int32_t     dock_x;
    int32_t     dock_y;
    // v0.20.88: THIS BERTH IS REACHED BY DRIVING UP A BEACH THE MODEL CANNOT SEE.
    //
    // Aaron, on Shumi Village: "You go up the beach like any other. Let's have
    // the build try to drive up the beach and get as close as possible to the
    // Shumi Village. If it runs into walls or something like that so be it, but
    // we can at least use that data to survey the area around the village."
    //
    // The beach is in the data -- 53 terrain-9 polygons with b15=0xF7, the only
    // Garden-masked ground on the island's 7,034 foot cells -- but between it
    // and the water sits a skirt of terrain-29 polygons carrying NO masks at
    // all, so the model reads a 295-unit step against a 200 gate and refuses.
    // The engine does not. Rather than loosen the beach rule map-wide on a
    // guess (that rule is what fixed Balamb island in .84 and it is measured),
    // a beach_climb berth is allowed to be entered from adjacent water for its
    // OWN goal cell only. If the engine refuses after all, the drive fails at a
    // known coordinate with the trace running, which is the survey Aaron asked
    // for.
    bool        beach_climb;
};
// v0.52.0 (#109): defined in world_map_wmslots.inl, which is included after
// world_map_segments.inl (it needs WmSafeReadBytes) and called from inside it.
static void WmDumpWorldmapSlots();

static const GardenPark* Garden_ParkFor(const char* name);
// v0.20.89: ask about a BERTH, not a coordinate. A beach_climb berth is only
// reachable with its own exception in force, and v0.20.88 armed that exception
// in Garden_StartDrive alone -- so the CATALOG, which is built long before any
// drive starts, tested Shumi Village without it and hid the destination it had
// just been given. Every reachability question about a berth goes through here.
static bool Garden_BerthReachable(const GardenPark* gp);


// v0.19 #80: the savemap's per-vehicle position mirrors are 12-byte records of
// int32 X, int32 Y, int16 Z, int16 rotation -- NOT six int16s. Proven from a
// live [VEHDUMP]: car_pos read as words (-6076,-2,-14815,-1,-340,1966); read
// as int32 pairs that is X = 0xFFFEE844 = -71100, Y = -14815, i.e. the
// Galbadia Missile Base coast, which is where the car actually was. Read as
// int16 the X came out as -6076, an open-ocean coordinate 65 km away.
// The old int16 reader is correct only while |X| < 32768, which is why it
// survived every BAT so far (all of them on the Balamb continent).
static const uint32_t WMS_VEHPOS_X_OFF   = 0;    // int32
static const uint32_t WMS_VEHPOS_Y_OFF   = 4;    // int32
static const uint32_t WMS_VEHPOS_Z_OFF   = 8;    // int16
static const uint32_t WMS_VEHPOS_ROT_OFF = 10;   // int16

// ============================================================================
// v0.56.0 (#118): THE LOCOMOTION VERDICT -- what the player is ACTUALLY riding.
// ============================================================================
// State for world_map_locomotion.inl. That module is included after
// world_map_segments.inl (it needs GetWorldMapPosition / WmSafeReadBytes /
// GetActiveVehicleId), but segments.inl's GetWorldMapPosition_Active asks it a
// question, so LocoIsFoot is forward-declared here.
//
// The full account of why the animation byte cannot be trusted, and why a
// two-second "did the player move" window is a timer rather than a
// discriminator, is in world_map_locomotion.inl.
enum LocoVerdictKind { LOCO_UNKNOWN = 0, LOCO_FOOT = 1, LOCO_VEHICLE = 2 };
static LocoVerdictKind s_locoVerdict      = LOCO_UNKNOWN;
static int32_t         s_locoFootX        = 0;
static int32_t         s_locoFootY        = 0;
static bool            s_locoHadFoot      = false;
static int             s_locoLastRejected = -999;

// How close a vehicle's savemap mirror has to be to the player's foot position
// for it to second that vehicle's claim. 600 is the v0.20.56 value, kept: a
// parked vehicle sits beside the boarding point the frozen foot DWORDs hold,
// and a stale claim misses by tens of thousands of units (Aaron's 2026-08-21
// Ship claim missed by ~70,000), so nothing here is near the boundary.
static const double LOCO_MIRROR_AGREE_UNITS = 600.0;

static bool LocoIsFoot();
static void LocoTick();
static void LocoReset();
static bool LocoCorroborated(uint8_t vehicle, int32_t footX, int32_t footY,
                             int* outId, double* outMirrorDist);
