// field_archive_jsm_linepass.inl -- Line-entity REQ-following post-pass.
//
// A statement fragment #included at ONE point inside ScanJSMScripts, AFTER
// MapjumpResolver::Run -- it reads types the resolver may have changed, so the
// ordering is load-bearing. Extracted from field_archive_jsm_scan.inl in
// v0.62.0 for the 80 KB CI size gate. Do not compile independently; do not
// include anywhere else.

    // v0.62.0 (#123): REQ-following map exits, AFTER the mapjump resolver.
    //
    // Aaron, blocked at the end of the Lunar Base: "you have to go down a lift
    // to proceed but auto-drive failed to get me there. There was no specific
    // elevator or lift in the catalog." There was one -- "Exit to Lunar Base -
    // Pod 1" -- but it was attributed to `director1`, a script object with no
    // position, so the catalog held an exit at (0,0) and navigation answered
    // "Target not yet located."
    //
    // The thing the player steps on is `ele`, the red platform at (-30,30); its
    // script REQs director1's method 48, and THAT is where the MAPJUMP3 to field
    // 870 lives. Attributing the exit to the entity that triggers it gives the
    // exit a position for free, because that entity is a real object standing
    // somewhere.
    //
    // This rule existed since v0.07.84 and had never once fired as intended: it
    // ran inside the per-entity scan loop, so it could only see methods already
    // scanned, and directors are declared last. Add that s_entityReqs was empty
    // on every field (see the REQ recording in the scan) and the path was dead.
    //
    // v0.62.1: it runs HERE, after MapjumpResolver::Run, rather than before it.
    // The destination and its provenance both belong to the entity that owns the
    // MAPJUMP, and only the resolver knows them for certain -- on sscont2 it
    // resolves director1's destination through the variable block and marks it
    // INTERP. Copying the raw scan value instead left `ele` carrying a
    // destination the INF-gateway filter then rejected as probably-stale, and
    // the exit vanished from the catalog a second time: "Exit to the pod did not
    // show in the catalog in this test."
    for (int e2 = 0; e2 < outCount; e2++) {
        JSMEntityInfo& en = outEntities[e2];
        if (en.jsmCategory != 3) continue;
        // Only an entity the classifier had NOTHING to say about. The v0.07.84
        // rule also allowed NPC and BACKGROUND, but an entity that talks is an
        // NPC first and foremost -- retyping `Ghei1` on bcsaka1a from a person
        // you can speak to into a door loses more than it gains, and the exit it
        // triggers is a cutscene, not a way through.
        if (en.type != JSM_ENT_UNKNOWN) continue;
        int e3 = en.jsmIndex;
        if (e3 < 0 || e3 >= 128) continue;
        for (int r = 0; r < s_entityReqs[e3].count; r++) {
            int tgtEnt  = s_entityReqs[e3].calls[r].targetEntity;
            int tgtMeth = s_entityReqs[e3].calls[r].targetMethod;
            if (tgtEnt < 0 || tgtEnt >= totalEntities) continue;
            if (tgtMeth < groups[tgtEnt].startMethodIdx ||
                tgtMeth > groups[tgtEnt].startMethodIdx + groups[tgtEnt].methodCount) continue;
            if (tgtMeth < 0 || tgtMeth >= MAX_METHOD_MAPJUMPS) continue;
            if (!s_methodMapjumps[tgtMeth].found) continue;
            en.type  = JSM_ENT_MAP_EXIT;
            en.param = s_methodMapjumps[tgtMeth].destFieldId;
            // Take the OWNER's destination and provenance when it has them: the
            // resolver has already run and its answer is the authoritative one.
            for (int t3 = 0; t3 < outCount; t3++) {
                if (outEntities[t3].jsmIndex != tgtEnt) continue;
                if (outEntities[t3].type == JSM_ENT_MAP_EXIT) {
                    en.param           = outEntities[t3].param;
                    en.paramFromInterp = outEntities[t3].paramFromInterp;
                    // The script that CONTAINS the jump is the mechanism, not
                    // the door. With no position of its own it can only ever be
                    // catalogued at (0,0), which is what put an unreachable
                    // "Exit to Lunar Base - Pod 1" in front of Aaron. Now that
                    // the exit has a real position on the entity the player
                    // touches, retire the copy that has none.
                    if (!outEntities[t3].hasPosition) {
                        outEntities[t3].type = JSM_ENT_UNKNOWN;
                        Log::Field("FieldArchive: [JSMScan] ...and ent%d '%s', which holds the "
                                   "MAPJUMP but no position, is retired in its favour [v0.62.0]",
                                   tgtEnt, outEntities[t3].symName);
                    }
                }
                break;
            }
            // v0.62.2 (#123): the STORY GATE. Decode the guard the triggering
            // method opens with, if it has the canonical shape
            //   PSHM_B/W/L <addr> ; PSHN_L <literal> ; OP <cmp> ; JMPZ <n>
            // 55 of the REQ-follow triggers on the disc carry one, almost all of
            // them on var[256] -- FF8's story-progress word. The catalog reads the
            // live value and drops the exit while the guard is false, which is why
            // the Lunar Base pod stops being offered before you have spoken to
            // Ellone. Anything that is not exactly this shape gets no gate and the
            // exit behaves as it did.
            {
                int sm = s_entityReqs[e3].calls[r].srcMethod;
                if (!en.hasGate && sm >= 0 && sm < totalMethods) {
                    int ip0 = (int)(entryPoints[sm] & 0x7FFF);
                    if (ip0 >= 0 && ip0 < scriptDataDwords) {
                        JsmGate g = JsmDecodeGate(&scriptData[ip0],
                                                  (int)(scriptDataDwords - ip0));
                        if (g.ok && s_entityReqs[e3].calls[r].srcRel < g.skipTo) {
                            en.hasGate   = true;
                            en.gateAddr  = g.addr;
                            en.gateWidth = g.width;
                            en.gateOp    = g.op;
                            en.gateValue = g.value;
                            Log::Field("FieldArchive: [JSMScan] ...gated on var[%d] (%dB) "
                                       "op%d %d [v0.62.2]", en.gateAddr, (int)g.width,
                                       (int)en.gateOp, en.gateValue);
                        }
                    }
                }
            }
            Log::Field("FieldArchive: [JSMScan] REQ-follow: ent%d '%s' triggers ent%d "
                       "method%d, which MAPJUMPs to %d (interp=%d) -- it IS the exit [v0.62.0]",
                       e3, en.symName, tgtEnt, tgtMeth, en.param,
                       en.paramFromInterp ? 1 : 0);
            break;
        }
    }

    // v0.12.24 / v0.17.7.5.4: REQ-following for Line entity interaction detection.
    // If a Line entity REQs another entity that has dialog opcodes or ext dispatch,
    // the Line is dual-purpose (exit + interaction). Mark it with hasDialogReqTarget
    // so the catalog can distinguish this from the (much more common) case where
    // a Line uses extended dispatch in its OWN script for non-dialog purposes
    // (sound, particle effects, animation). v0.17.7.5.4 split the previous unified
    // hasExtDispatch flag into two: hasExtDispatch (own 0x1C usage, set in opcode
    // scan) and hasDialogReqTarget (dialog REQ target, set HERE). The catalog uses
    // hasDialogReqTarget for the dual-purpose check.
    //
    // The previous `if (outEntities[i].hasExtDispatch) continue;` early-exit was
    // dropped: we now run REQ-following for ALL Line entities regardless of own
    // ext-dispatch usage, so lines like bgroad_5 squalls (own 0x1C true, REQ
    // target dialog false) get correctly classified as pure exits.
    for (int i = 0; i < outCount; i++) {
        if (outEntities[i].jsmCategory != 1) continue;  // Line entities only
        int e = outEntities[i].jsmIndex;
        if (e >= 128) continue;
        // Check if this Line entity REQs any entity with dialog/ext dispatch.
        // First try resolved REQ targets.
        bool reqsInteractive = false;
        for (int r = 0; r < s_entityReqs[e].count && !reqsInteractive; r++) {
            int tgt = s_entityReqs[e].calls[r].targetEntity;
            if (tgt >= 0 && tgt < 128) {
                if (s_hasDialogAny[tgt] || s_hasExtDispatchArr[tgt])
                    reqsInteractive = true;
            }
        }
        // Fallback: if entity has unresolved REQ opcodes (stack lost track),
        // check if ANY Interactive Object entity exists on this field.
        // Interactive Objects are specifically the targets of dual-purpose Line
        // entity interactions (dormitory bed/desk/wardrobe, etc.).
        if (!reqsInteractive && s_reqOpcodeCount[e] > 0 && s_entityReqs[e].count == 0) {
            for (int ii = 0; ii < outCount && !reqsInteractive; ii++) {
                if (outEntities[ii].type == JSM_ENT_INTERACTIVE_OBJECT)
                    reqsInteractive = true;
            }
        }
        if (reqsInteractive) {
            outEntities[i].hasDialogReqTarget = true;
            Log::Field("FieldArchive: [JSMScan] REQ-interact: Line ent%d '%s' REQs interactive entity -> hasDialogReqTarget=1",
                       e, outEntities[i].symName);
            // v0.61.0: and that makes it an INTERACTION, not an event.
            //
            // The Line classification cascade sends a line with no dialog of its
            // own but with REQ opcodes to LINE_EVENT, which the catalog treats as
            // transparent and never surfaces. Until v0.59.0 that almost never
            // happened, because `foundExtDispatch` caught these first -- but that
            // flag fired on opcode 0x1C, which occurs in 92.8% of all entities, and
            // v0.59.0 removed it once the decode showed 0x1C is a no-op. Removing a
            // wrong signal without replacing what it was standing in for is a
            // regression, and this is the one it caused: on the Lunar Base control
            // room (sscont1) the moon-scope terminal is the line `moonscope`, whose
            // own script says nothing and whose touchOn method REQs six entities.
            // Aaron: "There is also a control panel you are supposed to look at /
            // operate and I couldn't find it."
            //
            // hasDialogReqTarget is the exact form of what extDispatch was guessing
            // at -- REQ-following found this line dispatches to an entity that
            // actually talks. LINE_CAMERA_PAN is deliberately left alone: a line
            // that drives BGDRAW/scroll is doing something visual.
            if (outEntities[i].type == JSM_ENT_LINE_EVENT) {
                outEntities[i].type = JSM_ENT_LINE_INTERACTIVE;
                Log::Field("FieldArchive: [JSMScan] Line ent%d '%s' promoted "
                           "LINE_EVENT -> LINE_INTERACTIVE: it dispatches to an entity "
                           "that talks [v0.61.0]", e, outEntities[i].symName);
            }
        }

        // v0.62.0 (#123): A LINE THE FIELD SWITCHES OFF AND SOMEBODY SWITCHES ON.
        //
        // v0.61.0 restored the moon-scope terminal by promoting on
        // hasDialogReqTarget -- but s_entityReqs was empty on every field then
        // (see the REQ recording above), so what actually fired was the "does
        // this field contain ANY Interactive Object" fallback beside it. With
        // REQ targets resolving properly that coincidence is gone, and
        // `moonscope` REQs six entities of which none has a single dialog
        // opcode. The promotion was right; the reason given for it was not.
        //
        // The real signal is in the line's own script. `moonscope` calls LINEOFF
        // in its init and LINEON in a method that `irvine`, `selphie` and
        // `quistis` each REQ from a method the SYM names `moon_lineon0` --
        // talking to any of them arms the terminal. Both halves are load-time
        // facts: the init disables the line, and another entity holds a
        // reference to it. A passive cutscene tripwire has neither. 86 lines on
        // the disc carry both, among them the Missile Base valves (bgmd1_4
        // 'Valve1'/'Valve2') and the Galbadia Garden hall lines.
        if (outEntities[i].type == JSM_ENT_LINE_EVENT &&
            e < 128 && s_lineInitOff[e] && s_isReqTarget[e]) {
            outEntities[i].type = JSM_ENT_LINE_INTERACTIVE;
            Log::Field("FieldArchive: [JSMScan] Line ent%d '%s' promoted "
                       "LINE_EVENT -> LINE_INTERACTIVE: disabled by its own init "
                       "and switched on from another script [v0.62.0]",
                       e, outEntities[i].symName);
        }

        // v0.17.8.8: Save-line detection, signal (b) -- REQ to a save point.
        // A Line that REQs an entity classified SAVE_POINT (or with a save*/svpt
        // SYM name, in case that entity was classified MAP_EXIT because its
        // script also contains a MAPJUMP -- e.g. bghall_1 'saveline0') is the
        // walk-on trigger that opens the save menu. Flag the Line so the catalog
        // labels it "Save Point". The Line already has a position (its SETLINE
        // center), so no save-point positioning is needed.
        if (!outEntities[i].isSaveLine) {
            for (int r = 0; r < s_entityReqs[e].count && !outEntities[i].isSaveLine; r++) {
                int tgt = s_entityReqs[e].calls[r].targetEntity;
                for (int t2 = 0; t2 < outCount; t2++) {
                    if (outEntities[t2].jsmIndex != tgt) continue;
                    bool tgtIsSave = (outEntities[t2].type == JSM_ENT_SAVE_POINT) ||
                                     (_strnicmp(outEntities[t2].symName, "save", 4) == 0) ||
                                     (_strnicmp(outEntities[t2].symName, "svpt", 4) == 0);
                    if (tgtIsSave) {
                        outEntities[i].isSaveLine = true;
                        outEntities[i].hasDialogReqTarget = true;  // ensure it surfaces
                        Log::Field("FieldArchive: [JSMScan] save-line(req): Line ent%d '%s' "
                                   "REQs save point ent%d '%s' -> isSaveLine=1 [v0.17.8.8]",
                                   e, outEntities[i].symName, tgt, outEntities[t2].symName);
                        break;
                    }
                }
            }
        }
    }

