// ============================================================================
// v0.124.0 (#centra): THE LADDER CLIMB SOUND -- THE GAME'S OWN
// ============================================================================
// Aaron: "why can't we utilize the same climbing sound as the rest of the
// ladders in the game?" We can. v0.123.0 synthesised knocks on the assumption
// that reaching the engine's audio would be fragile; the assumption was never
// tested and it was wrong. See ladder_cue_model.inl for the routine, its four
// call sites, and the branch that picks the ladder sound from the movement
// mode -- which means the mod chooses no sound, no id and no volume. It asks
// the engine for the noise this character on this surface would make.
//
// Nothing here reads the entity array or the player index: the caller decides
// which entity is climbing and passes its block through. That is what lets
// tests/ladder_cue_compile.cpp build this unit on the host, which
// field_navigation.cpp's own translation unit cannot be.

typedef void (__cdecl* LadderStepSoundFn)(int entityPtr, int foot, int volume, int pan);

static LadderStepSoundFn s_ladderStepSound = nullptr;
static bool  s_ladderStepChecked = false;
static DWORD s_ladderStepLastMs  = 0;
static bool  s_ladderStepEver    = false;
static int   s_ladderStepIndex   = 0;

// SEH-guarded compare of the routine's prologue. A patched or repacked exe
// fails it and the cue stays silent, which is the only safe answer when the
// alternative is calling into the middle of something else.
static bool LadderStepSigMatches(uintptr_t addr)
{
    bool ok = false;
    __try {
        const unsigned char* p = (const unsigned char*)addr;
        ok = true;
        for (int i = 0; i < LADDER_STEP_SIG_LEN; i++) {
            if (p[i] != LADDER_STEP_SIG[i]) { ok = false; break; }
        }
    } __except (EXCEPTION_EXECUTE_HANDLER) { ok = false; }
    return ok;
}

// Resolved once. Returns null when the signature does not match.
static LadderStepSoundFn LadderStepSound()
{
    if (s_ladderStepChecked) return s_ladderStepSound;
    s_ladderStepChecked = true;
    if (LadderStepSigMatches((uintptr_t)LADDER_STEP_ADDR))
        s_ladderStepSound = (LadderStepSoundFn)(uintptr_t)LADDER_STEP_ADDR;
    return s_ladderStepSound;
}

// SEH-guarded call. The routine touches the entity block and the audio mixer;
// a fault here must not take the game down over a sound cue.
static void LadderStepInvoke(LadderStepSoundFn fn, int entityPtr, int foot)
{
    __try {
        fn(entityPtr, foot, LADDER_STEP_VOLUME, LADDER_STEP_PAN);
    } __except (EXCEPTION_EXECUTE_HANDLER) { }
}

// Called every frame with the player's entity block and its movement mode.
// Returns true when a step was played, so the caller can log it.
static bool LadderStepPoll(int entityPtr, int mode, unsigned nowMs)
{
    const bool climbing = LadderModeIsClimb(mode);
    if (!climbing) { s_ladderStepEver = false; s_ladderStepIndex = 0; return false; }
    if (!LadderStepDue(climbing, nowMs, (unsigned)s_ladderStepLastMs, s_ladderStepEver))
        return false;
    LadderStepSoundFn fn = LadderStepSound();
    if (fn == nullptr) return false;
    s_ladderStepLastMs = (DWORD)nowMs;
    s_ladderStepEver   = true;
    LadderStepInvoke(fn, entityPtr, LadderStepFoot(s_ladderStepIndex++));
    return true;
}
