// ladder_cue_test.cpp -- the ladder climb cue (#centra, v0.123.0).
//
// Every assertion was written against a mutant. The opcode-to-mode table is
// read out of FF8_EN.exe, not guessed, and the test says so by pinning it.
#include <cstdio>
#include <cmath>

#include "ladder_cue_model.inl"

static int g_fail = 0;
static void CHECK(bool c, const char* w) { if (!c) { printf("FAIL: %s\n", w); g_fail++; } }

int main()
{
    // THE FOUR OPCODES, and the movement modes their handlers set. This is the
    // evidence the whole build rests on: crtower3's `laddw0` runs 0x024 and
    // crtower1's `p0_ladup0` runs 0x027 -- the two Aaron says make a noise --
    // and crroof1's silent roof ladder runs 0x026.
    CHECK(LadderOpcodeIsMove(0x024) && LadderOpcodeIsMove(0x025) &&
          LadderOpcodeIsMove(0x026) && LadderOpcodeIsMove(0x027),
          "all four ladder opcodes are recognised");
    CHECK(!LadderOpcodeIsMove(0x023), "0x023 is not one");
    CHECK(!LadderOpcodeIsMove(0x028), "0x028 is not one");
    CHECK(LadderOpcodeMode(0x024) == 2, "0x024 sets mode 2");
    CHECK(LadderOpcodeMode(0x025) == 3, "0x025 sets mode 3");
    CHECK(LadderOpcodeMode(0x026) == 3, "0x026 sets mode 3 -- the silent roof ladder");
    CHECK(LadderOpcodeMode(0x027) == 4, "0x027 sets mode 4");
    CHECK(LadderOpcodeMode(0x023) == -1, "an opcode outside the set has no mode");

    // AND EVERY ONE OF THOSE MODES IS A CLIMB THE MOD WILL SOUND. The roof
    // ladder's mode 3 reaches the engine's ladder-sound branch exactly as the
    // tower ladders' 3 and 4 do -- it was never missing the sound, only the
    // call. A mutant that sounded just the modes the engine already calls for
    // would leave the one ladder this build exists for as quiet as before.
    CHECK(LadderModeIsClimb(LadderOpcodeMode(0x024)), "mode 2 is a climb");
    CHECK(LadderModeIsClimb(LadderOpcodeMode(0x026)), "mode 3 -- the roof ladder -- is a climb");
    CHECK(LadderModeIsClimb(LadderOpcodeMode(0x027)), "mode 4 is a climb");
    CHECK(!LadderModeIsClimb(0) && !LadderModeIsClimb(1),
          "standing and walking are not, so ordinary steps are left to the engine");

    // The volume and pan are the engine's own callers' -- 0x7F and 0x80 appear
    // at 0x004783D6 and 0x00478420; pan 0x80 (centre) at all four call sites.
    CHECK(LADDER_STEP_VOLUME == 0x7F, "the volume the engine's callers pass");
    CHECK(LADDER_STEP_PAN == 0x80, "centre pan, as all four call sites pass");
    CHECK(LADDER_STEP_ADDR == 0x00520260u, "the routine's address");
    CHECK(LADDER_STEP_SIG_LEN == 15, "fifteen bytes of prologue are checked");
    CHECK(LADDER_STEP_SIG[0] == 0x83 && LADDER_STEP_SIG[1] == 0xEC &&
          LADDER_STEP_SIG[2] == 0x10, "starting with its stack frame");

    printf("ladder_cue_test: fail=%d\n", g_fail);
    return g_fail ? 1 : 0;
}
