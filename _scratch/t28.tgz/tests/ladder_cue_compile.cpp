// ladder_cue_compile.cpp -- host probe for the ladder climb sound (#centra, v0.124.0).
//
// WHY THIS EXISTS. The climb sound lives in field_navigation.cpp's include
// chain, and that translation unit cannot be syntax-checked on the host -- it
// pulls in DirectInput and inline assembly, the same standing limitation
// src/world_map.cpp has carried for years. So the sound was split into its own
// includable unit with one dependency the caller keeps to itself (which entity
// is climbing, and what its movement mode says), and this probe builds the
// rest: the signature check, the resolve-once, the per-frame step spacing and
// the alternating feet.
//
// It matters more here than in most places, because the thing being built calls
// a HARDCODED ENGINE ADDRESS. The signature check is the only thing standing
// between a repacked exe and a jump into the middle of something else, and it
// is checked here against both the real prologue and a corrupted one.
#include <windows.h>
#include <cstdio>
#include <cstring>
#include <cstdint>

namespace Log { static void Field(const char*, ...) {} }

#include "ladder_cue_model.inl"
#include "ladder_cue.inl"

static int g_fail = 0;
static void CHECK(bool c, const char* w) { if (!c) { printf("FAIL: %s\n", w); g_fail++; } }

// A stand-in for the engine routine, plus a copy of its prologue so the
// signature check has something real to match.
static int g_calls = 0, g_lastFoot = -1, g_lastVol = -1, g_lastPan = -1, g_lastEnt = 0;
static void __cdecl FakeStepSound(int ent, int foot, int vol, int pan)
{ g_calls++; g_lastEnt = ent; g_lastFoot = foot; g_lastVol = vol; g_lastPan = pan; }

int main()
{
    printf("ladder_cue.inl compiles\n");

    // THE MODES. Read out of the four ladder opcode handlers; 2, 3 and 4 are
    // ladder moves and nothing else is. Kills a mutant that treats every
    // non-zero mode as a climb, which would play a step for ordinary walking.
    CHECK(LadderModeIsClimb(2) && LadderModeIsClimb(3) && LadderModeIsClimb(4),
          "the three ladder movement modes are climbs");
    CHECK(!LadderModeIsClimb(0) && !LadderModeIsClimb(1) && !LadderModeIsClimb(5),
          "standing, walking and anything else are not");

    // THE SIGNATURE CHECK, against the real sixteen bytes and a corrupted copy.
    unsigned char good[32]; memcpy(good, LADDER_STEP_SIG, LADDER_STEP_SIG_LEN);
    unsigned char bad[32];  memcpy(bad,  LADDER_STEP_SIG, LADDER_STEP_SIG_LEN);
    bad[LADDER_STEP_SIG_LEN - 1] ^= 0xFF;
    CHECK(LadderStepSigMatches((uintptr_t)good), "the real prologue matches");
    CHECK(!LadderStepSigMatches((uintptr_t)bad),
          "a prologue that differs in its LAST byte does not");
    bad[0] ^= 0xFF;
    CHECK(!LadderStepSigMatches((uintptr_t)bad), "nor one that differs in its first");
    // A null or unmapped address is caught by the SEH guard in the shipped
    // build. It is NOT asserted here: the host shim compiles __try away, so the
    // only thing this probe could prove is that Linux segfaults, which it does.

    // THE SPACING. One step, then silence until the interval has passed.
    CHECK(LadderStepDue(true, 1000, 0, false), "the first step of a climb plays");
    CHECK(!LadderStepDue(true, 1100, 1000, true), "the next frame does not");
    CHECK(!LadderStepDue(true, 1000 + LADDER_STEP_MS - 1, 1000, true), "nor just inside the interval");
    CHECK(LadderStepDue(true, 1000 + LADDER_STEP_MS, 1000, true), "the next rung does");
    CHECK(!LadderStepDue(false, 99999, 0, false), "and nothing plays when not climbing");
    // "Never stepped" is a flag, not a zero timestamp -- under a clock reading
    // 0 a zero sentinel means every step stamps 0 and the spacing never
    // engages, which is what the v0.123.0 probe caught in its first minute.
    CHECK(LadderStepDue(true, 0, 0, false), "a climb at tick zero still steps");
    CHECK(!LadderStepDue(true, 0, 0, true), "and still spaces the ones after it");

    // FEET ALTERNATE, as the engine's own callers do.
    CHECK(LadderStepFoot(0) == 0 && LadderStepFoot(1) == 1 &&
          LadderStepFoot(2) == 0 && LadderStepFoot(3) == 1, "the feet alternate");

    // THE POLL, driven end to end against the stand-in.
    s_ladderStepSound = FakeStepSound;   // stand in for the resolve
    s_ladderStepChecked = true;
    s_ladderStepEver = false; s_ladderStepIndex = 0; s_ladderStepLastMs = 0;
    g_calls = 0;

    CHECK(!LadderStepPoll(0x1234, 0, 5000), "no step while standing");
    CHECK(LadderStepPoll(0x1234, 3, 5000), "a step when the climb starts");
    CHECK(g_calls == 1, "exactly one");
    CHECK(g_lastEnt == 0x1234, "on the entity it was given");
    CHECK(g_lastVol == LADDER_STEP_VOLUME && g_lastPan == LADDER_STEP_PAN,
          "with the volume and centre pan the engine's own callers pass");
    CHECK(g_lastFoot == 0, "starting on one foot");
    CHECK(!LadderStepPoll(0x1234, 3, 5000 + 10), "not again on the next frame");
    CHECK(LadderStepPoll(0x1234, 3, 5000 + LADDER_STEP_MS), "again a rung later");
    CHECK(g_lastFoot == 1, "on the other foot");

    // ENDING THE CLIMB RESETS IT, so the next climb starts on its first frame
    // instead of waiting out an interval that began minutes ago.
    CHECK(!LadderStepPoll(0x1234, 0, 6000), "the climb ends");
    CHECK(LadderStepPoll(0x1234, 2, 6001), "and the next one steps immediately");

    // WITH NO RESOLVED ROUTINE, NOTHING IS CALLED AND NOTHING FAULTS -- the
    // signature check failing must be silent, not a crash.
    s_ladderStepSound = nullptr;
    s_ladderStepEver = false;
    const int before = g_calls;
    CHECK(!LadderStepPoll(0x1234, 3, 9000), "an unresolved routine plays nothing");
    CHECK(g_calls == before, "and calls nothing");

    printf(g_fail ? "ladder_cue_compile: FAILED %d\n" : "ladder_cue_compile: OK\n", g_fail);
    return g_fail ? 1 : 0;
}
