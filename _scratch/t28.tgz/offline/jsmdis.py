"""FF8 .jsm disassembler.

Word encoding is read straight out of FF8_EN.exe (see
src/field_archive_jsm_decode.inl, decoder 0x00530760):
    (w & 0xFF000000) == 0  ->  BARE opcode, opcode = w   (this is how every
                               opcode above 0xFF is encoded)
    otherwise              ->  opcode = w >> 24, param = sign_extend24(w)

File layout: +4 u16 entriesOff, +6 u16 codeOff; groups are u16 from +8, with
count = w & 0x7F and start = w >> 7 (an index into the entries array).  Entity
declaration order in the .sym equals the groups SORTED BY START; entries[start]
is the entity header and entries[start+1+m] is method m.  Entry values carry a
0x8000 flag the engine masks off (`and eax,0x7fff` at 0x0052BF98).
"""
import os, re, struct, sys

def load_opnames(path):
    d = {}
    for m in re.finditer(r'case\s+0x([0-9A-Fa-f]+):\s*return\s+"([A-Z_0-9]+)"', open(path).read()):
        d[int(m.group(1), 16)] = m.group(2)
    # corrections proven by decode.inl's walk of the opcode table
    d[0x004] = 'CALL'; d[0x005] = 'PROLOG'; d[0x006] = 'RET'
    d[0x007] = 'PSHN_L'; d[0x008] = 'PSHL'; d[0x00A] = 'PSHM_B'
    d[0x00B] = 'POPM_B'; d[0x00C] = 'PSHM_W'; d[0x00D] = 'POPM_W'
    d[0x00E] = 'PSHM_L'; d[0x00F] = 'POPM_L'; d[0x013] = 'PSHN_L2'
    d[0x001] = 'OPER'; d[0x002] = 'JMP'; d[0x003] = 'JPF'
    return d

OPER = {0:'ADD',1:'SUB',2:'MUL',3:'DIV',4:'MOD',5:'NEG',6:'==',7:'>',8:'>=',9:'<',10:'<=',
        11:'!=',12:'AND',13:'OR',14:'XOR',15:'NOT'}

class J: pass

def load(d, name):
    raw = open(os.path.join(d, name + '.jsm'), 'rb').read()
    j = J(); j.name = name; j.raw = raw
    eoff, coff = struct.unpack_from('<HH', raw, 4)
    j.eoff, j.coff = eoff, coff
    j.groups = []
    for i in range((eoff - 8)//2):
        w = struct.unpack_from('<H', raw, 8+i*2)[0]
        j.groups.append((w & 0x7F, w >> 7))
    j.entries = [struct.unpack_from('<H', raw, eoff+i*2)[0] & 0x7FFF
                 for i in range((coff-eoff)//2)]
    j.code = [struct.unpack_from('<I', raw, coff+i*4)[0]
              for i in range((len(raw)-coff)//4)]
    j.order = []
    sym = os.path.join(d, name + '.sym')
    if os.path.exists(sym):
        for l in open(sym, errors='ignore').read().splitlines():
            l = l.strip()
            if '::' not in l: continue
            e, m = l.split('::', 1)
            if not j.order or j.order[-1][0] != e: j.order.append((e, [m]))
            else: j.order[-1][1].append(m)
    return j

def dec(w):
    if (w & 0xFF000000) == 0: return (w, None)
    op = w >> 24; p = w & 0xFFFFFF
    if p & 0x800000: p -= 0x1000000
    return (op, p)

def methods(j):
    out = []
    by_start = sorted(range(len(j.groups)), key=lambda g: j.groups[g][1])
    for i, g in enumerate(by_start):
        cnt, start = j.groups[g]
        ename = j.order[i][0] if i < len(j.order) else 'grp%d' % g
        ml    = j.order[i][1] if i < len(j.order) else []
        for m in range(cnt):
            idx = start + 1 + m
            if idx >= len(j.entries): continue
            lo = j.entries[idx]
            nxt = [e for e in j.entries if e > lo]
            hi = min(nxt) if nxt else len(j.code)
            out.append((ename, ml[m] if m < len(ml) else 'm%d' % m, m, lo, hi))
    return out

def fmt(j, i, ops):
    op, p = dec(j.code[i])
    nm = ops.get(op, 'OP_0x%03X' % op)
    if p is None: return "%5d  %-14s" % (i, nm)
    if op == 0x01: return "%5d  %-14s %s" % (i, nm, OPER.get(p, p))
    if op in (0x02, 0x03): return "%5d  %-14s %+d  -> %d" % (i, nm, p, i+p)
    if op in (0x0A,0x0B,0x0C,0x0D,0x0E,0x0F):
        return "%5d  %-14s var[%d]   (0x%08X)" % (i, nm, p, 0x01CFE9B8+p)
    return "%5d  %-14s %d" % (i, nm, p)

def main():
    ops = load_opnames(os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                    '..', 'src', 'field_archive_jsm_opnames.inl'))
    d, n = sys.argv[1], sys.argv[2]
    want = sys.argv[3:] if len(sys.argv) > 3 else None
    j = load(d, n)
    print("# %s  groups=%d entries=%d code=%d" % (n, len(j.groups), len(j.entries), len(j.code)))
    for e, m, mi, lo, hi in methods(j):
        if want and e not in want and ('%s::%s' % (e, m)) not in want: continue
        print("\n=== %s::%s  (method %d)  code[%d..%d]" % (e, m, mi, lo, hi))
        for i in range(lo, min(hi, len(j.code))):
            print("   " + fmt(j, i, ops))

if __name__ == '__main__':
    main()
