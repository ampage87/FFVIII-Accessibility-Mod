// rag_approach_test.cpp -- the braked approach, and the strike an orbit cannot fake.
#include <cstdio>
#include "rag_ground_pure.inl"
#include "rag_approach_pure.inl"

static int bad = 0;
static void chk(bool ok, const char* w) { if (!ok) { printf("  BAD: %s\n", w); bad++; } }

int main()
{
    printf("rag_approach_test\n");

    // --- altitude: UP WAS NEVER A THROTTLE ----------------------------------
    //
    // Aaron: "You ascend and descend using the up and down arrow keys." The
    // 15:15 log settles the rest -- dist 1806 -> 1471 -> 1037 with keys=----
    // and nothing pressed. The ship flies forward by itself.
    chk(RagAltitudeWant(true, 50000.0, RAG_BRAKE_DIST, true, 200, 200) == RAG_ALT_CLIMB,
        "**the airship does not climb on the cruise** -- Aaron: \"make sure the "
        "airship ascends to max altitude when doing auto-drive so it doesn't get "
        "stuck against things on land\", and holding UP on the long haul is what "
        "the old code was doing BY ACCIDENT while 151 km crossings sailed over "
        "everything");
    chk(RagAltitudeWant(true, RAG_BRAKE_DIST, RAG_BRAKE_DIST, true, 5000, 200) == RAG_ALT_CLIMB,
        "the climb stops before the approach begins");

    // On the approach it comes down, and only as far as the engine will accept.
    chk(RagAltitudeWant(true, 1000.0, RAG_BRAKE_DIST, true, 3000, 200) == RAG_ALT_DESCEND,
        "**the ship stays high on the final approach** -- it cannot be set down "
        "until |shipZ - groundH| is under the 200 of 0x54B860");
    chk(RagAltitudeWant(true, 1000.0, RAG_BRAKE_DIST, true, 200, 200) == RAG_ALT_DESCEND,
        "a gap exactly at the set-down gate stops descending; the engine REFUSES at 200");
    chk(RagAltitudeWant(true, 1000.0, RAG_BRAKE_DIST, true, 199, 200) == RAG_ALT_HOLD,
        "**it keeps descending once it is low enough to land** -- pressing DOWN into "
        "the ground is not an improvement");

    // Unreadable altitude must not guess in either direction.
    chk(RagAltitudeWant(true, 1000.0, RAG_BRAKE_DIST, false, 0, 200) == RAG_ALT_HOLD,
        "**an unreadable altitude still commands a climb or a dive** -- with no "
        "measurement the honest move is to leave the axis alone");

    // Foot and car have no altitude at all.
    chk(RagAltitudeWant(false, 50000.0, RAG_BRAKE_DIST, true, 200, 200) == RAG_ALT_HOLD,
        "on foot or in the car this commands an altitude change");

    // --- forward is its own axis now ---------------------------------------
    chk(RagForwardWant(true, 0, 96) == true,   "a ship dead on the bearing does not go forward");
    chk(RagForwardWant(true, 96, 96) == true,  "a ship at the edge of the cone does not go forward");
    chk(RagForwardWant(true, 97, 96) == false,
        "**it flies forward while still turning** -- turning under power is what a "
        "wide arc is made of, and an arc is what put the ship in orbit at v0.85.0");
    chk(RagForwardWant(false, 0, 96) == false,
        "**the flight throttle fires for the car** -- A is the car's gas pedal too, "
        "and its own path already presses it");

    // --- the aim cone -------------------------------------------------------
    chk(RagSteerCone(true, 1000.0, 576) == RAG_FINAL_CONE &&
        RAG_FINAL_CONE < 576,
        "**the braked approach uses the car's ~50-degree cone** -- at this speed "
        "fifty degrees of bearing error is a mile of arc");
    chk(RagSteerCone(true, 50000.0, 576) == 576, "the long haul uses the tight cone");
    chk(RagSteerCone(false, 1000.0, 576) == 576, "on foot the cone changed");

    // --- the strike ---------------------------------------------------------
    // The BAT: moving 3000 units a window while orbiting at a constant distance.
    chk(RagStuckStrike(true, 3043.0, 100.0, 1618.0, 1645.0, 100.0) == true,
        "**three thousand units of orbit counts as progress** -- that is the 12:59 "
        "trace exactly, and it is why the drive ran fifty-eight seconds without ever "
        "reaching Stuck check 6/6");
    chk(RagStuckStrike(true, 3043.0, 100.0, 958.0, 1645.0, 100.0) == false,
        "687 units closer in a window scores a strike");
    chk(RagStuckStrike(true, 0.0, 100.0, 500.0, -1.0, 100.0) == false,
        "**the first check of a flight is a strike** -- there is no previous reading, "
        "and starting a drive one strike down is wrong");

    // On foot and in the car the rule is untouched -- movement, not progress.
    chk(RagStuckStrike(false, 0.0, 100.0, 1618.0, 1645.0, 100.0) == true,
        "on foot, not moving no longer scores a strike");
    chk(RagStuckStrike(false, 3043.0, 100.0, 1618.0, 1645.0, 100.0) == false,
        "**on foot, moving without closing distance now scores a strike** -- the "
        "reverse-burst recovery #67 tuned depends on those strikes being spent slowly");

    // --- blocked: commanded forward, and did not move -----------------------
    //
    // The 15:15 BAT, sixteen identical lines: dist=1806 hdg=2255 off=65 cone=96
    // gas=1 keys=U---. Asked to go, did not go, for fifteen seconds.
    chk(RagBlockedStrike(true, 5, 0.0, 100.0) == true,
        "**forward commanded on five ticks with zero movement is not read as "
        "blocked** -- that is the 15:15 log exactly, 1,806 units short of the "
        "Fisherman's Horizon pad with UP held");

    chk(RagBlockedStrike(true, 0, 0.0, 100.0) == false,
        "**a ship that was never asked to go reads as blocked** -- pivoting in place "
        "is what the tight cone asks for, and calling that an obstruction would end "
        "every drive that has to turn");

    chk(RagBlockedStrike(true, 5, 3000.0, 100.0) == false,
        "a ship moving 3000 units reads as blocked");
    chk(RagBlockedStrike(false, 5, 0.0, 100.0) == false,
        "**on foot or in the car this fires** -- a walker genuinely wedges on terrain "
        "and #67's reverse-burst recovery is what handles that; this rule is about a "
        "hull no polygon can stop");

    // Two strikes, not six: the signature is unambiguous and eighteen seconds of
    // pressing into a wall helps nobody.
    chk(RAG_BLOCKED_MAX == 2,
        "**the blocked bound is not two** -- six is the ordinary give-up, and it is six "
        "because a car's stall is ambiguous; this one is not");

    // --- settling: arriving is not the same as being able to land -----------
    //
    // The 16:18 BAT reached both pads and arrived 2,472 and 2,654 units up, where
    // 0x54B860 refuses to set the ship down at anything from 200. "Land the
    // Ragnarok to go in" at a height where landing is impossible.
    chk(RagMustSettle(true, true, 2472, 200) == true,
        "**arriving 2,472 units up is treated as arrived** -- that is the Deep Sea "
        "line from the 16:18 BAT, and the engine will not set the ship down there");
    chk(RagMustSettle(true, true, 2654, 200) == true, "the Fisherman's Horizon arrival is accepted at 2,654 up");
    chk(RagMustSettle(true, true, 200, 200) == true,
        "a gap exactly at the gate is accepted; the engine REFUSES at 200");
    chk(RagMustSettle(true, true, 199, 200) == false,
        "**a ship low enough to land is held up settling** -- it has arrived, and "
        "the last act is his");

    chk(RagMustSettle(true, false, 5000, 200) == false,
        "**an unreadable altitude holds the arrival open** -- with no measurement "
        "there is no way to know it will ever close, and a drive that will not end "
        "is worse than one that ends honestly");
    chk(RagMustSettle(false, true, 5000, 200) == false, "the car settles");

    // The hold is bounded: over water the engine's ground height reads 0 and the
    // gap can never close. v0.80.0 spent a whole build on that lesson.
    chk(RagSettleExpired(20000, 5000, 12000) == true,
        "**a settle that cannot close never expires** -- over water the gap never "
        "closes, and the drive would hang forever pressing DOWN");
    chk(RagSettleExpired(10000, 5000, 12000) == false, "the settle expires before its bound");
    chk(RagSettleExpired(99999, 0, 12000) == false,
        "**a drive that is not settling reads as expired** -- zero means not started, "
        "not started long ago");

    printf("rag_approach_test: %s (%d bad)\n", bad ? "FAILED" : "OK", bad);
    return bad ? 1 : 0;
}
