// drive_progress_model.inl -- IS THE DRIVE ACTUALLY GETTING ANYWHERE?
//
// v0.131.1 (#centra). Aaron, after the ladder finally worked both ways: "only
// issue now is the auto-drive getting stuck when headed to that ladder... there
// was another part where I got stuck as well when headed to Ruins 7. See if you
// can make object avoidance / getting out of being stuck more intelligent."
//
// The two episodes in that log are NOT the same failure, and the recovery
// machinery treated them identically -- which is why neither got better.
//
// **crroof1, 19:15:26-19:15:36, tri 34: AN OSCILLATION.** The player alternates
// between exactly two positions, 30 units apart, forever:
//
//     pp=(1476,-187)  trigRedir=1  finalDelta=(16.9, 7.3)   kb=DR
//     pp=(1498,-167)  trigRedir=1  finalDelta=(-8.9,-3.9)   kb=UL
//
// He IS moving. The trigger-line avoidance is projecting the steer parallel to a
// line it does not want him to cross, and the tangential component flips sign
// each time he crosses back -- a textbook two-cycle. Every nudge in the recovery
// ladder pushes perpendicular to a corridor edge, which is orthogonal to the
// thing actually going wrong, and after five of them he cancelled.
//
// **crtower3, 19:15:07-19:15:14, tri 89: A HARD PIN.** The opposite signature:
//
//     pp=(-1305,-34)  trigRedir=0  moveDist=0  lX=989  for seven seconds
//
// He is not moving AT ALL. The commanded direction is into geometry, and the
// four-mode perpendicular escape guesses at which way is clear rather than
// finding out.
//
// So: one monitor, two verdicts. Path length and net displacement over a short
// window separate them completely -- oscillating means a long path with no net
// distance; pinned means no path at all -- and each verdict gets the remedy that
// matches it. Both are decided from the player's own position history, which
// costs nothing and cannot be wrong about whether he is getting anywhere.

static const int   DRIVE_PROG_SAMPLES   = 32;    // ~0.5 s of ticks
static const float DRIVE_PROG_NET_EPS   = 45.0f; // net displacement that counts as "nowhere"
static const float DRIVE_PROG_PATH_MIN  = 120.0f;// path length that counts as "moving"
static const float DRIVE_PROG_STALL_EPS = 6.0f;  // path length that counts as "not moving"

struct DriveProgressTracker {
    float x[DRIVE_PROG_SAMPLES];
    float y[DRIVE_PROG_SAMPLES];
    int   count;
    int   next;
};

static void DriveProgressClear(DriveProgressTracker* t)
{
    if (!t) return;
    t->count = 0;
    t->next  = 0;
}

static void DriveProgressPush(DriveProgressTracker* t, float px, float py)
{
    if (!t) return;
    t->x[t->next] = px;
    t->y[t->next] = py;
    t->next = (t->next + 1) % DRIVE_PROG_SAMPLES;
    if (t->count < DRIVE_PROG_SAMPLES) t->count++;
}

static bool DriveProgressFull(const DriveProgressTracker* t)
{
    return t && t->count >= DRIVE_PROG_SAMPLES;
}

// Distance between the oldest and newest sample: how far the drive actually got.
static float DriveProgressNet(const DriveProgressTracker* t)
{
    if (!DriveProgressFull(t)) return 0.0f;
    const int oldest = t->next;                                  // ring is full
    const int newest = (t->next + DRIVE_PROG_SAMPLES - 1) % DRIVE_PROG_SAMPLES;
    const float dx = t->x[newest] - t->x[oldest];
    const float dy = t->y[newest] - t->y[oldest];
    return sqrtf(dx * dx + dy * dy);
}

// Total ground covered over the same window: how hard it tried.
static float DriveProgressPath(const DriveProgressTracker* t)
{
    if (!DriveProgressFull(t)) return 0.0f;
    float sum = 0.0f;
    for (int i = 1; i < DRIVE_PROG_SAMPLES; i++) {
        const int a = (t->next + i - 1) % DRIVE_PROG_SAMPLES;
        const int b = (t->next + i) % DRIVE_PROG_SAMPLES;
        const float dx = t->x[b] - t->x[a];
        const float dy = t->y[b] - t->y[a];
        sum += sqrtf(dx * dx + dy * dy);
    }
    return sum;
}

// Walking a long way and ending where you started. crroof1's two-cycle: 30 units
// each tick, ~900 units of path, ~30 units of net.
static bool DriveIsOscillating(const DriveProgressTracker* t)
{
    if (!DriveProgressFull(t)) return false;
    return DriveProgressPath(t) >= DRIVE_PROG_PATH_MIN &&
           DriveProgressNet(t)  <= DRIVE_PROG_NET_EPS;
}

// Not moving at all. crtower3's wall: moveDist=0 for seven seconds.
static bool DriveIsStalled(const DriveProgressTracker* t)
{
    if (!DriveProgressFull(t)) return false;
    return DriveProgressPath(t) <= DRIVE_PROG_STALL_EPS;
}

// ============================================================================
// THE ESCAPE: SWEEP THE HEADING, DO NOT GUESS AT IT
// ============================================================================
// Against a wall the mod knows one thing for certain -- the direction it is
// asking for does not work. So it stops asking for that one and tries the rest,
// nearest first, alternating sides so a wall on either hand is found in two
// probes rather than four. The list ends at 180 degrees because a heading that
// works nowhere in a full sweep is a pathing problem, not a steering one, and
// the recovery ladder above is where that belongs.
static const int DRIVE_PROBE_ANGLES[] = { 30, -30, 60, -60, 90, -90, 135, -135, 180 };
static const int DRIVE_PROBE_COUNT = (int)(sizeof(DRIVE_PROBE_ANGLES) /
                                           sizeof(DRIVE_PROBE_ANGLES[0]));
// Long enough for a step to register at 60 Hz, short enough that a full sweep
// is under two seconds.
static const int DRIVE_PROBE_TICKS = 12;

static int DriveProbeAngle(int idx)
{
    if (idx < 0 || idx >= DRIVE_PROBE_COUNT) return 0;
    return DRIVE_PROBE_ANGLES[idx];
}

static void DriveRotateSteer(float dx, float dy, int degrees, float* outX, float* outY)
{
    const float r = (float)degrees * 3.14159265f / 180.0f;
    const float c = cosf(r), s = sinf(r);
    if (outX) *outX = dx * c - dy * s;
    if (outY) *outY = dx * s + dy * c;
}

// The redirect that caused the oscillation is suspended, not deleted: a few
// seconds of steering straight at the waypoint is enough to break a two-cycle,
// and the avoidance is still wanted for the rest of the drive.
static const int DRIVE_REDIRECT_SUPPRESS_TICKS = 180;   // ~3 s
