// tests/winshim/windows.h -- just enough of the Win32 surface for a HOST SYNTAX
// CHECK of the Win32-only translation units. Never linked, never run: the point
// is that a change to field_archive.cpp (which cannot be compiled on the build
// host otherwise) is still parsed and type-checked by the gate.
#pragma once
#include <cstdint>
#include <cstddef>
#include <cstdio>
#include <cstring>
typedef unsigned long  DWORD;
typedef int            BOOL;
typedef unsigned char  BYTE;
typedef unsigned short WORD;
typedef void*          HANDLE;
typedef void*          HMODULE;
typedef void*          HWND;
typedef const char*    LPCSTR;
typedef char*          LPSTR;
typedef long           LONG;
typedef unsigned int   UINT;
typedef intptr_t       LPARAM;
typedef uintptr_t      WPARAM;
#define WINAPI
// v0.62.3.1: enough of the Win32 pointer typedefs for MinHook's header, so the
// gate can syntax-check field_navigation.cpp -- the translation unit that
// consumes field_catalog.inl. It could not before, which is exactly how a
// v0.62.3 identifier that resolves in the scanner's TU and in the harness but
// not in the mod's reached Aaron's compiler with every local gate green.
typedef void            VOID;
typedef void*           LPVOID;
typedef const wchar_t*  LPCWSTR;
typedef wchar_t*        LPWSTR;
typedef wchar_t         WCHAR;
#define __cdecl
#define TRUE  1
#define FALSE 0
#define MAX_PATH 260
#define INVALID_HANDLE_VALUE ((HANDLE)(intptr_t)-1)
#define EXCEPTION_EXECUTE_HANDLER 1
// libstdc++ already defines __try (bits/exception_defines.h) but NOT __except,
// so these have to be guarded separately -- a single #ifndef __try around both
// silently leaves __except undefined the moment <string> or <vector> is included.
#ifndef __try
#define __try    try
#endif
#ifndef __except
#define __except(x) catch (...)
#endif
// v0.63.1: a probe that RUNS a Win32 translation unit (rather than only
// syntax-checking it) needs a clock and a keyboard it can drive. Define
// WINSHIM_HOST_CLOCK / WINSHIM_HOST_INPUT before including and supply your own;
// leave them alone and the inert stubs below keep the syntax gate working.
#ifndef WINSHIM_HOST_CLOCK
inline DWORD  GetTickCount() { return 0; }
#endif
#define VK_SHIFT   0x10
#define VK_CONTROL 0x11
#define VK_MENU    0x12
#define VK_RETURN  0x0D
#define VK_F9      0x78
#define VK_OEM_2   0xBF
#ifndef WINSHIM_HOST_INPUT
inline short  GetAsyncKeyState(int) { return 0; }
#endif
inline DWORD  GetLastError() { return 0; }
inline void   Sleep(DWORD) {}
inline HMODULE GetModuleHandleA(LPCSTR) { return nullptr; }
inline int    _stricmp(const char* a, const char* b) { return strcasecmp(a, b); }
inline int    _strnicmp(const char* a, const char* b, size_t n) { return strncasecmp(a, b, n); }
#include <cmath>
inline DWORD GetModuleFileNameA(HMODULE, LPSTR buf, DWORD n) { if (n) buf[0] = '\0'; return 0; }
