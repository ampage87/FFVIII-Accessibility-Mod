// ladder_cue_test.cpp -- the ladder climb cue (#centra, v0.123.0).
//
// Every assertion was written against a mutant. The opcode-to-mode table is
// read out of FF8_EN.exe, not guessed, and the test says so by pinning it.
#include <cstdio>
#include <cmath>

#include "ladder_cue_model.inl"

static int g_fail = 0;
static void CHECK(bool c, const char* w) { if (!c) { printf("FAIL: %s\n", w); g_fail++; } }

int main()
{
    // THE FOUR OPCODES, and the movement modes their handlers set. This is the
    // evidence the whole build rests on: crtower3's `laddw0` runs 0x024 and
    // crtower1's `p0_ladup0` runs 0x027 -- the two Aaron says make a noise --
    // and crroof1's silent roof ladder runs 0x026.
    CHECK(LadderOpcodeIsMove(0x024) && LadderOpcodeIsMove(0x025) &&
          LadderOpcodeIsMove(0x026) && LadderOpcodeIsMove(0x027),
          "all four ladder opcodes are recognised");
    CHECK(!LadderOpcodeIsMove(0x023), "0x023 is not one");
    CHECK(!LadderOpcodeIsMove(0x028), "0x028 is not one");
    CHECK(LadderOpcodeMode(0x024) == 2, "0x024 sets mode 2");
    CHECK(LadderOpcodeMode(0x025) == 3, "0x025 sets mode 3");
    CHECK(LadderOpcodeMode(0x026) == 3, "0x026 sets mode 3 -- the silent roof ladder");
    CHECK(LadderOpcodeMode(0x027) == 4, "0x027 sets mode 4");
    CHECK(LadderOpcodeMode(0x023) == -1, "an opcode outside the set has no mode");

    // AND EVERY ONE OF THOSE MODES IS A CLIMB THE MOD WILL SOUND. The roof
    // ladder's mode 3 reaches the engine's ladder-sound branch exactly as the
    // tower ladders' 3 and 4 do -- it was never missing the sound, only the
    // call. A mutant that sounded just the modes the engine already calls for
    // would leave the one ladder this build exists for as quiet as before.
    CHECK(LadderModeIsClimb(LadderOpcodeMode(0x024)), "mode 2 is a climb");
    CHECK(LadderModeIsClimb(LadderOpcodeMode(0x026)), "mode 3 -- the roof ladder -- is a climb");
    CHECK(LadderModeIsClimb(LadderOpcodeMode(0x027)), "mode 4 is a climb");
    CHECK(!LadderModeIsClimb(0) && !LadderModeIsClimb(1),
          "standing and walking are not, so ordinary steps are left to the engine");

    // The volume and pan are the engine's own callers' -- 0x7F and 0x80 appear
    // at 0x004783D6 and 0x00478420; pan 0x80 (centre) at all four call sites.
    CHECK(LADDER_STEP_VOLUME == 0x7F, "the volume the engine's callers pass");
    CHECK(LADDER_STEP_PAN == 0x80, "centre pan, as all four call sites pass");
    CHECK(LADDER_STEP_ADDR == 0x00520260u, "the routine's address");
    CHECK(LADDER_STEP_SIG_LEN == 15, "fifteen bytes of prologue are checked");
    CHECK(LADDER_STEP_SIG[0] == 0x83 && LADDER_STEP_SIG[1] == 0xEC &&
          LADDER_STEP_SIG[2] == 0x10, "starting with its stack frame");

    // ================================================================
    // v0.125.0: THE CADENCE IS LEARNED FROM THE GAME, NOT PICKED BY US.
    // ================================================================
    // Aaron: "the climbing sounds were very fast compared to the way they
    // usually sound on a ladder." The old constant was 260 ms and it was a
    // guess; the fix is that no number in this file is a guess any more.
    CHECK(LADDER_STEP_MS_DEFAULT > 260 * 1.5,
          "the default is no longer the 260 ms Aaron heard as very fast");
    // v0.126.0: and it is no longer the 700 ms placeholder either. The hook
    // measured fourteen consecutive gaps on crtower on 2026-08-28 and eleven of
    // them were 468-469 ms, so THAT is the starting value -- pinned here so the
    // next person to change it has to argue with the measurement.
    CHECK(LADDER_STEP_MS_DEFAULT == 469,
          "the default is the 469 ms the engine was measured at");
    CHECK(LadderGapIsSample(LADDER_STEP_MS_DEFAULT),
          "the default is itself a plausible sample, not an out-of-range placeholder");
    CHECK(LADDER_STEP_MS_MIN < LADDER_STEP_MS_DEFAULT &&
          LADDER_STEP_MS_DEFAULT < LADDER_STEP_MS_MAX,
          "and it sits inside the range learning is allowed to reach");
    CHECK(LadderClampInterval(10) == LADDER_STEP_MS_MIN, "clamped up from absurdly fast");
    CHECK(LadderClampInterval(99999) == LADDER_STEP_MS_MAX, "clamped down from a pause");
    CHECK(LadderClampInterval(600) == 600, "a plausible interval passes through");

    // A GAP ONLY COUNTS IF IT COULD BE A STRIDE. The engine plays two feet, and
    // when both cross on the same frame the gap is a handful of milliseconds --
    // learning from that would drive the cue back to a machine-gun rattle,
    // which is exactly the bug being fixed.
    CHECK(!LadderGapIsSample(8), "two feet on one frame is not a cadence sample");
    CHECK(!LadderGapIsSample(5000), "nor is a five-second pause between ladders");
    CHECK(LadderGapIsSample(LADDER_STEP_MS_MIN), "the boundary values are samples");
    CHECK(LadderGapIsSample(LADDER_STEP_MS_MAX), "at both ends");
    CHECK(LadderGapIsSample(650), "and an ordinary climbing gap is one");

    // ================================================================
    // v0.127.0: A GAP THE ENGINE SKIPPED IS NOT A SLOWER LADDER.
    // ================================================================
    // Folding, first. 953 and 1359 ms are the engine missing one and two
    // strides at ~469 ms, not the animation changing speed.
    CHECK(LadderFoldGap(469, 469) == 469, "a gap at the believed pace is itself");
    CHECK(LadderFoldGap(953, 469) == 476, "a doubled gap folds in half");
    CHECK(LadderFoldGap(1359, 452) == 453, "a tripled one folds in three");
    CHECK(LadderFoldGap(1344, 444) == 448, "and so does the other one in the log");
    // 672 IS THE ONE THAT MATTERS. It is the gap that must be REJECTED, and at a
    // +/-35% band its halving (336) squeaks in -- a fold that finds some
    // quotient in range for every gap is a licence to believe anything.
    CHECK(LadderFoldGap(672, 452) == 0,
          "672 ms folds to nothing plausible and is dropped, not halved");
    CHECK(LadderFoldGap(900, 600) == 0, "and so does any gap around 1.5x the pace");
    CHECK(LadderFoldGap(8, 469) == 0, "two feet on one frame folds to nothing");
    CHECK(LadderFoldGap(9000, 469) == 0, "and neither does a nine-second pause");
    CHECK(LadderFoldGap(469, 0) == 0, "a zero belief folds nothing");
    // Four times the pace is beyond what the fold will reach, on purpose: past
    // three skipped strides the gap is a pause, not a rhythm.
    CHECK(LadderFoldGap(469 * 4, 469) == 0, "a quadrupled gap is a pause, not a stride");

    // THE MEAN IS WEIGHTED TWO-TO-ONE toward what is already believed, and
    // v0.125.0's "first sample outright" rule is gone: since v0.126.0 the
    // starting value IS a measurement, so there is no guess to escape.
    CHECK(LadderLearnInterval(600, 700) == 633,
          "samples are weighted two-to-one toward what we already measured");
    // A gap around 1.5x the pace reads equally well as one slow stride or two
    // fast ones. Both readings fall outside the band, so it teaches nothing.
    CHECK(LadderLearnInterval(600, 900) == 600,
          "an ambiguous 1.5x gap is dropped rather than split the difference");
    CHECK(LadderLearnInterval(LADDER_STEP_MS_DEFAULT, 12) == LADDER_STEP_MS_DEFAULT,
          "a gap that folds to nothing changes nothing");
    CHECK(LadderLearnInterval(469, 953) == 471,
          "a doubled gap teaches the pace it doubled, not the double");
    {
        // Ten identical samples converge on the truth rather than drifting.
        unsigned iv = LADDER_STEP_MS_DEFAULT;
        for (int i = 0; i < 30; i++) iv = LadderLearnInterval(iv, 520);
        CHECK(iv >= 515 && iv <= 520, "a steady rhythm is converged on");
    }
    {
        // THE REGRESSION, REPLAYED. These are the nineteen gaps the hook
        // recorded on crtower3 and crroof1 between 16:39 and 16:54, in order.
        // v0.126.0's running mean reached 970 ms on them and handed 586 ms to
        // the silent roof ladder -- a quarter slower than the ladder it was
        // imitating. Folded, the same nineteen never leave the pace Aaron
        // called normal.
        static const unsigned RUN[] = { 469, 390, 469, 469, 406, 500, 953, 375,
                                        438, 531, 422, 453, 672, 407, 1359, 1344,
                                        422, 406, 438 };
        unsigned iv = LADDER_STEP_MS_DEFAULT, worst = 0;
        for (unsigned i = 0; i < sizeof(RUN) / sizeof(RUN[0]); i++) {
            iv = LadderLearnInterval(iv, RUN[i]);
            if (LadderAbsDiff(iv, LADDER_STEP_MS_DEFAULT) >
                LadderAbsDiff(worst, LADDER_STEP_MS_DEFAULT)) worst = iv;
        }
        CHECK(worst <= 560, "the run's own gaps never drag the cadence to 586 ms again");
        CHECK(iv >= 380 && iv <= 520, "and it ends where the game actually is");
    }

    // THE MOD STAYS QUIET WHILE THE ENGINE IS SOUNDING THE LADDER. This is the
    // second bug v0.125.0 closes: v0.124.0 stepped on EVERY ladder, doubling
    // the ones crtower3 and crtower1 already sound. Aaron's Centra log has only
    // the roof ladder in it, so he has not heard this yet.
    CHECK(!LadderEngineIsStepping(false, 10000, 0, 700),
          "an engine that has not stepped on this climb suppresses nothing");
    CHECK(LadderEngineIsStepping(true, 10000, 9800, 700),
          "a step 200 ms ago means the game is sounding this ladder itself");
    // v0.127.0 widened the slack from two intervals to four. At two, the 1359 ms
    // hole in crtower3's own rhythm at 16:51:22 let the mod cut in -- the log
    // says "2 mod steps, engine sounded it itself" on a ladder the mod was
    // supposed to leave alone.
    CHECK(LadderEngineIsStepping(true, 10000, 10000 - 1359, 452),
          "the longest hole the engine has ever left does NOT let the mod cut in");
    CHECK(LadderEngineIsStepping(true, 10000, 10000 + 1 - 700 * 4, 700),
          "slack runs to four intervals");
    CHECK(!LadderEngineIsStepping(true, 10000, 10000 - 700 * 4, 700),
          "and past that a real dropout hands the ladder back to the mod");

    // THE STEP SCHEDULE. A climb waits out the mount animation before its first
    // step -- which is also what keeps the mod from landing a step on top of the
    // engine's opening one on a ladder that turns out to be sounded.
    CHECK(!LadderStepDue(false, 10000, 9000, 0, false, 700),
          "not climbing, no step");
    CHECK(!LadderStepDue(true, 9000 + LADDER_STEP_GRACE_MS - 1, 9000, 0, false, 700),
          "the first step waits out the grace period");
    CHECK(LadderStepDue(true, 9000 + LADDER_STEP_GRACE_MS, 9000, 0, false, 700),
          "and arrives the moment it expires");
    CHECK(!LadderStepDue(true, 10699, 9000, 10000, true, 700),
          "later steps hold for the learned interval");
    CHECK(LadderStepDue(true, 10700, 9000, 10000, true, 700),
          "and land on it");
    // The interval is a parameter now, so a learned value actually reaches the
    // schedule. A mutant that kept using a constant would pass every test above.
    CHECK(!LadderStepDue(true, 10700, 9000, 10000, true, 1100),
          "a slower learned cadence really does space the steps further apart");
    CHECK(LadderStepDue(true, 11100, 9000, 10000, true, 1100), "landing later");

    // The 260 ms regression, stated as a scenario rather than a constant: a
    // five-second climb at the default must not produce anything like the
    // eighteen steps Aaron heard.
    {
        int steps = 0; unsigned last = 0; bool ever = false;
        for (unsigned t = 0; t <= 5000; t += 16) {
            if (LadderStepDue(true, t, 0, last, ever, LADDER_STEP_MS_DEFAULT)) {
                steps++; last = t; ever = true;
            }
        }
        // v0.126.0: at 469 ms after a 400 ms mount this is ten steps, which is
        // exactly what crroof1's silent ladder logged on the run Aaron called
        // the normal pace. Eighteen was the sound of the guess.
        CHECK(steps == 10, "a five-second climb is ten steps, as crroof1 logged");
        CHECK(steps <= 8 + 2, "a five-second climb is no longer eighteen steps");
        CHECK(steps >= 4, "but it is still audibly a climb");
    }

    // ================================================================
    // v0.126.0: THE MODE THE ROUTINE WILL SOUND AS A LADDER.
    // ================================================================
    // sub_00520260 branches to the ladder sound on mode 3 and mode 4 only;
    // everything else falls through to the terrain footstep table. Mode 2 is
    // a climb -- 0x024 sets it, and 0x024 is crtower3's ladder going DOWN --
    // but it is NOT a mode that routine calls a ladder, which is the whole of
    // why Aaron heard the way up and not the way down.
    CHECK(LadderModeSoundsAsLadder(3), "mode 3 reaches the ladder branch");
    CHECK(LadderModeSoundsAsLadder(4), "mode 4 reaches the ladder branch");
    CHECK(!LadderModeSoundsAsLadder(2),
          "mode 2 does NOT -- it falls through to the footstep table");
    CHECK(LadderModeIsClimb(2) && !LadderModeSoundsAsLadder(2),
          "mode 2 is a climb the mod sounds and a mode the engine will not: "
          "the descent needs the byte presented as 3");
    CHECK(LadderModeSoundsAsLadder((int)LADDER_MODE_SOUNDS_AS),
          "the mode the cue presents is one the routine accepts");
    CHECK(LadderOpcodeMode(0x024) == 2 && !LadderModeSoundsAsLadder(LadderOpcodeMode(0x024)),
          "0x024 -- crtower3's laddw0, the way down -- is the silent one");

    printf("ladder_cue_test: fail=%d\n", g_fail);
    return g_fail ? 1 : 0;
}
