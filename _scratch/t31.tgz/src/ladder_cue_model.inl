// ladder_cue_model.inl -- CONFIRMING THAT A CLIMB IS ACTUALLY HAPPENING
//
// v0.123.0 (#centra). Aaron, after the roof ladder finally worked: "that
// particular ladder on the roof for some reason does not have the ladder
// climbing sound that is normally played. Can we institute that sound effect
// for that ladder as well? It is useful for a blind player to confirm they are
// actually climbing."
//
// THE GAME IS NOT WITHHOLDING A SOUND -- IT IS RUNNING A DIFFERENT OPCODE.
// Field scripts move a character along a ladder with one of four opcodes, and
// all four do the same thing to the entity's movement mode byte at +0x23C:
//
//     0x024  handler 0x00525740  ->  mode 2
//     0x025  handler 0x00525900  ->  mode 3
//     0x026  handler 0x00525A30  ->  mode 3
//     0x027  handler 0x00525B60  ->  mode 4
//
// and the Centra Ruins uses three of them. crtower3's `laddw0` runs 0x024,
// crtower3's `ladup0` and crtower1's `p0_ladup0` run 0x027 -- and those are the
// ladders Aaron says make the noise. crroof1's `lad0`, the roof ladder, is the
// only one in the ruins that runs **0x026**, and it is the only one that is
// silent. The sound belongs to the movement mode, the mode belongs to the
// opcode, and the opcode is Square's choice in a script we do not patch.
//
// WHICH MEANS THE FIX IS NOT TO CHASE THEIR SOUND. Making the mod fire the
// engine's own SE would leave every OTHER ladder in the game that happens to
// use 0x025 or 0x026 just as silent, and it would tie an accessibility cue to
// an internal audio path that changes nothing about whether the player can hear
// it over the music. The mod plays its own cue on **every** ladder move
// instead, so "am I climbing?" has one answer everywhere rather than an answer
// that depends on which of four interchangeable opcodes a 1999 script author
// happened to type.
//
// NO DIRECTION IN THE CUE, and that is a decision rather than an omission. The
// obvious guess is that the opcodes come in up/down pairs -- an older comment in
// this project even names 0x025 LADDERUP and 0x026 LADDERDOWN. The disc says
// otherwise: crtower3's `ladup0` (up) runs 0x027 while its `laddw0` (down) runs
// 0x024, and crroof1's `lad0` -- which v0.116.0 established travels UP, from
// z=18403 to z=19496 -- runs the one supposedly called LADDERDOWN. The opcode
// does not encode the direction, so the cue does not claim to.

static const int LADDER_OPCODE_FIRST = 0x024;
static const int LADDER_OPCODE_LAST  = 0x027;
static const int LADDER_OPCODE_COUNT = LADDER_OPCODE_LAST - LADDER_OPCODE_FIRST + 1;

static bool LadderOpcodeIsMove(int opcode)
{
    return opcode >= LADDER_OPCODE_FIRST && opcode <= LADDER_OPCODE_LAST;
}

// The entity movement mode each one sets, read out of the four handlers. Kept
// so the next person who wonders why one ladder is quiet can check the claim
// instead of taking it on trust.
static int LadderOpcodeMode(int opcode)
{
    switch (opcode) {
        case 0x024: return 2;
        case 0x025: return 3;
        case 0x026: return 3;
        case 0x027: return 4;
        default:    return -1;
    }
}

// THE CUE IS THE GAME'S OWN STEP SOUND, not one of ours.
//
// The first cut of this build synthesised three knocks, on the reasoning that
// chasing the engine's audio path would be fragile. Aaron: "why can't we
// utilize the same climbing sound as the rest of the ladders in the game?" --
// and he was right, because that reasoning was an assumption I had not tested.
// The engine's own routine is one call:
//
//     sub_00520260(entityPtr, foot /*0|1*/, volume /*0x7F*/, pan /*0x80*/)
//
// -- cdecl, four arguments, four call sites in the exe (0x004783D6, 0x00478420,
// 0x0052A31C, 0x0052A35C), each cleaning with `add esp, 0x10` and passing
// volume 0x7F or 0x40 with pan 0x80 for centre.
//
// It picks the sound ITSELF from the entity's movement mode at +0x23C:
//
//     0x00520354  cmp dl, 3 / je  -> 0x005203BB
//     0x00520359  cmp dl, 4 / je  -> 0x005203BB
//     0x005203BB  push vol; push pan; push 0x400000; push 0x3F
//                 call 0x0046B2A0            <- the ladder step, sound id 0x3F
//
// with every other mode falling through to the terrain footstep table at
// 0x01CE4BFC. So the mod does not choose a sound, hardcode an id, or guess at a
// volume: it asks the engine to make the noise this character on this surface
// would make, and on a ladder that is the ladder sound the other ladders play.
//
// WHICH MEANS THE ROOF LADDER WAS NEVER MISSING THE SOUND -- IT WAS MISSING THE
// CALL. Mode 3 reaches the ladder branch exactly as mode 4 does. The routine is
// driven by footstep event frames in the climbing animation, and crroof1's
// `lad0` runs animation 3 (`0x031 3`) where crtower3's runs animation 6. One
// has the step frames and one does not. Nothing about the sound is unavailable
// to us; it simply was not being asked for.
//
// SO THE MOD ASKS, ON EVERY LADDER, for as long as the climb lasts. The
// movement mode is the engine's own statement that a ladder move is in
// progress, so polling it needs no timer to guess a duration: steps play while
// the mode is a ladder mode and stop the frame it clears.
// v0.126.0 (#centra): MODE 2 IS WHY THE WAY DOWN IS SILENT.
//
// Aaron: "I only heard it when going up, not when going down." The answer is
// already written at the top of this file and nobody had joined the two halves
// of it up. sub_00520260 picks its sound from the movement mode byte:
//
//     0x00520354  cmp dl, 3 / je  -> 0x005203BB   <- the ladder branch
//     0x00520359  cmp dl, 4 / je  -> 0x005203BB
//                 ...everything else falls through to the terrain footstep table
//
// **ONLY 3 AND 4 REACH THE LADDER SOUND.** And the opcode table says 0x024 sets
// mode 2 -- 0x024 being crtower3's `laddw0`, which is the ladder going DOWN.
// So on a descent the mod has been asking the engine for a sound all along and
// the engine has been answering with a footstep, because it was asked in a mode
// that is not a ladder as far as that routine is concerned. Ten calls, no ladder
// noise, exactly what Aaron heard.
//
// THE FIX DOES NOT HARDCODE THE SOUND ID, which is the whole reason this cue
// calls the engine instead of playing its own knock. It presents mode 3 for the
// length of the call and puts the byte back, so the routine takes the branch it
// would have taken on any ascent and still chooses the id, the volume and the
// surface itself. That also generalises past this one ladder: ANY mode a ladder
// opcode sets now sounds like a ladder, which is what "repurpose this for other
// silent ladders" actually needs -- mode 2 is not special, it is just the first
// one that turned up.
static const unsigned      LADDER_MODE_OFFSET    = 0x23C;
static const unsigned char LADDER_MODE_SOUNDS_AS = 3;

// True when sub_00520260 will take its ladder branch for this mode unaided.
static bool LadderModeSoundsAsLadder(int mode)
{
    return mode == 3 || mode == 4;
}

static const int LADDER_STEP_VOLUME = 0x7F;   // as sub_4783D6 and sub_478420 pass
static const int LADDER_STEP_PAN    = 0x80;   // centre, as all four call sites pass

// v0.125.0 (#centra): THE CADENCE IS MEASURED, NOT CHOSEN.
//
// Aaron on v0.124.0: "did hear the ladder sounds now on that top ladder,
// however, the climbing sounds were very fast compared to the way they usually
// sound on a ladder." His log says exactly how fast: eighteen steps between
// `climb started` at 12:28:09 and `climb ended` at 12:28:14, which is the 260 ms
// this file used to hardcode. **260 WAS A GUESS**, written in the same build
// that had just finished arguing against guessing, and it is wrong by roughly
// the factor a listener would call "very fast".
//
// THE ENGINE ALREADY KNOWS THE ANSWER, so the mod stops guessing and asks it.
// sub_00520260 fires on a zero crossing: 0x004783A2 compares the previous foot
// offset in `si` against the new one in `bx` and plays a step when their signs
// differ, once per foot, twice per animation cycle. That means the true cadence
// is a property of the climbing animation's playback speed -- not a number
// anybody can read out of the exe, and not one worth guessing at twice. So this
// build hooks the routine, times the gaps between the engine's own steps on the
// ladders that already sound, and replays that interval on the ones that do not.
//
// AND IT FIXES SOMETHING AARON HAS NOT HIT YET. v0.124.0 polls the movement mode
// and steps on every ladder -- including the ones the engine is already sounding.
// On crtower3's `ladup0` and crtower1's `p0_ladup0` that is a SECOND set of steps
// laid over the game's own. The Centra run that produced the log climbed only the
// roof ladder, so the doubling never reached his ears; the hook that measures the
// cadence is also what detects the engine stepping and holds the mod's cue back.
// v0.126.0 (#centra): 469 IS MEASURED, NOT CHOSEN -- IT IS THE NUMBER THE
// HOOK CAME BACK WITH. The 2026-08-28 13:06 run timed fifteen consecutive
// engine steps on the crtower ladder: 468, 407, 468, 453, 469, 469, 469,
// 468, 469, 469, 469, 453, 469, 468. Eleven of the fourteen gaps are 468-469
// ms; the 453 and 407 outliers are one and three frames short at 64 Hz, which
// is the poll quantising, not the animation changing speed. So the climbing
// animation's true cadence is ~469 ms per rung and that is now the starting
// value, not 700. Aaron heard the running mean (465 ms) on crroof1's silent
// ladder and called it "the normal pace" -- this locks that pace in so a
// silent ladder sounds right on the FIRST climb, with no engine-sounded
// ladder needed ahead of it to teach the mod the rhythm. The learning below
// still runs and still refines; it just no longer has anything to rescue.
static const unsigned LADDER_STEP_MS_DEFAULT = 469;  // measured, see above
static const unsigned LADDER_STEP_MS_MIN     = 300;  // faster than this is not a climb
static const unsigned LADDER_STEP_MS_MAX     = 1400; // slower than this is a pause
// A climb has a mount animation before the first rung. Waiting this long before
// the mod's first step also gives an engine-sounded ladder time to declare
// itself, so the mod never lays a step over the game's own opening one.
static const unsigned LADDER_STEP_GRACE_MS   = 400;

static unsigned LadderClampInterval(unsigned ms)
{
    if (ms < LADDER_STEP_MS_MIN) return LADDER_STEP_MS_MIN;
    if (ms > LADDER_STEP_MS_MAX) return LADDER_STEP_MS_MAX;
    return ms;
}

// A gap only counts as a cadence sample if it could plausibly be one. Two steps
// 80 ms apart are the two feet crossing on the same frame; two steps four
// seconds apart span a pause, a cutscene, or two separate ladders.
static bool LadderGapIsSample(unsigned gapMs)
{
    return gapMs >= LADDER_STEP_MS_MIN && gapMs <= LADDER_STEP_MS_MAX;
}

// ============================================================================
// v0.127.0 (#centra): A GAP THE ENGINE SKIPPED IS NOT A SLOWER LADDER
// ============================================================================
// The 16:39-16:54 run measured nineteen gaps on the crtower ladder and the
// running mean walked 469 -> 783 -> 970 before settling at 586, which is the
// number crroof1's silent roof ladder then played at. The game's own rate is
// 468-469 ms (v0.126.0 timed eleven of fourteen gaps there). So the mod spent
// that climb a quarter slower than the ladder it was imitating.
//
// FOUR OF THE NINETEEN GAPS DID IT: 953, 1359, 1344 and 672 ms. The first
// three are 2x and 3x the real interval -- the engine's zero crossing missing
// a stride, not the animation slowing down -- and averaging them in is
// arithmetic that cannot be right, because a skipped step contains no
// information about the pace except that it was a whole number of steps.
//
// SO A GAP IS FOLDED BEFORE IT IS BELIEVED. Divide by 1, 2 or 3 and keep the
// quotient closest to the pace we already have, provided it lands inside a
// quarter of it. 953/2 = 476 and 1359/3 = 453 both survive and both are the
// truth; 672 does not divide into anything plausible (672 itself is too slow,
// 336 too fast) and is dropped rather than dragged into the mean. Replayed
// against the whole run this holds the cadence between 426 and 476 ms
// throughout -- the pace Aaron called normal -- instead of reaching 970.
//
// THE BAND IS 80-125% AND THAT IS NOT ARBITRARY. A gap around 1.5x the pace is
// genuinely ambiguous -- one slow stride or two fast ones, and nothing in the
// data says which -- so the band is set so that BOTH readings of it fall
// outside and it is dropped. 672 against a 452 ms belief is that case: 672 is
// too slow and its halving, 336, is too fast. Widen the band to +/-35% and the
// halving squeaks in, which is the exact failure the folding exists to prevent
// -- a fold that finds SOME quotient in range for any gap at all is a licence
// to believe anything.
static const unsigned LADDER_FOLD_MAX_N   = 3;   // 2x and 3x skips are what the log shows
static const unsigned LADDER_BAND_LO_PCT  = 80;
static const unsigned LADDER_BAND_HI_PCT  = 125;

static unsigned LadderAbsDiff(unsigned a, unsigned b)
{
    return (a > b) ? (a - b) : (b - a);
}

// The per-step interval this gap implies, or 0 when it implies nothing usable.
static unsigned LadderFoldGap(unsigned gapMs, unsigned intervalMs)
{
    if (intervalMs == 0) return 0;
    unsigned best = 0;
    for (unsigned n = 1; n <= LADDER_FOLD_MAX_N; n++) {
        const unsigned folded = gapMs / n;
        if (!LadderGapIsSample(folded)) continue;
        if (folded * 100u < intervalMs * LADDER_BAND_LO_PCT) continue;
        if (folded * 100u > intervalMs * LADDER_BAND_HI_PCT) continue;
        if (best == 0 || LadderAbsDiff(folded, intervalMs) < LadderAbsDiff(best, intervalMs))
            best = folded;
    }
    return best;
}

// Learned as a running mean weighted two-to-one toward what we already believe,
// so one odd gap cannot swing the cue.
//
// v0.127.0 drops v0.125.0's "the first real sample is taken outright" rule. That
// rule existed to stop a 700 ms guess contaminating a measurement; since v0.126.0
// the starting value IS a measurement -- 469 ms, timed off the engine -- so there
// is nothing to escape from, and taking a first sample outright would throw away
// the better estimate to chase a single reading.
static unsigned LadderLearnInterval(unsigned prevMs, unsigned gapMs)
{
    const unsigned folded = LadderFoldGap(gapMs, prevMs);
    if (folded == 0) return prevMs;
    return LadderClampInterval((prevMs * 2u + folded) / 3u);
}

// True while the engine is sounding this climb itself. The mod stays silent:
// its job is the ladders the game forgot, not a second layer on the ones it
// remembered.
//
// v0.127.0 widens the slack from two intervals to four. At two, the 1359 ms hole
// in the engine's own rhythm on crtower3 at 16:51:22 was long enough for the mod
// to cut in, and the log duly shows "2 mod steps, engine sounded it itself" on a
// ladder the mod was supposed to leave alone. Four intervals is ~1.9 s, past the
// longest hole the engine has ever been observed to leave (1359 ms), so a real
// dropout is still covered and its own rhythm is not interrupted.
static const unsigned LADDER_ENGINE_QUIET_FACTOR = 4;

static bool LadderEngineIsStepping(bool everEngine, unsigned nowMs,
                                   unsigned lastEngineMs, unsigned intervalMs)
{
    if (!everEngine) return false;
    return (unsigned)(nowMs - lastEngineMs) < intervalMs * LADDER_ENGINE_QUIET_FACTOR;
}

// The routine's first sixteen bytes, checked before the mod ever calls through
// a hardcoded address. A patched or repacked exe fails the check and the cue
// stays silent rather than jumping into the middle of something else.
static const unsigned char LADDER_STEP_SIG[] = {
    0x83, 0xEC, 0x10,                    // sub  esp, 0x10
    0x57,                                // push edi
    0x8B, 0x7C, 0x24, 0x18,              // mov  edi, [esp+0x18]   <- the entity
    0xF6, 0x87, 0x60, 0x01, 0x00, 0x00, 0x80   // test byte [edi+0x160], 0x80
};
static const int LADDER_STEP_SIG_LEN = (int)sizeof(LADDER_STEP_SIG);
static const unsigned LADDER_STEP_ADDR = 0x00520260u;

// The entity movement modes a ladder move sets. Anything else -- standing,
// walking, running -- is the engine's business and already makes its own noise.
static bool LadderModeIsClimb(int mode)
{
    return mode == 2 || mode == 3 || mode == 4;
}

// One step per learned interval while the climb lasts. `everStepped` is a flag
// rather than a zero timestamp for the reason the host probe found within a
// minute of existing: under a clock reading 0, a zero sentinel means the very
// first step stamps 0 and the spacing never engages. `climbStartMs` is stamped
// the frame the mode turns into a ladder mode, so the grace period is measured
// from the mount rather than from whenever the last climb happened to end.
static bool LadderStepDue(bool climbing, unsigned nowMs, unsigned climbStartMs,
                          unsigned lastMs, bool everStepped, unsigned intervalMs)
{
    if (!climbing) return false;
    if (!everStepped) return (unsigned)(nowMs - climbStartMs) >= LADDER_STEP_GRACE_MS;
    return (unsigned)(nowMs - lastMs) >= intervalMs;
}

// Feet alternate, the way the engine's own callers do -- two of the four pass
// foot 1 and two pass foot 0, and the routine has a separate branch for each.
static int LadderStepFoot(int stepIndex)
{
    return (stepIndex & 1);
}
